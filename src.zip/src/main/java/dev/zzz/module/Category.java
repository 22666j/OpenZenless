package dev.zzz.module;

public enum Category {
    Combat,
    Movement,
    Render,
    World,
    Player,
    Misc;

}


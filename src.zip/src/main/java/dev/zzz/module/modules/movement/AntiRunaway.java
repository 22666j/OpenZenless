package dev.zzz.module.modules.movement;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.world.EventUpdate;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.values.NumberValue;

@Native
public class AntiRunaway extends Module {

    public AntiRunaway(){
        super("AntiRunaway", Category.Movement);
    }
    private final NumberValue health = new NumberValue("Health", 2.0, 0.1,20.0,  0.1);
    @EventTarget
    public void onUpdate(EventUpdate event) {
        if ((double) AntiRunaway.mc.thePlayer.getHealth() <= this.health.getValue()) {
            AntiRunaway.mc.thePlayer.sendChatMessage("我是欣欣哥来看我自动逃逸");
            AntiRunaway.mc.thePlayer.sendChatMessage("/hub");
            //this.state = false;
        }
    }
}

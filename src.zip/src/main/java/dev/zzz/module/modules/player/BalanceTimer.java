package dev.zzz.module.modules.player;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.rendering.EventRender2D;
import dev.zzz.event.world.EventWorldLoad;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.utils.client.MathUtil;
import dev.zzz.utils.render.RenderUtil;
import dev.zzz.utils.render.animation.BezierUtil;
import dev.zzz.utils.render.fontRender.FontManager;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.awt.*;

@Native

public class BalanceTimer extends Module {
    private static BalanceTimer INSTANCE;
    public static final int RELEASE_SPEED = 5;
    public static int balance = 0;
    public static Stage stage = Stage.IDLE;
    private final BezierUtil yAnimation = new BezierUtil(4, 0);
    private final BezierUtil xAnimation = new BezierUtil(4, 0);

    public BalanceTimer() {
        super("BalanceTimer", Category.Player);
        INSTANCE = this;
    }

    @EventTarget
    public void onWorld(EventWorldLoad event) {
        balance = 0;
        stage = Stage.IDLE;
    }

    public static void preTick() {
        if (INSTANCE == null || mc.theWorld == null || !INSTANCE.getState()) {
            stage = Stage.IDLE;
            mc.timer.timerSpeed = 1.0f;
            balance = 0;
            return;
        }
        if ((Keyboard.isKeyDown(Keyboard.KEY_LCONTROL) && Keyboard.isKeyDown(Keyboard.KEY_1)) || Mouse.isButtonDown(3)) {
            mc.theWorld.skiptick++;
            stage = Stage.STORE;
            mc.timer.timerSpeed = 1.0f;
            balance = 0;
        } else if (((Keyboard.isKeyDown(Keyboard.KEY_LCONTROL) && Keyboard.isKeyDown(Keyboard.KEY_2)) || Mouse.isButtonDown(4)) && mc.scheduledTasks.size() > 0) {
            stage = Stage.RELEASE;
            mc.timer.timerSpeed = RELEASE_SPEED;
            balance++;
        } else {
            stage = Stage.IDLE;
            mc.timer.timerSpeed = 1.0f;
            balance = 0;
        }

        if (!mc.scheduledTasks.isEmpty()) {
            INSTANCE.yAnimation.update(0);
        } else {
            INSTANCE.yAnimation.update(-30);
            INSTANCE.xAnimation.update(0);
        }

    }

    public enum Stage {
        STORE,
        IDLE,
        RELEASE
    }
    @EventTarget
    public void onRender2D(EventRender2D e){
        ScaledResolution sr = new ScaledResolution(mc);
        float x = sr.getScaledHeight() / 2F;
        float y = sr.getScaledWidth() / 2F + yAnimation.get();
        String text = "Timer Balance: " + Math.max(0, MathUtil.round((mc.scheduledTasks.size() - 1) * 0.05, 1)) + "s";
        float width = FontManager.arial16.getStringWidth(text) + 10, height = 20;
        xAnimation.update(width);

        RenderUtil.scissorStart(sr.getScaledHeight() / 2F, sr.getScaledWidth() / 2F, this.xAnimation.get(), height);
        RenderUtil.drawRect(x, y, x + this.xAnimation.get(), y + height, new Color(0, 0, 0, 129).getRGB());

        FontManager.arial16.drawString(text, x + 5, y + 5, Color.WHITE);
        RenderUtil.scissorEnd();
    }

    public static boolean isInstanceEnabled() {
        return INSTANCE.getState();
    }
}
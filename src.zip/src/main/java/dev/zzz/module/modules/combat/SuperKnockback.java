package dev.zzz.module.modules.combat;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.Client;
import dev.zzz.event.EventTarget;
import dev.zzz.event.attack.EventAttack;
import dev.zzz.event.world.EventMotion;
import dev.zzz.event.world.EventPacketSend;
import dev.zzz.event.world.EventUpdate;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.values.BoolValue;
import dev.zzz.module.values.ModeValue;
import dev.zzz.utils.player.MoveUtil;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.MathHelper;

@Native
public class SuperKnockback extends Module {
    private int state = 0;
    private static boolean canSend = false;
    private static boolean canSprint = false;

    public SuperKnockback() {
        super("SuperKnockBack", Category.Combat);
    }

    public static boolean canSprint() {
        return canSprint || !Client.instance.moduleManager.getModule(SuperKnockback.class).getState();
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (canSend) {
            if (state <= 2 && mc.thePlayer.isSprinting() == mc.thePlayer.serverSprintState) {
                if (mc.thePlayer.serverSprintState) {
                    canSprint = false;
                } else {
                    canSprint = true;
                }
            } else {
                canSprint = true;
            }
            state++;

        }



    }

    @EventTarget
    public void onAttack(EventAttack event) {
        state = 0;
    }

    @EventTarget
    public void onPacketSend(EventPacketSend e) {
        if (e.getPacket() instanceof C03PacketPlayer) {
            canSend = true;
        }

        if (e.getPacket() instanceof C0BPacketEntityAction action && (action.getAction() == C0BPacketEntityAction.Action.START_SPRINTING || action.getAction() == C0BPacketEntityAction.Action.STOP_SPRINTING)) {
//            ChatUtil.info(action.getAction().toString());
            canSend = false;
        }
        if (e.getPacket() instanceof S08PacketPlayerPosLook packet) {
            canSend = false;
        }

    }
}
package dev.zzz.module.modules.combat;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.yumegod.obfuscation.Native;
import dev.zzz.Client;
import dev.zzz.event.EventTarget;
import dev.zzz.event.world.EventMotion;
import dev.zzz.event.world.EventUpdate;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.modules.player.Blink;
import dev.zzz.module.modules.world.Scaffold;
import dev.zzz.module.values.BoolValue;
import dev.zzz.module.values.ModeValue;
import dev.zzz.module.values.NumberValue;
import dev.zzz.utils.MovementFix;
import dev.zzz.utils.RotationComponent;
import dev.zzz.utils.client.MathUtil;
import dev.zzz.utils.client.StopWatch;
import dev.zzz.utils.player.RotationUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemEgg;
import net.minecraft.item.ItemSnowball;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import org.apache.commons.lang3.RandomUtils;
import org.lwjgl.compatibility.util.vector.Vector2f;

/**
 * @author 22666j
 * @since 2024/12/1 0:55
 */
@Native
public final class ProjectileAura extends Module {
    public final NumberValue range = new NumberValue("Range",  8, 5, 15, 1);
    public final NumberValue minRange = new NumberValue("Min Range", 0, 0, 4, 0.1);
    private final NumberValue rotationSpeed = new NumberValue("Rotation speed", 5, 10, 20, 1);
    private final NumberValue ticksValue = new NumberValue("Attack Ticks",  20.0, 1.0, 80.0, 1.0);
    private final BoolValue showTargets = new BoolValue("Targets", false);
    public final BoolValue player = new BoolValue("Player",  false, () -> !this.showTargets.getValue());
    public final BoolValue invisibles = new BoolValue("Invisibles", false, () -> !this.showTargets.getValue());
    public final BoolValue animals = new BoolValue("Animals",  false, () -> !this.showTargets.getValue());
    public final BoolValue mobs = new BoolValue("Mobs",  false, () -> !this.showTargets.getValue());
    public final BoolValue villagers = new BoolValue("Villagers",  false, () -> !this.showTargets.getValue());
    public final BoolValue teams = new BoolValue("Teams",  false, () -> !this.showTargets.getValue());
    private long AttackTime = 0L;
    private float randomYaw;
    private float randomPitch;
    private boolean AttackFix;
    public static List<Entity> targets;
    public Entity target;
    public StopWatch switchChangeTicks = new StopWatch();
    int i = 0;

    public ProjectileAura() {
        super("Projectile Aura", Category.Combat);
    }
    @Override
    public void onEnable() {
        i = mc.thePlayer.inventory.currentItem;

    }
    @EventTarget
    public void onEvent(EventUpdate event) {

        KillAura killAura = this.getModule(KillAura.class);
        if (!this.isNull()
                && killAura.target == null
                && !this.getModule(Scaffold.class).state
                && !this.getModule(Blink.class).state
                && !this.getModule(AutoGapple.class).state) {
            if (mc.thePlayer.inventory.hasItem(Items.snowball) || mc.thePlayer.inventory.hasItem(Items.egg)) {
                this.getTargets(this.range.getValue().doubleValue());
                if (targets.isEmpty()) {
                    this.randomiseTargetRotations();
                    this.target = null;
                    return;
                }

                this.target = targets.get(0);


                if (this.target == null || mc.thePlayer.isDead) {
                    this.randomiseTargetRotations();
                    return;
                }

                if (mc.thePlayer.inventory.hasItem(Items.snowball) || mc.thePlayer.inventory.hasItem(Items.egg)) {
                    int snowballSlot = this.getItemSlot(Items.snowball);
                    int eggSlot = this.getItemSlot(Items.egg);
                    if (snowballSlot != -1) {
                        //mc.thePlayer.inventory.currentItem = snowballSlot;
                        mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(snowballSlot));
                        this.rotations();
                        this.doAttack();
                        mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(i));
                    } else if (eggSlot != -1) {
                        mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(eggSlot));
                        this.rotations();
                        this.doAttack();
                        mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(i));
                    }
                }

                //if (mc.thePlayer.getHeldItem() != null
                //&& (mc.thePlayer.getHeldItem().getItem() instanceof ItemSnowball || mc.thePlayer.getHeldItem().getItem() instanceof ItemEgg)) {
                //this.rotations();
                //this.doAttack();
                //}
            }
        }
    };

    private void rotations() {
        Vector2f targetRotations = RotationUtil.calculate(target, false, range.getValue());
        if (target != null) {
            RotationUtil.calculate(target);
        }
        final double minRotationSpeed = this.rotationSpeed.getValue();
        final double maxRotationSpeed = this.rotationSpeed.getValue();
        final float rotationSpeed = (float) MathUtil.getRandom(minRotationSpeed, maxRotationSpeed);
        if (target != null) {
            if (target.getDistanceToEntity(mc.thePlayer) <= range.getValue()) {
                if (mc.thePlayer.onGround) {
                    if (target.getDistanceToEntity(mc.thePlayer) >= 8 && target.getDistanceToEntity(mc.thePlayer) <= 12) {
                        targetRotations.y -= 3;
                    } else if (target.getDistanceToEntity(mc.thePlayer) >= 13 && target.getDistanceToEntity(mc.thePlayer) <= 17) {
                        targetRotations.y -= 5;
                    } else if (target.getDistanceToEntity(mc.thePlayer) >= 18 && target.getDistanceToEntity(mc.thePlayer) <= 24) {
                        targetRotations.y -= 8;
                    } else if (target.getDistanceToEntity(mc.thePlayer) >= 25 && target.getDistanceToEntity(mc.thePlayer) <= range.getValue()) {
                        targetRotations.y -= 11;
                    }
                }
            }
        }

        if (target == null) {
            targetRotations.x = mc.thePlayer.rotationYaw;
            targetRotations.y = mc.thePlayer.rotationPitch;
        }
        RotationComponent.setRotations(targetRotations, rotationSpeed, true);
    }

    private double calculateExposure(Vec3 start, Vec3 end) {
        double exposure = 0.0;
        Vec3 direction = end.subtract(start).normalize();
        Vec3 currentPosition = start;

        while (currentPosition.distanceTo(end) > 1.0) {
            currentPosition = currentPosition.addVector(direction.xCoord, direction.yCoord, direction.zCoord);
            int blockX = MathHelper.floor_double(currentPosition.xCoord);
            int blockY = MathHelper.floor_double(currentPosition.yCoord);
            int blockZ = MathHelper.floor_double(currentPosition.zCoord);
            BlockPos blockPos = new BlockPos(blockX, blockY, blockZ);
            if (!mc.theWorld.isAirBlock(blockPos)) {
                exposure += 0.1;
            }
        }

        return exposure;
    }

    private void doAttack() {
        long currentTime = System.currentTimeMillis();
        long ticks = (long)this.ticksValue.getValue().intValue() * 20L;
        if (currentTime - this.AttackTime >= ticks) {
            //if (this.AttackFix) {
                this.rotations();
                //mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem());
                mc.getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.getHeldItem()));
                this.AttackFix = false;
           // }

            this.AttackTime = currentTime;
        }
    }

    private void randomiseTargetRotations() {
        this.randomYaw = this.randomYaw + (float)(Math.random() - 0.5) / 5.0F;
        this.randomPitch = this.randomPitch + (float)(Math.random() - 0.5) * 2.0F / 5.0F;
    }

    private int getItemSlot(Item item) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.thePlayer.inventory.mainInventory[i];
            if (stack != null && stack.getItem() == item) {
                return i;
            }
        }

        return -1;
    }

    public void getTargets(double range) {
        //Teams teams1 = Client.INSTANCE.getModuleManager().get(Teams.class);
        AntiBot antiBot = Client.instance.moduleManager.getModule(AntiBot.class);
        targets = mc.theWorld
                .loadedEntityList
                .stream()
                .filter(entity -> entity instanceof EntityLivingBase && entity != mc.thePlayer)
                .filter(entity -> !entity.isDead && ((EntityLivingBase)entity).deathTime == 0)
                .filter(entity -> (double)mc.thePlayer.getDistanceToEntity(entity) <= range)
                .filter(entity -> {
                    if (entity.isInvisible() && !this.invisibles.getValue()) {
                        return false;
                    } else {
                        return this.isTargetTypeAllowed(entity);
                    }
                })
                .sorted(Comparator.comparingDouble(entity -> (double)mc.thePlayer.getDistanceToEntity(entity)))
                .collect(Collectors.toList());
        this.target = targets.isEmpty() ? null : targets.get(0);
    }

    private boolean isTargetTypeAllowed(Entity entity) {
        if (entity instanceof EntityPlayer) {
            return this.player.getValue();
        } else if (entity instanceof EntityAnimal) {
            return this.animals.getValue();
        } else if (entity instanceof EntityVillager) {
            return this.villagers.getValue();
        } else if (entity instanceof EntitySquid) {
            return false;
        } else {
            return entity instanceof EntityMob ? this.mobs.getValue() : false;
        }
    }
}
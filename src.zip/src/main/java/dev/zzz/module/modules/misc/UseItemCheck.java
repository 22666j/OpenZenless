package dev.zzz.module.modules.misc;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.world.EventPacketSend;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.modules.combat.KillAura;
import dev.zzz.utils.DebugUtil;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0EPacketClickWindow;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;

@Native
public class UseItemCheck extends Module {
    public UseItemCheck() {
        super("UseItemCheck", Category.Misc);
    }
    @EventTarget
    public void onUseItem(EventPacketSend event) {
        if (event.getPacket() == null) return;
        if (KillAura.target != null) {
            if (event.getPacket() instanceof C09PacketHeldItemChange c09PacketHeldItemChange) {
                DebugUtil.log("UseItemCheck: 我去C09你漏防了 切换手物品到槽位: " + c09PacketHeldItemChange.getSlotId());
            }
            if (event.getPacket() instanceof C07PacketPlayerDigging c07PacketPlayerDigging) {
                DebugUtil.log("UseItemCheck: 我去C07你漏防了 正在执行的操作: " + c07PacketPlayerDigging.getStatus().name());
            }
            if (event.getPacket() instanceof C0EPacketClickWindow) {
                DebugUtil.log("UseItemCheck: 我去C0E你漏防了 正在点击窗口");
            }
        }
    }
}

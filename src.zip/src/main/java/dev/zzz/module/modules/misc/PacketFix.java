package dev.zzz.module.modules.misc;

import dev.zzz.module.Category;
import dev.zzz.module.Module;

public class PacketFix extends Module {
    public PacketFix() {
        super("PacketFix", Category.Misc);
    }
}

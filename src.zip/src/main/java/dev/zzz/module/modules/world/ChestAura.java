package dev.zzz.module.modules.world;

import com.yumegod.obfuscation.FlowObfuscate;
import dev.zzz.Client;
import dev.zzz.event.EventTarget;
import dev.zzz.event.rendering.EventRender3D;
import dev.zzz.event.world.EventMotion;
import dev.zzz.event.world.EventUpdate;
import dev.zzz.event.world.EventWorldLoad;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.modules.combat.KillAura;
import dev.zzz.module.modules.player.Blink;
import dev.zzz.module.modules.player.InvCleaner;
import dev.zzz.module.modules.render.HUD;
import dev.zzz.module.values.BoolValue;
import dev.zzz.module.values.NumberValue;
import dev.zzz.utils.Rotation;
import dev.zzz.utils.RotationComponent;
import dev.zzz.utils.TimeHelper;
import dev.zzz.utils.TimerUtil;
import dev.zzz.utils.client.PacketUtil;
import dev.zzz.utils.client.TimeUtil;
import dev.zzz.utils.player.PlayerUtil;
import dev.zzz.utils.player.RotationUtil;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import dev.zzz.utils.vec.Vector3d;
import net.minecraft.block.*;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.IInventory;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C0DPacketCloseWindow;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.*;
import org.lwjgl.compatibility.util.vector.Vector2f;
import org.lwjgl.opengl.GL11;

import static dev.zzz.module.modules.world.Scaffold.getVec3;
import static dev.zzz.utils.render.RenderUtil.drawBlockBox;


public class ChestAura extends Module {
    private final BoolValue render = new BoolValue("Render", false);
    private Rotation needRot;
    private EnumFacing needFacing;
    private TimeUtil msTimer = new TimeUtil();

    public static ArrayList<BlockPos> openedContainer = new ArrayList<>();

    public ChestAura() {
        super("ContainerAura", Category.Player);

    }

    @Override
    public void onEnable() {
        openedContainer.clear();
    }

    @EventTarget
    public void onWorld(EventWorldLoad e) {
        openedContainer.clear();
    }
    @EventTarget
    public void onRender3D(EventRender3D event) {

        if (render.getValue()) {
            for (BlockPos pos : mc.theWorld.loadedTileEntityList.stream()
                    .filter(e -> e instanceof IInventory)
                    .map(TileEntity::getPos)
                    .collect(Collectors.toList())) {

                Color color = openedContainer.contains(pos) ? new Color(128, 128, 200, 60) : new Color(255, 200, 200, 60);

//                    double x = pos.getX() - mc.getRenderManager().viewerPosX;
//                    double y = pos.getY() - mc.getRenderManager().viewerPosY;
//                    double z = pos.getZ() - mc.getRenderManager().viewerPosZ;
//
//                    double sizeX = 1.0, sizeY = 1.0, sizeZ = 1.0;
//                    if (isChest(pos)) {
//                        double inset = 0.0625F;
//                        sizeX = sizeZ = 0.9375F - inset;
//                        sizeY = 0.875F;
//                        x += inset;
//                        z += inset;
//                        // 我他妈写了1个小时才知道这个碰撞箱
//                    }
                for (final BlockPos blockPos : openedContainer) {
                    drawBlockBox(blockPos, HUD.mainColor.getColorC(), true);
                }
            }
        }
    }
    @EventTarget
//    @EventPriority(12)
    private void onPre(EventUpdate event) {
        try {
        if (KillAura.target != null || getModule(Scaffold.class).getState() ||
                getModule(Blink.class).getState())
            return;

        BlockPos nearestContainer = null;
        double nearestDistance = Double.MAX_VALUE;
        if (mc.currentScreen instanceof GuiContainer) return;
        for (int x = -5; x < 6; x++) {
            for (int y = -5; y < 6; y++) {
                for (int z = -5; z < 6; z++) {
                    BlockPos fixedBP = new BlockPos(mc.thePlayer.posX + x, mc.thePlayer.posY + y, mc.thePlayer.posZ + z);
                    if (checkContainerOpenable(fixedBP)) {
                        MovingObjectPosition mop = mc.theWorld.rayTraceBlocks(
                                new Vec3(mc.thePlayer.posX, mc.thePlayer.posY + mc.thePlayer.getEyeHeight(), mc.thePlayer.posZ),
                                new Vec3(fixedBP).add(new Vec3(0.5, 0.5, 0.5)),
                                false, true, true);
                        if (mc.thePlayer.getDistance(fixedBP.getX(), fixedBP.getY(), fixedBP.getZ()) < 4.5 &&
                                !openedContainer.contains(fixedBP) && mc.thePlayer.getDistance(fixedBP.getX(), fixedBP.getY(), fixedBP.getZ()) <= nearestDistance &&
                                isContainer(mc.theWorld.getBlockState(fixedBP).getBlock()) && mop != null &&
                                mop.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
                            nearestDistance = mc.thePlayer.getDistance(fixedBP.getX(), fixedBP.getY(), fixedBP.getZ());
                            nearestContainer = fixedBP;
                            float[] r = RotationUtil.getRotationBlock(fixedBP);
                            needRot = new Rotation(r[0], r[1]);
                            needFacing = mop.sideHit;
                        }
                    }
                }
            }
        }

        if (nearestContainer == null) return;
        if (!msTimer.hasReached(500L)) return;
        msTimer.reset();
        RotationComponent.setRotation(needRot, 180f, true);
        if (InvCleaner.serverOpen || InvCleaner.clientOpen){
            InvCleaner.mc.thePlayer.sendQueue.addToSendQueue(new C0DPacketCloseWindow(InvCleaner.mc.thePlayer.inventoryContainer.windowId));
            InvCleaner.serverOpen = false;
            InvCleaner.clientOpen = false;
        }
            //InvCleaner.mc.thePlayer.sendQueue.addToSendQueue(new C0DPacketCloseWindow(InvCleaner.mc.thePlayer.inventoryContainer.windowId));
        mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, mc.thePlayer.inventory.getCurrentItem(), nearestContainer, needFacing, getVec3(nearestContainer, needFacing));
        openedContainer.add(nearestContainer);
    } catch (Throwable e) {}
}


    private boolean isContainer(Block block) {
        return block instanceof BlockChest;
    }

    private boolean checkContainerOpenable(BlockPos blockPos) {
        IBlockState blockState = mc.theWorld.getBlockState(blockPos);
        if (!(blockState.getBlock() instanceof BlockChest)) return true;
        IBlockState upBlockState = mc.theWorld.getBlockState(blockPos.add(0, 1, 0));
        if (upBlockState.getBlock().isFullBlock() && !(upBlockState.getBlock() instanceof BlockGlass)) return false;
        return true;
    }
}

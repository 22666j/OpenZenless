package dev.zzz.module.modules.render;

import dev.zzz.event.EventTarget;
import dev.zzz.event.world.RenderWorldLastEvent;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.utils.FrameBufferHandler;

public class InterpolationRenderer extends Module {
    private final FrameBufferHandler frameBufferHandler;
    public InterpolationRenderer() {
        super("InterpolationRenderer", Category.Render);
        int width = mc.displayWidth;
        int height = mc.displayHeight;
        this.frameBufferHandler = new FrameBufferHandler (width, height);
    }
    @EventTarget
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        // Capture current frame
        frameBufferHandler.captureFrame();

        // Calculate partial tick time
        float partialTicks = mc.timer.renderPartialTicks;

        // Render interpolated frame
        frameBufferHandler.renderInterpolatedFrame(partialTicks);


    }


}

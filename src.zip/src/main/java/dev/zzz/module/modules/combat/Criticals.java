package dev.zzz.module.modules.combat;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.Client;
import dev.zzz.event.EventTarget;
import dev.zzz.event.attack.EventAttack;
import dev.zzz.event.world.*;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.ModuleManager;
import dev.zzz.module.modules.misc.Disabler;
import dev.zzz.module.modules.misc.IRC;
import dev.zzz.module.modules.player.BalanceTimer;
import dev.zzz.module.modules.player.Blink;
import dev.zzz.module.values.BoolValue;
import dev.zzz.module.values.ModeValue;
import dev.zzz.module.values.NumberValue;
import dev.zzz.utils.IrcManager;
import dev.zzz.utils.client.MathUtil;
import dev.zzz.utils.client.TimeUtil;
import dev.zzz.utils.player.PlayerUtil;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.BlockPos;

@Native
public class Criticals extends Module {

    private boolean working;

    public Criticals() {
        super("Criticals", Category.Combat);
    }

    @Override
    public void onEnable() {
        working = false;

    }
    @Override
    public void onDisable() {
        working = false;

    }
    @EventTarget
    public void onWorld(EventWorldLoad event) {
        Criticals.mc.theWorld.skiptick = 0;
    }
    public void legitJump() {
        if (mc.thePlayer.onGround) {
            mc.thePlayer.jump();
        }
    }
    @EventTarget
    public void onMovementInput(EventMoveInput event) {
        if (KillAura.target == null) {
            return;
        }
        if (AutoGapple.eating) {
            return;
        }
       // if (IRC.ircfriend.isEnabled()&& IrcManager.transport.isUser(KillAura.target.getName()))return;

        if (this.cantCrit(KillAura.target)) {
            this.reset();
        } else {
            KillAura aura = Client.instance.moduleManager.getModule(KillAura.class);
            if (KillAura.target != null) {
                if (!this.isNull() && Criticals.mc.thePlayer.motionY < 0.0 && !Criticals.mc.thePlayer.onGround && aura.state && Criticals.mc.thePlayer.getClosestDistanceToEntity(KillAura.target) <= 2.0f) {
                    ++Criticals.mc.theWorld.skiptick;
                } else if (!this.isNull() && !aura.state) {
                    this.reset();
                }
            }
        }
    }

    @EventTarget
    public void onTick(EventTick e) {
        setSuffix("Stuck");
        if (Client.instance.moduleManager.getModule(BalanceTimer.class).getState()){
            this.setState(false);
        }
    }

    @EventTarget
    public void onStrafe(EventStrafe e) {
        if (working) {
            legitJump();

            if (mc.thePlayer.hurtTime % 2 == 0) working = false;
        }
    }

    @EventTarget
    public void onAttack(EventAttack e) {
        boolean canCrit = e.getTarget() != null && mc.theWorld.getBlockState(new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1, mc.thePlayer.posZ)).getBlock().isFullBlock() && !mc.thePlayer.isOnLadder() && mc.thePlayer.ridingEntity == null;
        if (canCrit) {
            if (mc.thePlayer.hurtTime % 2 == 1) {
                working = true;
            }
        }
    }
    public boolean cantCrit(EntityLivingBase targetEntity) {
        EntityPlayerSP player = Criticals.mc.thePlayer;
        return player.isOnLadder() || player.isInWeb || player.isInWater() || player.isInLava() || player.ridingEntity != null || targetEntity.hurtTime > 10 || targetEntity.getHealth() <= 0.0f;
    }
    private void reset() {
        Criticals.mc.theWorld.skiptick = 0;
    }
}

package dev.zzz.module.modules.misc;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.attack.EventAttack;
import dev.zzz.event.world.EventMotion;
import dev.zzz.event.world.EventUpdate;
import dev.zzz.event.world.EventWorldLoad;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.values.ModeValue;
import dev.zzz.module.values.NumberValue;
import dev.zzz.utils.component.BadPacketsComponent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.apache.commons.lang3.RandomUtils;

@Native
public class Insults extends Module {
    private final String[] insults = {
            "%s记住我我是傻逼xiatian233",
            "%s记住我我是傻逼cubk",
            "%s记住我我是傻逼_moran_",
            "%s记住我我是傻逼yige",
            "%s记住我我是傻逼xinxin",
            "%s记住我我是傻逼margele"
    };



    public Insults() {
        super("Insults", Category.World);
    }

    private EntityPlayer target;

    @EventTarget
    private void onAttack(EventAttack eventAttack) {
        final Entity entity = eventAttack.getTarget();

        if (entity instanceof EntityPlayer) {
            target = (EntityPlayer) entity;
            System.out.println(target.getName());
        }
    }

    ;

    @EventTarget
    private void onUpdate(EventUpdate eventAttack) {
        if (target != null && !mc.theWorld.playerEntities.contains(target)) {
            if (mc.thePlayer.ticksExisted > 20 && !mc.thePlayer.isSpectator() && !mc.thePlayer.isDead) {
                        mc.thePlayer.sendChatMessage(insults[RandomUtils.nextInt(0, insults.length)].replaceAll("%s", target.getName()));
                }
            }
            target = null;
        }



}
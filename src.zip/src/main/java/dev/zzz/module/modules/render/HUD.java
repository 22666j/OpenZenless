package dev.zzz.module.modules.render;

import dev.zzz.Client;
import dev.zzz.event.EventTarget;
import dev.zzz.event.misc.EventKey;
import dev.zzz.event.rendering.EventRender2D;
import dev.zzz.event.rendering.EventShader;
import dev.zzz.event.world.EventTick;
import dev.zzz.event.world.EventUpdate;
import dev.zzz.gui.notification.Notification;
import dev.zzz.gui.notification.NotificationManager;
import dev.zzz.gui.ui.UiModule;
import dev.zzz.gui.ui.modules.*;
import dev.zzz.gui.verify.GuiLogin;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.ModuleManager;
import dev.zzz.module.values.BoolValue;
import dev.zzz.module.values.ColorValue;
import dev.zzz.module.values.ModeValue;
import dev.zzz.module.values.NumberValue;
import dev.zzz.utils.FrameBufferHandler;
import dev.zzz.utils.TimerUtil;
import dev.zzz.utils.render.AnimationUtil;
import dev.zzz.utils.render.GifRenderer;
import dev.zzz.utils.render.RenderUtil;
import dev.zzz.utils.render.RoundedUtils;
import dev.zzz.utils.render.animation.Animation;
import dev.zzz.utils.render.animation.Direction;
import dev.zzz.utils.render.fontRender.FontManager;
import dev.zzz.utils.render.fontRender.RapeMasterFontManager;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

public class HUD
extends Module {
    public final ModeValue<HUDmode> hudModeValue = new ModeValue("HUD Mode", HUDmode.values(), HUDmode.Zeroless);
    public static BoolValue arraylist = new BoolValue("Arraylist", true);
    public static final BoolValue importantModules = new BoolValue("Arraylist-Important", false, () -> arraylist.getValue());
    public static final BoolValue hLine = new BoolValue("Arraylist-HLine", true, () -> arraylist.getValue());
    public static final NumberValue height = new NumberValue("Arraylist-Height", 11.0, 9.0, 20.0, 1.0, () -> arraylist.getValue());
    public static final NumberValue alpha = new NumberValue("Arraylist-Alpha", 2.0, 0.0, 5.0, 1.0, () -> arraylist.getValue());
    public static final ModeValue<ModuleList.ANIM> animation = new ModeValue("Arraylist-Animation", ModuleList.ANIM.values(), ModuleList.ANIM.ScaleIn, () -> arraylist.getValue());
    public static final BoolValue background = new BoolValue("Arraylist-Background", true, () -> arraylist.getValue());
    public static final NumberValue backgroundAlpha = new NumberValue("Arraylist-Background Alpha", 0.35, 0.01, 1.0, 0.01, () -> arraylist.getValue());
    public static BoolValue tab = new BoolValue("TabGUI", false);
    public static BoolValue notifications = new BoolValue("Notification", true);
    public static BoolValue Debug = new BoolValue("Debug", false);
    public static BoolValue info = new BoolValue("Info", true);
    public static BoolValue potionInfo = new BoolValue("Potion", false);
    public static BoolValue session = new BoolValue("Session", true);
    public static BoolValue inventory = new BoolValue("Inventory", true);
    public static BoolValue blockrate = new BoolValue("blockrate", true);
    public static BoolValue targetHud = new BoolValue("TargetHUD", true);
    public static BoolValue mcfont = new BoolValue("mcfont", true);
    public static ModeValue<THUDMode> thudmodeValue = new ModeValue("THUD Style", THUDMode.values(), THUDMode.Neon);
    public static BoolValue multi_targetHUD = new BoolValue("Multi TargetHUD", true);
    public static BoolValue titleBar = new BoolValue("TitleBar", true);
    private final ModeValue<TitleMode> modeValue = new ModeValue("Title Mode", TitleMode.values(), TitleMode.Logo);
    private final GifRenderer gifRenderer;
    public static NumberValue animationSpeed = new NumberValue("Animation Speed", 4.0, 1.0, 10.0, 0.1);
    public static NumberValue scoreBoardHeightValue = new NumberValue("Scoreboard Height", 0.0, 0.0, 300.0, 1.0);
    public static ColorValue mainColor = new ColorValue("First Color", Color.white.getRGB());
    public static ColorValue mainColor2 = new ColorValue("Second Color", Color.white.getRGB());
    private final TabGUI tabGUI = new TabGUI();
    TimerUtil time = new TimerUtil();
    int i;

    private float leftY;
    public int offsetValue = 0;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

    public HUD() {
        super("HUD", Category.Render);
        this.gifRenderer = new GifRenderer(new ResourceLocation("express/gif/cute.gif"));
        this.setState(true);
    }

    public static Color color(int tick) {
        return new Color(RenderUtil.colorSwitch(mainColor.getColorC(), mainColor2.getColorC(), 2000.0f, -(tick * 200) / 40, 75L, 2.0));
    }

    public static RapeMasterFontManager getFont() {
        return FontManager.arial18;
    }

    @EventTarget
    public void onShader(EventShader e) {
        String fps = String.valueOf(Minecraft.getDebugFPS());
        if (titleBar.getValue()) {
            switch (this.modeValue.getValue().toString().toLowerCase()) {
                case "simple": {
                    switch (this.hudModeValue.getValue()) {
                        case Shit: {
                            String str = EnumChatFormatting.DARK_GRAY + " | " + EnumChatFormatting.WHITE + Client.instance.USER + EnumChatFormatting.DARK_GRAY + " | " + EnumChatFormatting.WHITE + Minecraft.getDebugFPS() + "fps" + EnumChatFormatting.DARK_GRAY + " | " + EnumChatFormatting.WHITE + (mc.isSingleplayer() ? "SinglePlayer" : HUD.mc.getCurrentServerData().serverIP);
                            RoundedUtils.drawRound(6.0f, 6.0f, FontManager.arial16.getStringWidth(str) + 8 + FontManager.bold22.getStringWidth(Client.NAME.toUpperCase()), 15.0f, 0.0f, new Color(0, 0, 0));
                            RoundedUtils.drawRound(6.0f, 6.0f, FontManager.arial16.getStringWidth(str) + 8 + FontManager.bold22.getStringWidth(Client.NAME.toUpperCase()), 1.0f, 1.0f, new Color(0, 0, 0));
                            break;
                        }
                        case Neon: {
                            String title = String.format("| %s | %s | %sfps", Client.instance.getVersion(), Client.instance.USER, Minecraft.getDebugFPS());
                            String mark = Client.NAME;
                            float width = HUD.getFont().getStringWidth(title.toUpperCase()) + FontManager.bold22.getStringWidth(mark.toUpperCase()) + 6;
                            Gui.drawRect3(4.0, 4.0, width + 6.0f, FontManager.bold22.getHeight() + 4, new Color(0, 0, 0, 255).getRGB());
                            break;
                        }
                        case Zeroless: {
                            String username = GuiLogin.getUsername();
                            String n = Client.NAME;
                            StringBuilder nm = new StringBuilder(n);
                            float userwidth = FontManager.arial16.getStringWidth(username) + 6;
                            float iconwidth = FontManager.icon22.getStringWidth("t") + 12;
                            float namewidth = FontManager.bold24.getStringWidth(nm.toString());
                            float allwidth = namewidth + iconwidth;
                            float maxwidth = allwidth >= userwidth ? allwidth: userwidth;
                            RoundedUtils.drawRound(6.0f, 6.0f, maxwidth, 20, 2, new Color(20,20,20));
                            this.drawLine(6, 11, 2, 8, color(0));
                        }
                    }
                    break;
                }
                case "logo": {
                    GlStateManager.resetColor();
                    GlStateManager.enableAlpha();
                    GlStateManager.disableBlend();
                    RenderUtil.drawImage(10.0f, 10.0f, 66, 66, new ResourceLocation("express/jql.png"), new Color(255,255,255));
                    break;
                }
                case "ohh":{
                    float width;
                    String n;
                    String title;
                    float x = 5.0f;
                    float y = 5.0f;
                    title = String.format(" | %s | %s", Client.instance.getVersion(),"WDF");
                    n = Client.NAME;
                    StringBuilder nm = new StringBuilder(n);
                    nm.delete(this.i, nm.length());
                    width = (float)(FontManager.arial18.getStringWidth(title) + FontManager.bold22.getStringWidth(nm.toString()) + FontManager.logoFont.getStringWidth("A ") + 12);
                    RoundedUtils.drawRound(x + 4.0F, y + 4.0F, width + 5.0F, (float)(FontManager.bold22.getHeight() + 4), 2.0F, new Color(0, 0, 0));
                    break;
                }
            }
        }
        this.drawNotificationsEffects(e.isBloom());
        if (tab.getValue()) {
            this.tabGUI.blur(this, this.leftY);
        }
    }

    @EventTarget
    public void onKey(EventKey e) {
        if (tab.getValue()) {
            this.tabGUI.onKey(e.getKey());
        }
    }
    @EventTarget
    public void onUpdate(EventUpdate e){
        String n = Client.NAME;
        if (time.hasTimeElapsed(900)){
            if (i + 1 > n.length()){
                i = 0;
            } else {
                i += 1;
            }
            time.reset();
        }
    }
    @EventTarget
    public void onTick(EventTick e) {
        gifRenderer.update();
        gifRenderer.update();
        gifRenderer.update();
        gifRenderer.update();
    }

    @EventTarget
    public void onRender(EventRender2D e) {
        String name = Client.instance.USER;
        String fps = String.valueOf(Minecraft.getDebugFPS());
        int lengthName = FontManager.Tahoma16.getStringWidth(name);
        int nlRectX = lengthName + 74;
        UiModule DebugHud = Client.instance.uiManager.getModule(Debug.class);
        DebugHud.setState(Debug.getValue());
        UiModule Arraylist = Client.instance.uiManager.getModule(ModuleList.class);
        Arraylist.setState(arraylist.getValue());
        UiModule potionHUD = Client.instance.uiManager.getModule(PotionsInfo.class);
        potionHUD.setState(potionInfo.getValue());
        UiModule sessionHUD = Client.instance.uiManager.getModule(Session.class);
        sessionHUD.setState(session.getValue());
        UiModule InventoryHUD = Client.instance.uiManager.getModule(InventoryHUD.class);
        InventoryHUD.setState(inventory.getValue());
        UiModule BlockRate = Client.instance.uiManager.getModule(BlockRate.class);
        BlockRate.setState(blockrate.getValue());
        UiModule ifon = Client.instance.uiManager.getModule(Info.class);
        ifon.setState(info.getValue());
        gifRenderer.drawTexture(0,200, 100, 100);
        this.drawNotifications();
        if (titleBar.getValue()) {
            switch (this.modeValue.getValue().toString().toLowerCase()) {
                case "simple": {
                    switch (this.hudModeValue.getValue()) {
                        case Shit: {
                            String str = EnumChatFormatting.DARK_GRAY + " | " + EnumChatFormatting.WHITE + Client.instance.USER + EnumChatFormatting.DARK_GRAY + " | " + EnumChatFormatting.WHITE + Minecraft.getDebugFPS() + "fps" + EnumChatFormatting.DARK_GRAY + " | " + EnumChatFormatting.WHITE + (mc.isSingleplayer() ? "SinglePlayer" : HUD.mc.getCurrentServerData().serverIP);
                            RoundedUtils.drawRound(6.0f, 6.0f, FontManager.arial16.getStringWidth(str) + 8 + FontManager.bold22.getStringWidth(Client.NAME.toUpperCase()), 15.0f, 0.0f, new Color(19, 19, 19, 230));
                            RoundedUtils.drawRound(6.0f, 6.0f, FontManager.arial16.getStringWidth(str) + 8 + FontManager.bold22.getStringWidth(Client.NAME.toUpperCase()), 1.0f, 1.0f, HUD.color(8));
                            FontManager.arial16.drawString(str, 11 + FontManager.bold22.getStringWidth(Client.NAME.toUpperCase()), 11.5f, Color.WHITE.getRGB());
                            FontManager.bold22.drawString(Client.NAME.toUpperCase(), 9.5f, 12.0f, HUD.color(8).getRGB());
                            FontManager.bold22.drawString(Client.NAME.toUpperCase(), 10.0f, 12.5f, Color.WHITE.getRGB());
                            break;
                        }
                        case Neon: {
                            String title = String.format("| %s | %s | %sfps", Client.instance.getVersion(), Client.instance.USER, Minecraft.getDebugFPS());
                            String mark = Client.NAME;
                            float width = HUD.getFont().getStringWidth(title.toUpperCase()) + FontManager.bold22.getStringWidth(mark.toUpperCase()) + 6;
                            RenderUtil.drawRect(4.0, 4.0, width + 10.0f, FontManager.bold22.getHeight() + 8, new Color(0, 0, 0, 100).getRGB());
                            FontManager.bold22.drawStringDynamic(mark.toUpperCase(), 8.0, 10.0, 1, 6);
                            HUD.getFont().drawString(title.toUpperCase(), 12 + FontManager.bold22.getStringWidth(mark.toUpperCase()), 9.0f, -1);
                            break;
                        }
                        case Zeroless: {
                            String username = GuiLogin.getUsername();
                            String n = Client.NAME;
                            StringBuilder nm = new StringBuilder(n);
                            float userwidth = FontManager.arial16.getStringWidth(username) + 6;
                            float iconwidth = FontManager.icon22.getStringWidth("t") + 12;
                            float namewidth = FontManager.bold24.getStringWidth(nm.toString());
                            float allwidth = namewidth + iconwidth;
                            float maxwidth = allwidth >= userwidth ? allwidth: userwidth;
                            RoundedUtils.drawRound(6.0f, 6.0f, maxwidth, 20, 2, new Color(20,20,20, 130));
                            this.drawLine(6, 11, 2, 8, color(0));
                            FontManager.icon22.drawStringDynamic("t", 12, 12, 1, 6);
                            FontManager.bold24.drawStringDynamic(nm.toString(), maxwidth - FontManager.bold24.getStringWidth(nm.toString()) + 4, 11, 1, 6);
                            FontManager.arial16.drawCenteredString(username, 6.0f + maxwidth / 2.0f, 25.0f, Color.WHITE.getRGB());
                        }
                    }
                    this.leftY = AnimationUtil.animate(this.leftY, 24.0f, 0.3f);
                    break;
                }
                case "neverlose": {
                    int bgColor = new Color(30, 144, 255, 190).getRGB(); // 蓝色
                    int textColor = new Color(255, 255, 255).getRGB(); // 白色
                    double x = 5.0;
                    double y = 5.0;
                    double width = nlRectX;
                    double height = 20.0;
                    double cornerRadius = 5.0;
                    RenderUtil.drawRoundedRect((float) x, (float) y, (float) width, (float) height, (int) cornerRadius, bgColor);
                    FontManager.Tahoma18.drawString(Client.NAME, 10.0f, 10.0f, textColor);
                    FontManager.Tahoma16.drawString("|", 43.0f, 10.0f, textColor);
                    FontManager.Tahoma16.drawString(fps, 48.5f, 10.0f, textColor);
                    FontManager.Tahoma16.drawString("|", 64.0f, 10.0f, textColor);
                    FontManager.Tahoma16.drawString(name, 70.0f, 10.0f, textColor);
                    RenderUtil.drawShadow(5.0f, 5.0f, nlRectX, 20.0f);
                    break;
                }

                case "logo": {
                    GlStateManager.resetColor();
                    GlStateManager.enableAlpha();
                    GlStateManager.disableBlend();
                    RenderUtil.drawImage(10.0f, 10.0f, 60, 60, new ResourceLocation("express/jql.png"), new Color(255,255,255));
                    break;
                }
                case "onetap": {
                    String text = Client.NAME + " | " + fps + " | " + name + " | Yaw: " + (int)HUD.mc.thePlayer.rotationYaw % 360 + " | Pitch: " + (int)HUD.mc.thePlayer.rotationPitch;
                    int otRectX = FontManager.Tahoma14.getStringWidth(text) + 11;
                    RenderUtil.drawRoundedRect(5.0f, 6.0f, otRectX, 19.0f, 4, new Color(0, 0, 0, 200).getRGB());
                    RenderUtil.drawRoundedRect(5.0f, 5.0f, otRectX, 7.0f, 4, mainColor.getColor());
                    FontManager.Tahoma14.drawStringWithShadow(text, 8.0f, 11.0f, new Color(255, 255, 255).getRGB());
                    break;
                }
                case "ohh": {
                    float width;
                    String n;
                    String title;
                    float x = 5.0f;
                    float y = 5.0f;
                    title = String.format(" | %s | %s", Client.instance.getVersion(),"WDF");
                    n = Client.NAME;
                    StringBuilder nm = new StringBuilder(n);
                    nm.delete(this.i, nm.length());
                    width = (float)(FontManager.arial18.getStringWidth(title) + FontManager.bold22.getStringWidth(nm.toString()) + FontManager.logoFont.getStringWidth("A ") + 12);
                    RoundedUtils.drawRound(x + 4.0F, y + 4.0F, width + 5.0F, (float)(FontManager.bold22.getHeight() + 4), 2.0F, new Color(0, 0, 0, 100));
                    RenderUtil.drawRectWH((double)x + 4.0, (double)y + 8.0, 1.0, 8.0, HUD.color(1).getRGB());
                    FontManager.logoFont.drawString("A", x + 8.0F, y + 10.0F, Color.WHITE.getRGB());
                    FontManager.arial18.drawString("|", x + 8.0F + (float)FontManager.logoFont.getStringWidth("A "), y + 9.0F, -1);
                    FontManager.bold22.drawStringDynamic(" " + nm.toString(), (double)x + 8.0 + (double)FontManager.logoFont.getStringWidth("A ") + (double)FontManager.arial18.getStringWidth("|"), (double)y + 9.0, 1, 6);
                    FontManager.arial18.drawString(title, x + 16.0F + (float)FontManager.bold22.getStringWidth(nm.toString()) + (float)FontManager.logoFont.getStringWidth("A "), y + 9.0F, -1);
                    break;
                }
            }
        }
        UiModule Thud = Client.instance.uiManager.getModule(TargetHud.class);
        Thud.setState(targetHud.getValue());
        if (tab.getValue()) {
            this.tabGUI.renderTabGUI(this, this.leftY);
        }
    }
    public void drawLine(double x, double y, double width, double height, Color color){
        Gui.drawRect(x, y, x + width, y + height, color.getRGB());
    }


    public void drawNotifications() {
        ScaledResolution sr = new ScaledResolution(mc);
        float yOffset = 0.0f;
        NotificationManager.setToggleTime(2.0f);
        for (Notification notification : NotificationManager.getNotifications()) {
            Animation animation = notification.getAnimation();
            animation.setDirection(notification.getTimerUtil().hasTimeElapsed((long)notification.getTime()) ? Direction.BACKWARDS : Direction.FORWARDS);
            if (animation.finished(Direction.BACKWARDS)) {
                NotificationManager.getNotifications().remove(notification);
                continue;
            }
            animation.setDuration(200);
            int actualOffset = 10;
            int notificationHeight = 24;
            int notificationWidth = FontManager.arial20.getStringWidth(notification.getDescription()) + 33;
            float x2 = (float)((double)sr.getScaledWidth() - (double)(notificationWidth + 8) * animation.getOutput());
            float y2 = (float)sr.getScaledHeight() - (yOffset + 18.0f + (float)this.offsetValue + (float)notificationHeight + 15.0f);
            notification.drawDefault(x2, y2, notificationWidth, notificationHeight, (float) animation.getOutput());
            yOffset = (float)((double)yOffset + (double)(notificationHeight + actualOffset) * animation.getOutput());
        }
    }

    public void drawNotificationsEffects(boolean bloom) {
        ScaledResolution sr = new ScaledResolution(mc);
        float yOffset = 0.0f;
        for (Notification notification : NotificationManager.getNotifications()) {
            Animation animation = notification.getAnimation();
            animation.setDirection(notification.getTimerUtil().hasTimeElapsed((long)notification.getTime()) ? Direction.BACKWARDS : Direction.FORWARDS);
            if (animation.finished(Direction.BACKWARDS)) {
                NotificationManager.getNotifications().remove(notification);
                continue;
            }
            animation.setDuration(200);
            int actualOffset = 10;
            int notificationHeight = 24;
            int notificationWidth = FontManager.arial20.getStringWidth(notification.getDescription()) + 33;
            float x2 = (float)((double)sr.getScaledWidth() - (double)(notificationWidth + 8) * animation.getOutput());
            float y2 = (float)sr.getScaledHeight() - (yOffset + 18.0f + (float)this.offsetValue + (float)notificationHeight + 15.0f);
            notification.blurLettuce(x2, y2, notificationWidth, notificationHeight, bloom);
            yOffset = (float)((double)yOffset + (double)(notificationHeight + actualOffset) * animation.getOutput());
        }
    }

    public enum THUDMode {
        Neon,
        Novoline,
        Exhibition,
        ThunderHack,
        Raven,
        Sils,
        WTFNovo,
        Exire,
        Moon,
        RiseNew

    }

    public enum HUDmode {
        Neon,
        Shit,
        Zeroless,
        logo

    }

    public enum TitleMode {
        Simple,
        NeverLose,
        OneTap,
        ohh,
        Logo

    }

    public enum Section {
        TYPES,
        MODULES

    }

    public static class TabGUI {
        private Section section = Section.TYPES;
        private Category selectedType = Category.values()[0];
        private Module selectedModule = null;
        private int maxType;
        private int maxModule;
        private float horizonAnimation = 0.0f;
        private int currentType = 0;
        private int currentModule = 0;

        public void init() {
            Category[] arrCategory = Category.values();
            FontRenderer fontRenderer = Minecraft.getMinecraft().fontRendererObj;
            for (Category category : arrCategory) {
                int categoryWidth = fontRenderer.getStringWidth(category.name().toUpperCase()) + 4;
                this.maxType = Math.max(this.maxType, categoryWidth);
            }
            ModuleManager moduleManager = Client.instance.moduleManager;
            for (Module module : Client.instance.moduleManager.getModules()) {
                int moduleWidth = fontRenderer.getStringWidth(module.getName().toUpperCase()) + 4;
                this.maxModule = Math.max(this.maxModule, moduleWidth);
            }
            this.maxModule += 12;
            this.maxType = Math.max(this.maxType, this.maxModule);
            this.maxModule += this.maxType;
        }

        public void blur(HUD hud, float y2) {
            float categoryY;
            float moduleY = categoryY = y2 + 80;
            int moduleWidth = 60;
            int moduleX = moduleWidth + 1;
            Gui.drawRect(4.0, categoryY, moduleWidth - 3, categoryY + (float)(12 * Category.values().length), new Color(0, 0, 0, 255).getRGB());
            for (Category category : Category.values()) {
                boolean isSelected;
                boolean bl = isSelected = this.selectedType == category;
                if (isSelected) {
                    Gui.drawRect(5.0, categoryY + 2.0f, 6.5, (float)((double)(categoryY + (float)HUD.getFont().getHeight()) + 1.5), HUD.color(0).getRGB());
                    moduleY = categoryY;
                }
                categoryY += 12.0f;
            }
            if (this.section == Section.MODULES || this.horizonAnimation > 1.0f) {
                int moduleHeight = 12 * Client.instance.moduleManager.getModsByCategory(this.selectedType).size();
                if (this.horizonAnimation < (float)moduleWidth) {
                    this.horizonAnimation = (float)((double)this.horizonAnimation + (double)((float)moduleWidth - this.horizonAnimation) / 20.0);
                }
                Gui.drawRect(moduleX, moduleY, (float)moduleX + this.horizonAnimation, moduleY + (float)moduleHeight, new Color(0, 0, 0, 255).getRGB());
                for (Module module : Client.instance.moduleManager.getModsByCategory(this.selectedType)) {
                    boolean isSelected;
                    boolean bl = isSelected = this.selectedModule == module;
                    if (isSelected) {
                        Gui.drawRect((float)moduleX + 1.0f, moduleY + 2.0f, (float)moduleX + 2.5f, moduleY + (float)HUD.getFont().getHeight() + 1.0f, new Color(0, 0, 0, 255).getRGB());
                    }
                    moduleY += 12.0f;
                }
            }
            if (this.horizonAnimation > 0.0f && this.section != Section.MODULES) {
                this.horizonAnimation -= 5.0f;
            }
        }

        public void renderTabGUI(HUD hud, float y2) {
            float categoryY;
            float moduleY = categoryY = y2 + 80;
            int moduleWidth = 60;
            int moduleX = moduleWidth + 1;
            Gui.drawRect(4.0, categoryY, moduleWidth - 3, categoryY + (float)(12 * Category.values().length), new Color(0, 0, 0, 100).getRGB());
            for (Category category : Category.values()) {
                boolean isSelected = this.selectedType == category;
                int color = isSelected ? -1 : new Color(150, 150, 150).getRGB();
                HUD.getFont().drawString(category.name(), 8.0f, categoryY + 2.0f, color);
                if (isSelected) {
                    Gui.drawRect(5.0, categoryY + 2.0f, 6.5, (float)((double)(categoryY + (float)HUD.getFont().getHeight()) + 1.5), HUD.color(0).getRGB());
                    moduleY = categoryY;
                }
                categoryY += 12.0f;
            }
            if (this.section == Section.MODULES || this.horizonAnimation > 1.0f) {
                int moduleHeight = 12 * Client.instance.moduleManager.getModsByCategory(this.selectedType).size();
                if (this.horizonAnimation < (float)moduleWidth) {
                    this.horizonAnimation = (float)((double)this.horizonAnimation + (double)((float)moduleWidth - this.horizonAnimation) / 20.0);
                }
                Gui.drawRect(moduleX, moduleY, (float)moduleX + this.horizonAnimation, moduleY + (float)moduleHeight, new Color(0, 0, 0, 100).getRGB());
                for (Module module : Client.instance.moduleManager.getModsByCategory(this.selectedType)) {
                    boolean isSelected;
                    boolean bl = isSelected = this.selectedModule == module;
                    int color = isSelected ? new Color(-1).getRGB() : (module.getState() ? -1 : 0xAAAAAA);
                    HUD.getFont().drawString(module.getName(), moduleX + 3, moduleY + 2.0f, color);
                    if (isSelected) {
                        Gui.drawRect((float)moduleX + 1.0f, moduleY + 2.0f, (float)moduleX + 2.5f, moduleY + (float)HUD.getFont().getHeight() + 1.0f, HUD.color(0).getRGB());
                    }
                    moduleY += 12.0f;
                }
            }
            if (this.horizonAnimation > 0.0f && this.section != Section.MODULES) {
                this.horizonAnimation -= 5.0f;
            }
        }


        public void onKey(int key) {
            Minecraft mc = Minecraft.getMinecraft();
            ModuleManager moduleManager = Client.instance.moduleManager;
            Category[] values = Category.values();
            if (mc.gameSettings.showDebugInfo) {
                return;
            }
            int KEY_DOWN = Keyboard.KEY_DOWN;
            int KEY_UP = Keyboard.KEY_UP;
            int KEY_RIGHT = Keyboard.KEY_RIGHT;
            int KEY_RETURN = Keyboard.KEY_RETURN;
            int KEY_LEFT = Keyboard.KEY_LEFT;
            switch (key) {
                case 208: {
                    if (this.section == Section.TYPES) {
                        this.currentType = (this.currentType + 1) % values.length;
                        this.selectedType = values[this.currentType];
                        break;
                    }
                    if (this.section != Section.MODULES) break;
                    List<Module> modulesByCategory = moduleManager.getModsByCategory(this.selectedType);
                    this.currentModule = (this.currentModule + 1) % modulesByCategory.size();
                    this.selectedModule = modulesByCategory.get(this.currentModule);
                    break;
                }
                case 200: {
                    if (this.section == Section.TYPES) {
                        this.currentType = (this.currentType + values.length - 1) % values.length;
                        this.selectedType = values[this.currentType];
                        break;
                    }
                    if (this.section != Section.MODULES) break;
                    List<Module> modulesByCategory = moduleManager.getModsByCategory(this.selectedType);
                    this.currentModule = (this.currentModule + modulesByCategory.size() - 1) % modulesByCategory.size();
                    this.selectedModule = modulesByCategory.get(this.currentModule);
                    break;
                }
                case 205: {
                    if (this.section != Section.TYPES) break;
                    this.currentModule = 0;
                    this.selectedModule = moduleManager.getModsByCategory(this.selectedType).get(0);
                    this.section = Section.MODULES;
                    this.horizonAnimation = 0.0f;
                    break;
                }
                case 28: {
                    if (this.section == Section.MODULES) {
                        this.selectedModule.toggle();
                        break;
                    }
                    if (this.section != Section.TYPES) break;
                    this.currentModule = 0;
                    this.section = Section.MODULES;
                    this.selectedModule = moduleManager.getModsByCategory(this.selectedType).get(0);
                    break;
                }
                case 203: {
                    if (this.section != Section.MODULES) break;
                    this.section = Section.TYPES;
                    this.currentModule = 0;
                }
            }
        }
    }
}


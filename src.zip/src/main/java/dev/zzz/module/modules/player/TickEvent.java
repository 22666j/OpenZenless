package dev.zzz.module.modules.player;



import dev.zzz.event.api.events.Event;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public final class TickEvent implements Event {

}

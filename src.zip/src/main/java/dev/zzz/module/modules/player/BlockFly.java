package dev.zzz.module.modules.player;

import dev.zzz.event.EventTarget;
import dev.zzz.event.rendering.EventRender2D;
import dev.zzz.event.world.EventHigherPacketSend;
import dev.zzz.event.world.EventPacketSend;
import dev.zzz.event.world.EventTick;
import dev.zzz.event.world.EventUpdate;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.utils.client.PacketUtil;
import dev.zzz.utils.render.RenderUtil;
import dev.zzz.utils.render.RoundedUtils;
import dev.zzz.utils.render.fontRender.FontManager;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.network.Packet;

import java.awt.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

public class BlockFly extends Module {

    public BlockFly() {
        super("BlockFly", Category.Player);
    }

    private final LinkedList<List<Packet<?>>> queue = new LinkedList();
    public boolean release = false;

    @Override
    public void onDisable() {
        release = false;
        if (!queue.isEmpty()){
            queue.forEach(this::sendTick);
            queue.clear();
        }
        super.onDisable();
    }
    @Override
    public void onEnable() {
        queue.clear();
        queue.add(new ArrayList());
        release = false;
        super.onEnable();
    }
    @EventTarget
    public void onPacket(EventHigherPacketSend e){
        Packet packet = e.getPacket();
        if (PacketUtil.isCPacket(packet)) {

            mc.addScheduledTask(() -> {
                queue.getLast().add(packet);
            });
            e.setCancelled(true);
        }
    }
    @EventTarget
    public void onUpdate(EventTick e){
        queue.add(new ArrayList());
        if (queue.size() >= 20 && !release){
            release = true;
        }
        if (queue.size() <= 5 && release){
            release = false;
        }
        if (release){
            for (int i = 0; i <= 15; i++) {
                sendTick(queue.get(0));
                queue.remove(0);
            }
        }
    }
    private void sendTick(List<Packet<?>> tick) {
        tick.forEach(packet -> {
            mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(packet);
        });
    }
    @EventTarget
    public void onRender2D(EventRender2D e){
       ScaledResolution resolution = new ScaledResolution(mc);
       int x = resolution.getScaledWidth() / 2;
       int y = resolution.getScaledHeight() / 3;
        RoundedUtils.drawRound(x - 100, y - 20, 200, 3, 10, Color.BLACK);
        RoundedUtils.drawRound(x - 100, y - 20, queue.size() * 10, 3, 10, Color.red);
    }
}

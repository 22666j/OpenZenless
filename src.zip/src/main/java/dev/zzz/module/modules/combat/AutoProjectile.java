package dev.zzz.module.modules.combat;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.Client;
import dev.zzz.event.EventTarget;
import dev.zzz.event.world.EventMotion;
import dev.zzz.event.world.EventWorldLoad;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.modules.misc.Teams;
import dev.zzz.module.modules.player.Blink;
import dev.zzz.module.modules.world.Scaffold;
import dev.zzz.module.values.BoolValue;
import dev.zzz.module.values.NumberValue;
import dev.zzz.utils.RayCastUtil;
import dev.zzz.utils.RotationComponent;
import dev.zzz.utils.client.PacketUtil;
import dev.zzz.utils.client.TimeUtil;
import dev.zzz.utils.player.RotationUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemEgg;
import net.minecraft.item.ItemSnowball;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import org.lwjgl.compatibility.util.vector.Vector2f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

@Native

public class AutoProjectile extends Module {
    private final NumberValue dealy = new NumberValue("Delay", 8, 0, 1000, 1);
    private final NumberValue range = new NumberValue("Range",5,1,8,1);
    private final NumberValue Fov = new NumberValue("Fov",90,0,360,1);
    public BoolValue playersValue = new BoolValue("Players", true);
    public BoolValue animalsValue = new BoolValue("Animals", true);
    public BoolValue mobsValue = new BoolValue("Mobs", false);
    public BoolValue invisibleValue = new BoolValue("Invisible", false);
    private final TimeUtil attackTimer = new TimeUtil();
    private final TimeUtil timer = new TimeUtil();
    private int index;

    public static final List<EntityLivingBase> targets = new ArrayList<>();
    public static EntityLivingBase target;

    public AutoProjectile() {
        super("AutoSnowBall", Category.Combat);
    }



    @Override
    public void onEnable() {
        index = 0;
        targets.clear();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        index = 0;
        targets.clear();
        super.onDisable();
    }

    @EventTarget
    public void onWorldEvent(EventWorldLoad event) {
        index = 0;
        targets.clear();
    }

    @EventTarget
    public void onUpdateEvent(EventMotion e) {
        if (e.isPost()) {
            if (Client.instance.moduleManager.getModule(Scaffold.class).getState()||
                    Client.instance.moduleManager.getModule(AutoGapple.class).getState()
                    ||(Client.instance.moduleManager.getModule(KillAura.class).getState() && KillAura.target != null)) {
                return;
            }
            int slot = -1;
            if (getEggSlot() != -1) {
                slot = getEggSlot();
               // System.out.println("33333");
            } else if (getSnowballSlot() != -1) {
                slot = getSnowballSlot();
                //System.out.println("4444");
            }

            if (slot == -1) return;

            findTarget();
            /*if (switchTimer.hasTimeElapsed(dealy.getValue().longValue(), true)) {
                index++;
            }*/
            if (index >= targets.size()) {
                index = 0;
            }

            if (targets.isEmpty()) return;

            target = targets.get(index);

            if (target == null) return;
            if (!mc.thePlayer.canEntityBeSeen(target)) return;

            float[] rotation = RotationUtil.getRotationsNeededBall(target);

            RotationComponent.setRotation(new Vector2f(rotation[0], rotation[1]), 360f, true, false);

            if (RayCastUtil.rayCast(RotationComponent.rotation, range.getValue()).entityHit == null || !attackTimer.hasTimeElapsed(100, true))
                return;
            final int prevSlot = mc.thePlayer.inventory.currentItem;
            if (timer.delay((long) (dealy.getValue() * 10L))) {
                PacketUtil.send(new C09PacketHeldItemChange(slot));
                PacketUtil.send(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()));
                PacketUtil.send(new C09PacketHeldItemChange(prevSlot));
                mc.thePlayer.inventory.currentItem = prevSlot;
                timer.reset();
            }
        }
    }
    private void findTarget() {
        targets.clear();
        for (Entity entity : mc.theWorld.getLoadedEntityList()) {
            if (entity instanceof EntityLivingBase) {
                EntityLivingBase entityLivingBase = (EntityLivingBase) entity;

                if (mc.thePlayer.getDistanceToEntity(entity) <= range.getValue() && shouldAdd(entity) && mc.thePlayer != entityLivingBase ) {
                    targets.add(entityLivingBase);
                   // System.out.println("22222");
                }
            }
        }
        targets.sort(Comparator.comparingDouble(mc.thePlayer::getDistanceToEntity));
    }

    public int getEggSlot() {
        for (int i = 0; i < 9; ++i) {
            if (!mc.thePlayer.inventoryContainer.getSlot(i + 36).getHasStack() || !(mc.thePlayer.inventoryContainer.getSlot(i + 36).getStack().getItem() instanceof ItemEgg))
                continue;
            return i;
        }
        return -1;
    }

    public int getSnowballSlot() {
        for (int i = 0; i < 9; ++i) {
            if (!mc.thePlayer.inventoryContainer.getSlot(i + 36).getHasStack() || !(mc.thePlayer.inventoryContainer.getSlot(i + 36).getStack().getItem() instanceof ItemSnowball))
                continue;
            return i;
        }
        return -1;
    }
    public boolean shouldAdd(Entity target) {
        float entityFov = (float) RotationUtil.getRotationDifference(target);
        float fov = this.Fov.getValue().floatValue();
        Blink blink = Client.instance.moduleManager.getModule(Blink.class);
        double d2 = mc.thePlayer.getDistanceToEntity(target);
        double d3 = this.range.getValue();
        if (d2 > d3) {
            return false;
        }
        if (target.isInvisible() && !this.invisibleValue.getValue()) {
            return false;
        }
        if (!target.isEntityAlive()) {
            return false;
        }
        if (fov != 360.0f && !(entityFov <= fov)) {
            return false;
        }
        if (target == Minecraft.getMinecraft().thePlayer || target.isDead || Minecraft.getMinecraft().thePlayer.getHealth() == 0.0f) {
            return false;
        }
        if ((target instanceof EntityMob || target instanceof EntityGhast || target instanceof EntityGolem || target instanceof EntityDragon || target instanceof EntitySlime) && this.mobsValue.getValue().booleanValue()) {
            return true;
        }
        if ((target instanceof EntitySquid || target instanceof EntityBat || target instanceof EntityVillager) && this.animalsValue.getValue()) {
            return true;
        }
        if (target instanceof EntityAnimal && this.animalsValue.getValue()) {
            return true;
        }
        if (AntiBot.isServerBot(target)) {
            return false;
        }
        if (blink.getState()) {
            return false;
        }
        if (Teams.isSameTeam(target)) {
            return false;
        }
        return target instanceof EntityPlayer && this.playersValue.getValue();
    }
}
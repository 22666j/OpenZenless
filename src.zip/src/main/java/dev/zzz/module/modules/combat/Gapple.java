package dev.zzz.module.modules.combat;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.world.*;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.utils.DebugUtil;
import dev.zzz.utils.client.PacketUtil;
import dev.zzz.utils.player.MovementUtils;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


@Native
public class Gapple extends Module {
    public Gapple(){
        super("AutoGapple", Category.Combat);
    }
    public List<Packet<?>> packets = new ArrayList<>();
    boolean velocityed = true;
    public static boolean eating = false;
    boolean restart = true;
    private int slot = -1;
    int c03s = 0;
    @Override
    public void onEnable() {
        MovementUtils.cancelMove();
        packets.clear();
        c03s = 0;
        velocityed = false;
        this.slot = findItem2(36, 45, Items.golden_apple);
        if (this.slot != -1) {
            this.slot -= 36;
        }

        super.onEnable();
    }

    public static int findItem2(final int startSlot, final int endSlot, final Item item) {
        for (int i = startSlot; i < endSlot; i++) {
            final ItemStack stack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
            if (stack != null && stack.getItem() == item)
                return i;
        }
        return -1;
    }

    @Override
    public void onDisable() {
        eating = false;
        velocityed = false;
        MovementUtils.resetMove();
        blink();
        super.onDisable();
    }

    @EventTarget
    public final void onPacket(EventPacketSend event) {
        Packet<?> packet = event.getPacket();

        if (!PacketUtil.isEssential(packet) && PacketUtil.isCPacket(packet)) {
            event.setCancelled(true);
            packets.add(packet);
        }

        if (packet instanceof C02PacketUseEntity && Objects.requireNonNull(KillAura.getTarget()).hurtTime <= 3) {
            Objects.requireNonNull(KillAura.getTarget());
            send();
        }

        c03s = 0;
        for (Packet<?> index : packets) {
            if (index instanceof C03PacketPlayer) {
                c03s++;
            }
        }
    }
    @EventTarget
    public void onSlowDownEvent(EventSlowDown event) {
        event.setCancelled(false);
        event.setStrafeMultiplier(0.2f);
        event.setForwardMultiplier(0.2f);
    }

    @EventTarget
    public void ontick(EventTick e){
        mc.thePlayer.setSprinting(false);
    }
    @EventTarget
    public final void onUpdate(EventUpdate event) {
        if (mc.thePlayer == null || mc.thePlayer.isDead) {
            this.setState(false);
            return;
        }

        if (this.slot == -1) {
            this.setState(false);
            return;
        }
        DebugUtil.log(c03s);
        if (this.c03s >= 32) {
            c03s = 0;
            if (mc.thePlayer.inventory.currentItem != slot) {
                mc.getNetHandler().addToSendQueueUnregistered(new C09PacketHeldItemChange(slot));
                mc.getNetHandler().addToSendQueueUnregistered(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getStackInSlot(slot)));
                //mc.getConnection().sendPacketNoHigherEvent(new CPacketPlayerDigging(CPacketPlayerDigging.Action.DROP_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
                blink();
                mc.getNetHandler().addToSendQueueUnregistered(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
            } else {
                mc.getNetHandler().addToSendQueueUnregistered(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getStackInSlot(slot)));
                //mc.getConnection().sendPacketNoHigherEvent(new CPacketPlayerDigging(CPacketPlayerDigging.Action.DROP_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
                blink();
            }
            packets.clear();
            this.setState(false);
            restart = true;
            setState(true);
            restart = false;
        }
    }

    @EventTarget
    public final void onWorld(EventWorldLoad event) {
        this.setState(false);
    }

    void send() {
        if (packets.isEmpty())
            return;

        Packet<?> packet = packets.get(0);
        packets.remove(0);
        if (packet instanceof C09PacketHeldItemChange || (packet instanceof C07PacketPlayerDigging && ((C07PacketPlayerDigging) packet).getStatus() == C07PacketPlayerDigging.Action.RELEASE_USE_ITEM)) {
            send();
            return;
        }
        mc.getNetHandler().addToSendQueueUnregistered(packet);
        if (!(packet instanceof C02PacketUseEntity)) {
            send();
        }
    }

    void blink() {
        if (packets.isEmpty())
            return;
        while (!packets.isEmpty()) {
            Packet<?> packet = packets.get(0);
            packets.remove(0);
            if (packet instanceof C09PacketHeldItemChange || (packet instanceof C07PacketPlayerDigging && ((C07PacketPlayerDigging) packet).getStatus() == C07PacketPlayerDigging.Action.RELEASE_USE_ITEM))
                continue;
            mc.getNetHandler().addToSendQueueUnregistered(packet);
        }}
}
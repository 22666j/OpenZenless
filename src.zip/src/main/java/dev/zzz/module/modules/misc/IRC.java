package dev.zzz.module.modules.misc;


import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.gui.notification.NotificationManager;
import dev.zzz.gui.notification.NotificationType;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.values.BoolValue;
import dev.zzz.utils.IrcManager;

import static net.minecraft.block.BlockFurnace.setState;

/**
 * @Author: DreamDev
 * @Date: 2024/11/3
 * Time:14:24
 */
@Native
public class IRC extends Module {
    public static final BoolValue ircfriend = new BoolValue("IRC Friend",true);
    public IRC() {
        super("IRC", Category.Misc);
        setStateSilent(true);
    }

    @Override
    public void onEnable() {
        NotificationManager.post(NotificationType.WARNING,"IRC Module","Use .irc to send messages");
    }
}

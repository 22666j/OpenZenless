package dev.zzz.module.modules.movement;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.world.EventPacketSend;
import dev.zzz.event.world.EventTick;
import dev.zzz.event.world.EventUpdate;
import dev.zzz.gui.clickgui.book.NewClickGui;
import dev.zzz.gui.clickgui.drop.DropdownClickGUI;
import dev.zzz.gui.clickgui.express.NormalClickGUI;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.client.C0DPacketCloseWindow;
import net.minecraft.network.play.client.C16PacketClientStatus;
import org.lwjgl.input.Keyboard;

@Native
public class GuiMove
extends Module {
    private static final List<KeyBinding> keys = Arrays.asList(GuiMove.mc.gameSettings.keyBindForward, GuiMove.mc.gameSettings.keyBindBack, GuiMove.mc.gameSettings.keyBindLeft, GuiMove.mc.gameSettings.keyBindRight, GuiMove.mc.gameSettings.keyBindJump);

    public GuiMove() {
        super("InvMove", Category.Movement);
    }


    private final KeyBinding[] AFFECTED_BINDINGS = new KeyBinding[]{
            mc.gameSettings.keyBindForward,
            mc.gameSettings.keyBindBack,
            mc.gameSettings.keyBindRight,
            mc.gameSettings.keyBindLeft,
            mc.gameSettings.keyBindJump
    };

    @EventTarget
    public void onMotion(EventTick event) {
        if (GuiMove.mc.currentScreen instanceof GuiContainer || GuiMove.mc.currentScreen instanceof NormalClickGUI || GuiMove.mc.currentScreen instanceof DropdownClickGUI || GuiMove.mc.currentScreen instanceof NewClickGui) {

            for (final KeyBinding bind : AFFECTED_BINDINGS) {
                bind.setPressed(GameSettings.isKeyDown(bind));
            }
        }
    }
}


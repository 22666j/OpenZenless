package dev.zzz.module.modules.render;

import dev.zzz.event.EventTarget;
import dev.zzz.event.rendering.EventRender3D;
import dev.zzz.event.world.EventUpdate;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.modules.combat.KillAura;
import dev.zzz.module.values.ColorValue;
import dev.zzz.utils.player.CopyOfPlayer;
import dev.zzz.utils.player.EntityUtil;
import dev.zzz.utils.render.RenderUtil;
import net.minecraft.entity.player.EntityPlayer;

import java.awt.*;

public class TargetRender extends Module {
    public TargetRender(){
        super("TargetSharder", Category.Render);
    }
    private final ColorValue boxColor = new ColorValue("Color", new Color(0, 200, 200, 80).getRGB());
    private CopyOfPlayer entity;

    @EventTarget
    public void lll(EventRender3D e){
        if (KillAura.target != null) {
            if (KillAura.target.moveForward != 0 || KillAura.target.moveStrafing != 0) {
                RenderUtil.renderPlayerModel(entity, this.boxColor.getColorC(), null, 2);
            }
        }
    }
    @EventTarget
    public void cnm(EventUpdate e){
        if (KillAura.target != null) {
        this.entity = new CopyOfPlayer(EntityUtil.getCopiedPlayer((EntityPlayer) KillAura.target), 2, mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, mc.thePlayer.getSkinType().equals("slim"));
        }
    }
}

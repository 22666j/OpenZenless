package dev.zzz.module.modules.combat;

import java.util.ArrayList;
import java.util.List;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.world.EventJump;
import dev.zzz.event.world.EventMotion;
import dev.zzz.event.world.EventStrafe;
import dev.zzz.event.world.EventUpdate;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.modules.misc.IRC;
import dev.zzz.module.values.NumberValue;
import dev.zzz.utils.IrcManager;
import dev.zzz.utils.TimerUtil;
import dev.zzz.utils.client.PacketUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemEgg;
import net.minecraft.item.ItemSnowball;
import net.minecraft.network.play.client.C09PacketHeldItemChange;


public class AutoSnowball extends Module {
    private final NumberValue Range = new NumberValue("Range", 10.0, 0.0, 30.0, 1.0);
    private final NumberValue delay = new NumberValue("Delay", 1.0, 0.0, 10.0, 1.0);
    private final NumberValue number = new NumberValue("Number", 1.0, 0.0, 16.0, 1.0);
    private final NumberValue Handoff = new NumberValue("HandoffDelay", 100.0, 0.0, 1000.0, 10.0);
    private final NumberValue fov = new NumberValue("FOV", 90.0, 0.0, 180.0, 10.0);
    private final TimerUtil switchTimer = new TimerUtil();
    int index;
    private float yaw;
    private float pitch;
    private final List<EntityPlayer> targets = new ArrayList<>();
    private TimerUtil timer = new TimerUtil();
    private EntityPlayer target;

    public AutoSnowball() {
        super("AutoSnowball", Category.Combat);
    }

    @Override
    public void onEnable() {
        this.yaw = mc.thePlayer.rotationYaw;
        this.pitch = mc.thePlayer.rotationPitch;
        this.index = 0;
        this.switchTimer.reset();
        this.targets.clear();
        this.target = null;
    }

    @Override
    public void onDisable() {
        this.yaw = mc.thePlayer.rotationYaw;
        this.pitch = mc.thePlayer.rotationPitch;
        this.index = 0;
        this.switchTimer.reset();
        this.targets.clear();
        this.target = null;
    }

    @EventTarget
    private void onMotion(EventMotion eventMotion) {
        if (IRC.ircfriend.isEnabled()&& IrcManager.transport.isUser(target.getName()))return;
        if (eventMotion.isPre()) {
            long te = this.delay.getValue().longValue() * 50L;
            if (this.target != null
                    && (
                    this.target.getHealth() <= 0.0F
                            || this.target.isDead
                            || mc.thePlayer.getDistance(this.target.posX, this.target.posY, this.target.posZ) > this.Range.getValue()
                            || mc.thePlayer.getDistance(this.target.posX, this.target.posY, this.target.posZ) <= 4.0
            )) {
                this.target = null;
            }

            if (this.target != null && (this.getEgg() < 0 || !this.isVisibleFOV(this.target, (float)this.fov.getValue().intValue()))) {
                this.target = null;
            }

            List<EntityPlayer> targets = this.getTargets();
            if (this.targets.size() > 1 && this.switchTimer.hasTimeElapsed((long)this.Handoff.getValue().intValue())) {
                this.switchTimer.reset();
                this.index++;
            }

            if (this.index >= this.targets.size()) {
                this.index = 0;
            }

            if (!targets.isEmpty()) {
                this.target = targets.get(this.index);
            }
        }
    }

    @EventTarget
    private void onUpdate(EventUpdate eventUpdate) {
        if (this.target != null) {
            this.calculateRotation(this.target);
            this.yaw = this.calculateRotation(this.target)[0];
            this.pitch = this.calculateRotation(this.target)[1];
        }

        if (this.target != null && (double)this.target.getDistanceToEntity(mc.thePlayer) <= this.Range.getValue() && mc.thePlayer.onGround) {
            if (this.target.getDistanceToEntity(mc.thePlayer) >= 8.0F && this.target.getDistanceToEntity(mc.thePlayer) <= 12.0F) {
                this.pitch -= 3.0F;
            } else if (this.target.getDistanceToEntity(mc.thePlayer) >= 13.0F && this.target.getDistanceToEntity(mc.thePlayer) <= 17.0F) {
                this.pitch -= 5.0F;
            } else if (this.target.getDistanceToEntity(mc.thePlayer) >= 18.0F && this.target.getDistanceToEntity(mc.thePlayer) <= 24.0F) {
                this.pitch -= 8.0F;
            } else if (this.target.getDistanceToEntity(mc.thePlayer) >= 25.0F && (double)this.target.getDistanceToEntity(mc.thePlayer) <= this.Range.getValue()) {
                this.pitch -= 11.0F;
            }
        }

        if (this.target == null) {
            this.yaw = mc.thePlayer.rotationYaw;
            this.pitch = mc.thePlayer.rotationPitch;
        }
    }

    @EventTarget
    private void onStrafe(EventStrafe eventStrafe) {
        if (this.target != null) {
            eventStrafe.setYaw(this.yaw);
        }
    }

    @EventTarget
    private void onJump(EventJump eventJump) {
        if (this.target != null) {
            eventJump.setYaw(this.yaw);
        }
    }

    private List<EntityPlayer> getTargets() {
        this.targets.clear();

        for (Entity entity : mc.theWorld.loadedEntityList) {
            if (entity instanceof EntityPlayer) {
                EntityPlayer sb = (EntityPlayer)entity;
                if ((double)sb.getDistanceToEntity(mc.thePlayer) <= this.Range.getValue()
                        && sb.getDistanceToEntity(mc.thePlayer) >= 4.0F
                        && sb != mc.thePlayer
                        && this.getEgg() > 0
                        && this.isVisibleFOV(sb, (float)this.fov.getValue().intValue())) {
                    this.targets.add((EntityPlayer)entity);
                }
            }
        }

        return this.targets;
    }

    private void throwing() {
        PacketUtil.send(new C09PacketHeldItemChange(this.getEgg()));
        PacketUtil.send(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
    }

    public int getEgg() {
        for (int i = 0; i < 9; i++) {
            if (mc.thePlayer.inventoryContainer.getSlot(i + 36).getHasStack()
                    && mc.thePlayer.inventoryContainer.getSlot(i + 36).getStack().getItem() instanceof ItemSnowball && mc.thePlayer.inventoryContainer.getSlot(i + 36).getStack().getItem() instanceof ItemEgg) {
                return i;
            }
        }

        return -1;
    }

    private float[] calculateRotation(EntityPlayer player) {
        double deltaX = player.posX - mc.thePlayer.posX;
        double deltaY = player.posY + (double)player.getEyeHeight() - (mc.thePlayer.posY + (double)mc.thePlayer.getEyeHeight());
        double deltaZ = player.posZ - mc.thePlayer.posZ;
        double yaw = Math.atan2(deltaZ, deltaX) * (180.0 / Math.PI) - 90.0;
        double pitch = -Math.atan2(deltaY, Math.sqrt(deltaX * deltaX + deltaZ * deltaZ)) * (180.0 / Math.PI);
        return new float[]{(float)yaw, (float)pitch};
    }

    private boolean isVisibleFOV(EntityPlayer e, float fov) {
        return (
                Math.abs(this.calculateRotation(e)[0] - mc.thePlayer.rotationYaw) % 360.0F > 180.0F
                        ? 360.0F - Math.abs(this.calculateRotation(e)[0] - mc.thePlayer.rotationYaw) % 360.0F
                        : Math.abs(this.calculateRotation(e)[0] - mc.thePlayer.rotationYaw) % 360.0F
        )
                <= fov;
    }
}

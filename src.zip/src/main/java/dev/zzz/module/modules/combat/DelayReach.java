package dev.zzz.module.modules.combat;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.world.EventHigherPacketSend;
import dev.zzz.event.world.EventPacketReceive;
import dev.zzz.event.world.EventPacketSend;
import dev.zzz.event.world.EventTick;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.utils.client.ChatUtil;
import dev.zzz.utils.client.PacketUtil;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C0APacketAnimation;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@Native
public class DelayReach extends Module {
    public DelayReach(){
        super("BestReach", Category.Combat);
    }
    private boolean cancel = false;
    private LinkedList<List<Packet<?>>> packets = new LinkedList<>();
    @EventTarget
    public void onHigherPacket(EventPacketSend event){
        if (event.getPacket() instanceof C02PacketUseEntity c02){
           // if (Velocity.entity == null) {
                if (mc.thePlayer.hurtTime >= 10) {
                    mc.addScheduledTask(() -> {
                        if (packets.isEmpty()) {
                            packets.add(new LinkedList<Packet<?>>());
                        }
                        packets.getLast().add(c02);
                    });
                    event.setCancelled(true);
                }
          //  }
        }
        if (event.getPacket() instanceof C0APacketAnimation c0a){
            //if (Velocity.entity == null) {
                if (mc.thePlayer.hurtTime >= 10) {
                    mc.addScheduledTask(() -> {
                        if (packets.isEmpty()) {
                            packets.add(new LinkedList<Packet<?>>());
                        }
                        packets.getLast().add(c0a);
                    });
                    event.setCancelled(true);
                }
            //}
        }
        if (event.getPacket() instanceof C03PacketPlayer){
            if (cancel) {
                event.setCancelled(true);
            }

        }
    }
    @EventTarget
    public void onHigherPacket(EventPacketReceive event){
        if (event.getPacket() instanceof C03PacketPlayer){
            if (cancel) {
                event.setCancelled(true);
            }

        }
    }
    @EventTarget
    private void onTick(EventTick event) {
        if (mc.thePlayer == null) return;
        if (KillAura.target == null) {
            if (mc.thePlayer.ticksExisted % 5 == 0) {
                if (mc.thePlayer.hurtTime <= 1) {
                    if (Keyboard.isKeyDown(2)) {
                        packets.add(new ArrayList<>());
                        if (packets.isEmpty()) return;
                        this.sendTick(packets.getFirst());
                        packets.removeFirst();
                    }
                }
            }
        }
    }
    private void sendTick(List<Packet<?>> tick) {
        if (mc.getNetHandler() != null) {
            tick.forEach(packet -> {
                cancel = true;
                PacketUtil.send(packet);
                cancel = false;
                //mc.theWorld.skiptick++;
                ChatUtil.print("Send");

            });
        }
    }
}

package dev.zzz.module.modules.movement;

import com.viaversion.viarewind.protocol.protocol1_8to1_9.Protocol1_8To1_9;
import com.viaversion.viaversion.api.Via;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.misc.EventRightClick;
import dev.zzz.event.world.EventMotion;
import dev.zzz.event.world.EventPacketReceive;
import dev.zzz.event.world.EventPacketSend;
import dev.zzz.event.world.EventSlowDown;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.modules.combat.AutoGapple;
import dev.zzz.module.modules.combat.Gapple;
import dev.zzz.module.modules.combat.KillAura;
import dev.zzz.module.modules.world.GApple;
import dev.zzz.module.values.BoolValue;
import dev.zzz.module.values.ModeValue;
import dev.zzz.utils.client.PacketUtil;
import dev.zzz.utils.client.TimeUtil;
import java.util.Arrays;
import java.util.List;

import dev.zzz.utils.item.ItemUtils;
import dev.zzz.utils.player.MoveUtil;
import dev.zzz.utils.player.PlayerUtil;
import io.netty.buffer.Unpooled;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.item.*;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.*;
import net.minecraft.network.play.server.S2FPacketSetSlot;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;

@Native
public class NoSlow
        extends Module {
    public final List<Integer> blacklist = Arrays.asList(54, 146, 61, 62);
    boolean slow;
    boolean canCanCelC08;
    TimeUtil timer = new TimeUtil();
    long delay = 100L;
    boolean fasterDelay;
    private boolean disable;
    private final ModeValue<NoSlowMode> mode = new ModeValue("Mode", NoSlowMode.values(), NoSlowMode.Vanilla);
    public static final BoolValue blockingDamageAmountDebug = new BoolValue("BlockingDamageAmountDebug", false);
    private boolean sent = false;
    private final BoolValue food = new BoolValue("Food", true);
    private final BoolValue bow = new BoolValue("Bow", true);
    private boolean hasDroppedFood = false;
    public static boolean fix = false;

    public NoSlow() {
        super("NoSlow", Category.Movement);
    }

    @Override
    public void onEnable() {
        this.sent = false;
    }

    private boolean shouldCancelPlacement(MovingObjectPosition objectPosition) {
        return !this.blacklist.contains(Block.getIdFromBlock(NoSlow.mc.theWorld.getBlockState(objectPosition.getBlockPos()).getBlock()));
    }

    private boolean isHoldingPotionAndSword(ItemStack stack, boolean checkSword, boolean checkFood, boolean checkPotion, boolean checkBow) {
        return PlayerUtil.isHoldingPotionAndSword(stack, checkSword, checkFood, checkPotion, checkBow);
    }

    @EventTarget
    public void onSlowDown(EventSlowDown e) {
        if(AutoGapple.eating || Gapple.eating || GApple.eating){
            mc.thePlayer.setSprinting(false);
            return;
        }
        if (this.mode.is("Watchdog")) {
            if (mc.thePlayer == null || mc.theWorld == null || mc.thePlayer.getHeldItem() == null) return;
            if (mc.thePlayer.getHeldItem().getItem() instanceof ItemFood && mc.thePlayer.isUsingItem()) {
                e.setCancelled(true);
                if (!mc.thePlayer.isSprinting() && !mc.thePlayer.isSneaking() && MoveUtil.isMoving()) {
                    mc.thePlayer.setSprinting(true);
                }
            }
        }
        if (this.mode.is("Grim")) {
            if (mc.thePlayer == null || mc.theWorld == null || mc.thePlayer.getHeldItem() == null) return;
            if (mc.thePlayer.getHeldItem().getItem() instanceof ItemFood && food.isEnabled()) return;
            if (mc.thePlayer.getHeldItem() != null && (mc.thePlayer.getHeldItem().getItem() instanceof ItemSword
                    || (mc.thePlayer.getHeldItem().getItem() instanceof ItemBow && bow.isEnabled())) && mc.thePlayer.isUsingItem())
                e.setCancelled(true);
            if (!mc.thePlayer.isSprinting() && !mc.thePlayer.isSneaking() && MoveUtil.isMoving()) {
                mc.thePlayer.setSprinting(true);
            }
        }
    }

    public static boolean hasSwordwithout() {
        return  Minecraft.getMinecraft().thePlayer.getHeldItem().getItem() instanceof ItemSword;
    }

    @EventTarget
    public void onUpdate(EventMotion e) {
        if (AutoGapple.eating){
            return;
        }
        this.setSuffix(this.mode.getValue().toString());
        switch ((NoSlowMode) this.mode.getValue()) {
            case Grim: {
                if  (!mc.isSingleplayer()) {
                    if (e.isPre()) {
                        if (mc.thePlayer == null || mc.theWorld == null || mc.thePlayer.getHeldItem() == null) return;
                        ItemStack itemInHand = mc.thePlayer.getCurrentEquippedItem();
                        ItemStack itemStack = mc.thePlayer.getHeldItem();
                        int itemID = Item.getIdFromItem(itemInHand.getItem());
                        int itemMeta = itemInHand.getMetadata();
                        String itemId = itemInHand.getItem().getUnlocalizedName();
                        if(mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemFood && food.isEnabled()) {
                            if (mc.thePlayer.getHeldItem() != null && (!((itemID == 322 && itemMeta == 1) || itemId.equals("item.appleGoldEnchanted")))) {
                                if (Minecraft.getMinecraft().thePlayer.inventory.getCurrentItem() != null) {

                                    if (Minecraft.getMinecraft().thePlayer.getCurrentEquippedItem().getItem() instanceof ItemBlock) {
                                        Minecraft.getMinecraft().rightClickDelayTimer = 4;
                                    } else {
                                        Minecraft.getMinecraft().rightClickDelayTimer = 4;
                                    }
                                }
                                if (mc.thePlayer.isUsingItem() && !hasDroppedFood  && itemStack.stackSize > 1) {
                                    mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.DROP_ITEM, new BlockPos(0, 0, 0), EnumFacing.DOWN));
                                    hasDroppedFood = true;
                                    fix =true;
                                } else if (!mc.thePlayer.isUsingItem()) {
                                    hasDroppedFood = false;
                                    new Thread(() -> {try {Thread.sleep(500); fix =false;} catch (InterruptedException ex) {ex.printStackTrace();}}).start();

                                }
                            }
                        }else {
                            fix =false;
                        }
                        if (Minecraft.getMinecraft().thePlayer.inventory.getCurrentItem() != null) {
                            if ((mc.thePlayer.isBlocking()) ||mc.thePlayer.isUsingItem() && hasSwordwithout()) {
                                mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, new BlockPos(0, 0, 0), EnumFacing.DOWN));
                                //mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange((mc.thePlayer.inventory.currentItem + 1) % 9));
                                //mc.getNetHandler().addToSendQueue(new C17PacketCustomPayload("MadeByFire", new PacketBuffer(Unpooled.buffer())));
                                //mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
                            }
                            if (mc.thePlayer.getHeldItem().getItem() instanceof ItemBow && mc.thePlayer.isUsingItem() && bow.isEnabled() && !mc.thePlayer.isSneaking()) {
                                mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange((mc.thePlayer.inventory.currentItem + 1) % 9));
                                mc.getNetHandler().addToSendQueue(new C17PacketCustomPayload("MadeByFire", new PacketBuffer(Unpooled.buffer())));
                                mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
                            }
                        }
                    }
                    if (e.isPost()) {
                        if (mc.thePlayer.getHeldItem() == null) return;
                        if (mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword && mc.thePlayer.isUsingItem()) {
                            //if (AutoGapple.eating){
                            mc.getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement());
                            //}else {
                            //PacketWrapper useItem = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                            //useItem.write(Type.VAR_INT, 1);
                            //PacketUtil.sendToServer(useItem, Protocol1_8To1_9.class, true, true);
                            //PacketWrapper useItem2 = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                            // useItem2.write(Type.VAR_INT, 0);
                            // PacketUtil.sendToServer(useItem2, Protocol1_8To1_9.class, true, true);
                            // }
                        }
                        if (mc.thePlayer.getHeldItem().getItem() instanceof ItemBow && mc.thePlayer.isUsingItem() && bow.isEnabled()) {
                            PacketWrapper useItem = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                            useItem.write(Type.VAR_INT, 1);
                            PacketUtil.sendToServer(useItem, Protocol1_8To1_9.class, true, true);
                            PacketWrapper useItem2 = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                            useItem2.write(Type.VAR_INT, 0);
                            PacketUtil.sendToServer(useItem2, Protocol1_8To1_9.class, true, true);
                        }
                    }
                }
                break;
            }
            case Watchdog: {
                if (e.isPre()) {
                    double d2;
                    if (PlayerUtil.blockRelativeToPlayer(0.0, mc.thePlayer.motionY, 0.0) != Blocks.air && !mc.thePlayer.isUsingItem()) {
                        this.disable = false;
                    }
                    if (Math.abs((d2 = e.getY()) - (double)Math.round(d2)) > 0.03 && mc.thePlayer.onGround) {
                        this.disable = true;
                    }
                    if (mc.thePlayer.isUsingItem() && !(mc.thePlayer.getHeldItem().getItem() instanceof ItemSword)) {
                        if (mc.thePlayer.offGroundTicks >= 2) {

                        } else if (mc.thePlayer.onGround && !this.disable) {
                            e.setY(e.getY() + 0.001);
                        }
                    }
                    if (this.disable && !mc.thePlayer.onGround && mc.thePlayer.isUsingItem() && !(mc.thePlayer.getHeldItem().getItem() instanceof ItemSword)) {
                        mc.thePlayer.motionX *= 0.1;
                        mc.thePlayer.motionZ *= 0.1;
                    }
                }
                break;
            }
            case OldGrim: {
                /*if (!e.isPre() || !NoSlow.mc.thePlayer.isUsingItem() && !KillAura.isBlocking || !this.isHoldingPotionAndSword(NoSlow.mc.thePlayer.getHeldItem(), true, true)) break;
                PacketUtil.send(new C09PacketHeldItemChange(NoSlow.mc.thePlayer.inventory.currentItem % 8 + 1));
                PacketUtil.send(new C09PacketHeldItemChange(NoSlow.mc.thePlayer.inventory.currentItem));*/
                break;
            }
            case AAC4:
            case Packet: {
                if (e.isPre() && (NoSlow.mc.thePlayer.isUsingItem() || KillAura.isBlocking)) {
                    PacketUtil.send(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
                }
                if (!e.isPost() || !NoSlow.mc.thePlayer.isUsingItem() && !KillAura.isBlocking) break;
                NoSlow.mc.playerController.sendUseItem(NoSlow.mc.thePlayer, NoSlow.mc.theWorld, NoSlow.mc.thePlayer.getHeldItem(), false);
                break;
            }
            case Intave: {
                /*if (e.isPre() && (NoSlow.mc.thePlayer.isUsingItem() || KillAura.isBlocking) && this.isHoldingPotionAndSword(NoSlow.mc.thePlayer.getHeldItem(), true, false)) {
                    PacketUtil.send(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
                }
                if (!e.isPost() || !NoSlow.mc.thePlayer.isUsingItem() && !KillAura.isBlocking || !this.isHoldingPotionAndSword(NoSlow.mc.thePlayer.getHeldItem(), true, false) || !this.timer.hasTimeElapsed(this.delay)) break;
                PacketUtil.send(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
                this.delay = this.fasterDelay ? 100L : 200L;
                this.fasterDelay = !this.fasterDelay;
                this.timer.reset();
                break;*/
            }
            case AAC5: {
                if (!e.isPost() || !NoSlow.mc.thePlayer.isUsingItem() && !KillAura.isBlocking) break;
                NoSlow.mc.playerController.sendUseItem(NoSlow.mc.thePlayer, NoSlow.mc.theWorld, NoSlow.mc.thePlayer.getHeldItem(), false);
            }
        }
    }
    @EventTarget
    public void onRightClickBlock(EventRightClick event) {
        if (mode.getValue() == NoSlowMode.Watchdog) {
            if (mc.thePlayer.getHeldItem() == null) {
                return;
            }
            if (mc.thePlayer.isUsingItem() || mc.thePlayer.getHeldItem().getItem() instanceof ItemPotion && !ItemPotion.isSplash(mc.thePlayer.getHeldItem().getMetadata()) || mc.thePlayer.getHeldItem().getItem() instanceof ItemFood || mc.thePlayer.getHeldItem().getItem() instanceof ItemBow) {
                if (mc.thePlayer.offGroundTicks < 2 && mc.thePlayer.offGroundTicks != 0 && !this.disable) {
                    event.setCancelled();
                } else if (mc.thePlayer.onGround) {
                    mc.thePlayer.jump();
                    event.setCancelled();
                }
            }
        }
    }
    /*
    @EventTarget
    private void onPacketReceived(EventPacketReceive event) {
        final Packet<?> packet = event.getPacket();
        if (mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemFood) {
            if (packet instanceof S2FPacketSetSlot) {
                S2FPacketSetSlot s2f = (S2FPacketSetSlot) packet;
                if (s2f.getWindowId() == 0 && s2f.func_149174_e() != null && mc.thePlayer.getHeldItem() != null && s2f.func_149174_e().getItem() == mc.thePlayer.getHeldItem().getItem()) {
                    mc.thePlayer.getHeldItem().stackSize = s2f.func_149174_e().stackSize;
                    event.setCancelled();
                }
            }
        }
    }

     */
    @EventTarget
    public void onPacketSend(EventPacketSend event) {
        if (AutoGapple.eating){
            return;
        }
        final Packet<?> packet = event.getPacket();
        if (mc.thePlayer == null || mc.isSingleplayer() || event.isCancelled() || AutoGapple.eating) return;
        if (packet instanceof C07PacketPlayerDigging) {
            C07PacketPlayerDigging digging = (C07PacketPlayerDigging) packet;
            if (digging.getStatus() == C07PacketPlayerDigging.Action.RELEASE_USE_ITEM && mc.thePlayer.getHeldItem().stackSize >= 2) {
                event.setCancelled();
            }
        }
    }

    enum NoSlowMode {
        Vanilla,
        OldGrim,
        Grim,
        Packet,
        AAC5,
        AAC4,
        Watchdog,
        Intave

    }
}


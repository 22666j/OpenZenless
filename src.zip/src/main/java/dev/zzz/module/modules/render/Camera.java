package dev.zzz.module.modules.render;

import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.values.BoolValue;
import dev.zzz.module.values.NumberValue;

public final class Camera
extends Module {
    public final BoolValue cameraClipValue = new BoolValue("CameraClip", false);
    public final BoolValue noHurtCameraValue = new BoolValue("NoHurtCamera", false);
    public final BoolValue betterBobbingValue = new BoolValue("BetterBobbing", false);
    public final NumberValue interpolation = new NumberValue("Motion Interpolation", 0.01f, 0.01f, 0.4f, 0.01f);
    public final BoolValue noFovValue = new BoolValue("NoFov", false);
    public final NumberValue fovValue = new NumberValue("Fov", 1.0, 0.0, 4.0, 0.1);

    public Camera() {
        super("Camera", Category.Render);
    }
}


package dev.zzz.module.modules.combat;


import com.diaoling.client.viaversion.vialoadingbase.ViaLoadingBase;
import com.sun.jdi.BooleanValue;


import com.viaversion.viarewind.protocol.protocol1_8to1_9.Protocol1_8To1_9;
import com.viaversion.viarewind.utils.PacketUtil;
import com.viaversion.viaversion.api.Via;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.misc.MoveMathEvent;
import dev.zzz.event.rendering.EventRender2D;
import dev.zzz.event.world.*;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.values.BoolValue;
import dev.zzz.module.values.NumberValue;
import dev.zzz.utils.TimeHelper;
import dev.zzz.utils.client.ChatUtil;
import dev.zzz.utils.client.StopWatch;
import dev.zzz.utils.render.GLUtil;
import dev.zzz.utils.render.RenderUtil;
import dev.zzz.utils.render.RoundedUtils;
import dev.zzz.utils.render.StencilUtil;
import dev.zzz.utils.render.animation.Animation;
import dev.zzz.utils.render.animation.Direction;
import dev.zzz.utils.render.animation.impl.ContinualAnimation;
import dev.zzz.utils.render.animation.impl.DecelerateAnimation;
import dev.zzz.utils.render.fontRender.FontManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.item.ItemAppleGold;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.handshake.client.C00Handshake;
import net.minecraft.network.login.client.C00PacketLoginStart;
import net.minecraft.network.login.client.C01PacketEncryptionResponse;
import net.minecraft.network.play.client.*;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.status.client.C00PacketServerQuery;
import net.minecraft.network.status.client.C01PacketPing;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.text.DecimalFormat;
import java.util.concurrent.LinkedBlockingQueue;

@Native
public class AutoGapple extends Module {
    private final NumberValue delay = new NumberValue("Delay", 1000, 0,10000,  100);
    private final NumberValue r = new NumberValue("ReleaseTick", 3, 1,6,  1);
   // private final NumberValue health = new NumberValue("Health", 15, 0,20,  0.5);
    private final BoolValue noMove = new BoolValue("Stop move when eating", false);
    private final BoolValue autoClose = new BoolValue("Close when no gapple", true);
    private final BoolValue lagValue = new BoolValue("Stuck in air", false);
   // private final BoolValue notification = new BoolValue("Notification", false);
    private final StopWatch stopWatch = new StopWatch();
    private final TimeHelper ms = new TimeHelper();
    public static boolean eating = false;
    private int movingPackets = 0;
    private int slot = 0;
    private final ContinualAnimation animation = new ContinualAnimation();
    private final LinkedBlockingQueue<Packet<?>> packets = new LinkedBlockingQueue<>();
    private boolean needSkip = false;

    public AutoGapple() {
        super("Gapple", Category.Combat);
    }


    @Override
    public void onEnable() {
        dev.zzz.utils.client.PacketUtil.sendPacketNoEvent(new C08PacketPlayerBlockPlacement(KillAura.mc.thePlayer.inventory.getCurrentItem()));
//        PacketWrapper useItem_1_9 = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
//        useItem_1_9.write((Type)Type.VAR_INT, (Object)1);
//        PacketUtil.sendToServer(useItem_1_9, Protocol1_8To1_9.class, true, true);

        mc.theWorld.skiptick = 0;
        ms.reset();
        packets.clear();
        slot = -1;
        needSkip = false;
        movingPackets = 0;
        eating = false;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        mc.theWorld.skiptick = 0;
        ms.reset();
        eating = false;
        release();
        super.onDisable();
    }

    @EventTarget
    public void onWorldEvent(EventWorldLoad event) {
        eating = false;
        release();

    }

    @EventTarget
    public void onMoveMathEvent(MoveMathEvent event) {
        if (eating && lagValue.getConfigValue() && mc.thePlayer.positionUpdateTicks < 20) event.setCancelled(true);
    }
    @EventTarget
    public void onpostUpdateEvent(EventPostUpdate event) {
        //if (packet instanceof C03PacketPlayer)
           // movingPackets++;
    }
    @EventTarget
    public void onMotionEvent(EventTick event) {
        mc.thePlayer.setSprinting(false);


            if (eating) {
                movingPackets++;
                packets.add(new C01PacketChatMessage("release"));
            }



        //if (event.isPre()) {

            if (mc.thePlayer == null || !mc.thePlayer.isEntityAlive()) {
                eating = false;
                packets.clear();

                return;
            }

            if (!mc.playerController.getCurrentGameType().isSurvivalOrAdventure() || !stopWatch.finished(delay.getValue().intValue())) {
                eating = false;
                release();

                return;
            }

            slot = getGApple();

            //if (slot == -1 || mc.thePlayer.getHealth() >= health.getValue().floatValue()) {
            if (slot == -1) {
                if (eating) {
                    eating = false;
                    release();
                }
            } else {
                eating = true;
                int ticks = 0;
                if (movingPackets >= 32) {
                    mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(new C09PacketHeldItemChange(slot));
//                mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.inventory.getStackInSlot(slot));
                    mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getStackInSlot(slot)));
                    mc.thePlayer.itemInUseCount -= 36;
                    release();
                    mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
                    dev.zzz.utils.client.PacketUtil.sendPacketNoEvent(new C08PacketPlayerBlockPlacement(KillAura.mc.thePlayer.inventory.getCurrentItem()));
                    stopWatch.reset();
                    ChatUtil.print(ms.getElapsedTime()+"ms^^");
                    ms.reset();

                } else if (mc.thePlayer.ticksExisted % r.getValue().intValue() == 0) {
                    while (!packets.isEmpty()) {
                     //   final Packet<?> packet = packets.poll();
                        final Packet<?> packet = packets.peek();

                        if (packet instanceof C01PacketChatMessage) {
                            break;
                        }



                            mc.getNetHandler().addToSendQueueUnregistered(packet);
                            packets.poll();
                       // mc.getNetHandler().addToSendQueueUnregistered(packet);
                        //if (packet instanceof C08PacketPlayerBlockPlacement) {
                           // if (ViaLoadingBase.getInstance().getTargetVersion().getVersion() > 47) {
                                //PacketWrapper useItem = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                                //useItem.write(Type.VAR_INT, 1);
                                //PacketUtil.sendToServer(useItem, Protocol1_8To1_9.class, true, true);
                            //}
                        //}
                    }
                }
                  ChatUtil.print("[Gapple] "+ movingPackets);
            }

       // }
    }

    @EventTarget
    public void onPacketSendEvent(EventPacketSend event) {

        if (mc.thePlayer == null || !mc.playerController.getCurrentGameType().isSurvivalOrAdventure()) return;

        final Packet<?> packet = event.getPacket();

        if (event.getPacket() instanceof C07PacketPlayerDigging c07 && c07.getStatus().equals(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM)) {
            event.setCancelled();
        }

        if (packet instanceof C00Handshake || packet instanceof C00PacketLoginStart ||
                packet instanceof C00PacketServerQuery || packet instanceof C01PacketPing ||
                packet instanceof C01PacketEncryptionResponse || packet instanceof C01PacketChatMessage) {
            return;
        }

        if (!(packet instanceof C09PacketHeldItemChange) && !(packet instanceof C0EPacketClickWindow) && !(packet instanceof C16PacketClientStatus) && !(packet instanceof C0DPacketCloseWindow)) {
            if (eating) {
                event.setCancelled();

                packets.add(packet);
                if (packet instanceof C03PacketPlayer)
                    movingPackets++;
            }
        }
    }
    @EventTarget
    public void onRender2D(EventRender2D event) {
    }
    @EventTarget
    public void onPacketReceiveEvent(EventPacketReceive event) {
        final Packet<?> packet = event.getPacket();

        if (packet instanceof S12PacketEntityVelocity wrapped) {

            if (wrapped.getEntityID() == mc.thePlayer.getEntityId())
                needSkip = true;
        }
    }

    @EventTarget
    public void onSlowDownEvent(EventSlowDown event) {
        if (eating) {
            event.setCancelled(false);
            event.setStrafeMultiplier(0.2f);
            event.setForwardMultiplier(0.2f);
        }
    }

    @EventTarget
    public void onEventMoveInput(EventMoveInput event) {
        //if (noMove.isEnabled() && eating) {
          //  event.setForward(0);
         //   event.setStrafe(0);
       // }
    }

    private void release() {
        if (mc.getNetHandler() == null) return;

        while (!packets.isEmpty()) {
            final Packet<?> packet = packets.poll();

            if (packet instanceof C01PacketChatMessage || packet instanceof C08PacketPlayerBlockPlacement || packet instanceof C07PacketPlayerDigging)
                continue;

            mc.getNetHandler().addToSendQueueUnregistered(packet);
        }

        movingPackets = 0;
    }

    private int getGApple() {
        for (int i = 0;i < 9;i++) {
            final ItemStack stack = mc.thePlayer.inventory.getStackInSlot(i);

            if (stack == null)
                continue;

            if (stack.getItem() instanceof ItemAppleGold) {
                return i;
            }
        }

        if (autoClose.isEnabled())
            this.toggle();

        return -1;
    }


/*
            if (mc.thePlayer instanceof AbstractClientPlayer) {
                float renderHurtTime = (float)mc.thePlayer.hurtTime - (mc.thePlayer.hurtTime != 0 ? Minecraft.getMinecraft().timer.renderPartialTicks : 0.0f);
                float hurtPercent1 = renderHurtTime / 10.0f;
                GL11.glColor4f((float)1.0f, (float)(1.0f - hurtPercent1), (float)(1.0f - hurtPercent1), (float)1.0f);
                GL11.glPushMatrix();
                this.drawBigHeadRound2(mc.displayWidth / 5f,100, 32.0f, 32.0f, (AbstractClientPlayer)mc.thePlayer);
                GL11.glPopMatrix();
            }
        }


    }/*
    protected void drawBigHead(float x2, float y2, float width, float height, AbstractClientPlayer player) {
        double offset = -(player.hurtTime * 23);
        RenderUtil.glColor(new Color(255, (int)(255.0 + offset), (int)(255.0 + offset)).getRGB());
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(770, 771);
        mc.getTextureManager().bindTexture(player.getLocationSkin());
        Gui.drawScaledCustomSizeModalRect(x2, y2, 8.0f, 8.0f, 8, 8, width, height, 64.0f, 64.0f);
        GlStateManager.disableBlend();
        GlStateManager.resetColor();
    }

    protected void drawBigHeadRound2(float x2, float y2, float width, float height, AbstractClientPlayer player) {
        StencilUtil.initStencilToWrite();
        RenderUtil.renderRoundedRect(x2 - 1.0f, y2 - 1.0f, width, height, 6.0f, -1);
        StencilUtil.readStencilBuffer(1);
        RenderUtil.color(-1);
        this.drawBigHead(x2 - 1.0f, y2 - 1.0f, width, height, player);
        StencilUtil.uninitStencilBuffer();
        GlStateManager.disableBlend();
    }
    */
}
package dev.zzz.module.modules.movement;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.world.EventLivingUpdate;
import dev.zzz.event.world.EventMotion;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.modules.combat.KillAura;
import dev.zzz.module.values.ModeValue;
import dev.zzz.utils.RayCastUtil;
import dev.zzz.utils.client.PacketUtil;
import dev.zzz.utils.player.BlockUtil;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.BlockWeb;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

@Native
public class NoWeb
extends Module {

    public NoWeb() {
        super("NoWeb", Category.Movement);
    }

    @Override
    public void onDisable() {
        NoWeb.mc.timer.timerSpeed = 1.0f;
    }

    @EventTarget
    private void onUpdate(EventLivingUpdate e) {
        this.suffix = "Grim";
        if (RayCastUtil.isOnBlock() && GameSettings.isKeyDown(mc.gameSettings.keyBindAttack)) return;

        for (int i = -3;i <= 3;i++) {
            for (int i2 = -4;i2 <= 4;i2++) {
                for (int i3 = -3;i3 <= 3;i3++) {
                    final BlockPos bp = new BlockPos(mc.thePlayer).add(i, i2, i3);
                    final Block block = mc.theWorld.getBlockState(bp).getBlock();
                    if (block instanceof BlockWeb)
                        mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, bp, EnumFacing.UP));
                }
            }
        }

        mc.thePlayer.isInWeb = false;
    }

}


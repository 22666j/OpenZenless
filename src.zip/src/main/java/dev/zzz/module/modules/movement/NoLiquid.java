package dev.zzz.module.modules.movement;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.world.EventLivingUpdate;
import dev.zzz.event.world.EventMotion;
import dev.zzz.event.world.EventWorldLoad;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.modules.combat.KillAura;
import dev.zzz.module.values.ModeValue;
import dev.zzz.utils.RayCastUtil;
import dev.zzz.utils.player.BlockUtil;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

@Native
public class NoLiquid
extends Module {

    public NoLiquid() {
        super("NoLiquid", Category.Movement);
    }


    @EventTarget
    public void onUpdate(EventLivingUpdate e) {
        if (RayCastUtil.isOnBlock() && GameSettings.isKeyDown(mc.gameSettings.keyBindAttack)) return;
        this.setSuffix("Grim");
        for (int i = -3;i < 3;i++) {
            for (int i2 = -6;i2 < 6;i2++) {
                final BlockPos playerPos = new BlockPos(mc.thePlayer);
                BlockPos[] blockPoses = new BlockPos[]{playerPos.add(i2, i, 7), playerPos.add(i2, i, -7), playerPos.add(7, i, i2), playerPos.add(-7, i, i2)};
                for (BlockPos blockPos : blockPoses) {
                    final IBlockState blockState = mc.theWorld.getBlockState(blockPos);
                    final Block block = blockState.getBlock();

                    if (block instanceof BlockLiquid) {
                        mc.getNetHandler().addToSendQueueUnregistered(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, blockPos, EnumFacing.DOWN));
                        mc.theWorld.setBlockToAir(blockPos);
                    }
                }
            }
        }
    }

}


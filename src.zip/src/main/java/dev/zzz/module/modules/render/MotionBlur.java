package dev.zzz.module.modules.render;

import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.values.NumberValue;

public class MotionBlur
extends Module {
    public final NumberValue blurAmount = new NumberValue("Amount", 7.0, 0.0, 10.0, 0.1);

    public MotionBlur() {
        super("MotionBlur", Category.Render);
    }
}


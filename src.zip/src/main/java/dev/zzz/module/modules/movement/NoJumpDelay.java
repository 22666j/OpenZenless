package dev.zzz.module.modules.movement;

import dev.zzz.module.Category;
import dev.zzz.module.Module;

public class NoJumpDelay extends Module {
    public NoJumpDelay() {
        super("NoJumpDelay", Category.Movement);
    }


}

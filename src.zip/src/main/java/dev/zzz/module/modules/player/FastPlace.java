package dev.zzz.module.modules.player;

import dev.zzz.event.EventTarget;
import dev.zzz.event.world.EventTick;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.values.NumberValue;
import net.minecraft.item.ItemBlock;

public class FastPlace
extends Module {
    private final NumberValue ticks = new NumberValue("Ticks", 0.0, 4.0, 0.0, 1.0);

    public FastPlace() {
        super("FastPlace", Category.Player);
    }

    @EventTarget
    public void onTick(EventTick e) {
        if (FastPlace.mc.thePlayer.getHeldItem().getItem() instanceof ItemBlock) {
            FastPlace.mc.rightClickDelayTimer = Math.min(0, this.ticks.getValue().intValue());
        }
    }
}


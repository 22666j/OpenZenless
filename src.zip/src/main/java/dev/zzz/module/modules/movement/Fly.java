package dev.zzz.module.modules.movement;

import dev.zzz.event.EventTarget;
import dev.zzz.event.misc.EventTeleport;
import dev.zzz.event.rendering.EventRender3D;
import dev.zzz.event.world.*;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.values.ModeValue;
import dev.zzz.utils.BlinkUtils;
import dev.zzz.utils.DebugUtil;
import dev.zzz.utils.client.PacketUtil;
import dev.zzz.utils.client.TimeUtil;
import dev.zzz.utils.player.MoveUtil;
import dev.zzz.utils.render.RenderUtil;
import java.awt.Color;
import java.util.LinkedList;
import net.minecraft.network.play.client.C00PacketKeepAlive;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C16PacketClientStatus;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

public class Fly
extends Module {
    private final ModeValue<flyModes> flyMode = new ModeValue("FlyMode", flyModes.values(), flyModes.Vanilla);
    private boolean started;
    private boolean notUnder;
    private boolean clipped;
    private boolean teleport;
    private final LinkedList<double[]> positions = new LinkedList();
    private final TimeUtil pulseTimer = new TimeUtil();
    private int ticks = 0;
    private boolean exploited;
    public Fly() {
        super("Fly", Category.Movement);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void onDisable() {
        Fly.mc.timer.timerSpeed = 1.0f;
        if (this.flyMode.getValue() == flyModes.GrimGhostBlock) {
            LinkedList<double[]> linkedList = this.positions;
            synchronized (linkedList) {
                this.positions.clear();
            }
            if (Fly.mc.thePlayer == null) {
                return;
            }
            BlinkUtils.setBlinkState(true, true, false, false, false, false, false, false, false, false, false);
            BlinkUtils.clearPacket(null, false, -1);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void onEnable() {
        mc.timer.timerSpeed = 1.0f;
        ticks = 0;
        exploited = false;
        if (this.flyMode.getValue() == flyModes.DoMCer) {
            DebugUtil.log("\u9700\u8981\u9876\u5934");
            this.notUnder = false;
            this.started = false;
            this.clipped = false;
            this.teleport = false;
        }
        if (this.flyMode.getValue() == flyModes.GrimGhostBlock) {
            if (Fly.mc.thePlayer == null) {
                return;
            }
            BlinkUtils.setBlinkState(false, false, true, false, false, false, false, false, false, false, false);
            LinkedList<double[]> linkedList = this.positions;
            synchronized (linkedList) {
                this.positions.add(new double[]{Fly.mc.thePlayer.posX, Fly.mc.thePlayer.getEntityBoundingBox().minY + (double)(Fly.mc.thePlayer.getEyeHeight() / 2.0f), Fly.mc.thePlayer.posZ});
                this.positions.add(new double[]{Fly.mc.thePlayer.posX, Fly.mc.thePlayer.getEntityBoundingBox().minY, Fly.mc.thePlayer.posZ});
            }
            this.pulseTimer.reset();
        }
    }

    @EventTarget
    public void onPacketSend(EventPacketSend event) {
        if (this.flyMode.getValue() == flyModes.GrimGhostBlock && (event.getPacket() instanceof C16PacketClientStatus || event.getPacket() instanceof C00PacketKeepAlive)) {
            event.setCancelled();
        }
    }
    @EventTarget
    public void onPacketReceive(EventPacketReceive event) {


    }
    @EventTarget
    public void onTP(EventTeleport event) {
        if (this.teleport) {
            event.setCancelled(true);
            this.teleport = false;
            DebugUtil.log("Teleported");
            this.toggle();
        }
    }

    @EventTarget
    public void onStrafe(EventStrafe event) {
        this.setSuffix("NMSL");
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (this.flyMode.getValue() == flyModes.GrimGhostBlock) {
            this.setSuffix("GhostBlock-Blink:" + BlinkUtils.bufferSize(null));
            LinkedList<double[]> linkedList = this.positions;
            synchronized (linkedList) {
                this.positions.add(new double[]{Fly.mc.thePlayer.posX, Fly.mc.thePlayer.getEntityBoundingBox().minY, Fly.mc.thePlayer.posZ});
            }
            if (Fly.mc.thePlayer.ticksExisted % 2 == 1) {
                PacketUtil.sendPacketC0F(true);
            }
            if (this.pulseTimer.hasReached(2900.0)) {
                linkedList = this.positions;
                synchronized (linkedList) {
                    this.positions.clear();
                }
                BlinkUtils.releasePacket(null, false, -1, 0);
                this.pulseTimer.reset();
            }
        }
    }

    @EventTarget
    public void onTick(EventTick event){

    }
    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventTarget
    public void onRender3D(EventRender3D event) {
        if (this.flyMode.getValue() == flyModes.GrimGhostBlock) {
            LinkedList<double[]> linkedList = this.positions;
            synchronized (linkedList) {
                GL11.glPushMatrix();
                GL11.glDisable(3553);
                GL11.glBlendFunc(770, 771);
                GL11.glEnable(2848);
                GL11.glEnable(3042);
                GL11.glDisable(2929);
                Fly.mc.entityRenderer.disableLightmap();
                GL11.glLineWidth(2.0f);
                GL11.glBegin(3);
                RenderUtil.glColor(new Color(68, 131, 123, 255).getRGB());
                double renderPosX = Fly.mc.getRenderManager().viewerPosX;
                double renderPosY = Fly.mc.getRenderManager().viewerPosY;
                double renderPosZ = Fly.mc.getRenderManager().viewerPosZ;
                for (double[] pos : this.positions) {
                    GL11.glVertex3d(pos[0] - renderPosX, pos[1] - renderPosY, pos[2] - renderPosZ);
                }
                GL11.glColor4d(1.0, 1.0, 1.0, 1.0);
                GL11.glEnd();
                GL11.glEnable(2929);
                GL11.glDisable(2848);
                GL11.glDisable(3042);
                GL11.glEnable(3553);
                GL11.glPopMatrix();
            }
        }
    }

    public enum flyModes {
        Vanilla,
        DoMCer,
        GrimGhostBlock

    }
}


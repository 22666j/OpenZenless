package dev.zzz.module.modules.misc;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;

import dev.zzz.event.world.EventWorldLoad;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.values.BoolValue;
import dev.zzz.module.values.ModeValue;
import net.netease.chunk.RegionFileManager;
import net.netease.chunk.WorldLoader;


@Native
public class Protocol extends Module {
    public static final BoolValue germ = new BoolValue("Germ", true);
    public static final BoolValue bypassGreen = new BoolValue("BypassGreen", true);
    public static final BoolValue worldLoader = new BoolValue("WorldLoader",true);

    public Protocol() {
        super("Protocol", Category.Misc);
    }

    @EventTarget
    private void onWorld(EventWorldLoad event) {
        WorldLoader.INSTANCE.chunkManager = null;
        WorldLoader.INSTANCE.setLoaded(!worldLoader.getValue());
        RegionFileManager.clearRegionFileCache();
    }
}

package dev.zzz.module.modules.player;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.rendering.EventRender2D;
import dev.zzz.event.rendering.EventRender3D;
import dev.zzz.event.world.EventMotion;
import dev.zzz.event.world.EventPacketSend;
import dev.zzz.event.world.EventUpdate;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.values.BoolValue;
import dev.zzz.module.values.NumberValue;
import dev.zzz.utils.HYTUtils;
import dev.zzz.utils.TimerUtil;
import dev.zzz.utils.client.TimeUtil;
import dev.zzz.utils.item.ItemUtils;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import dev.zzz.utils.render.RenderUtil;
import dev.zzz.utils.render.RoundedUtils;
import dev.zzz.utils.render.ShaderUtil;
import net.minecraft.block.BlockChest;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerBrewingStand;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.ContainerFurnace;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import org.lwjgl.opengl.GL11;

import static dev.zzz.Client.mc;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL11.GL_BLEND;

@Native
public class ChestStealer
extends Module {
    private final BoolValue postValue = new BoolValue("Post", false);
    private final BoolValue chest = new BoolValue("Chest", true);
    private final BoolValue furnace = new BoolValue("Furnace", true);
    private final BoolValue brewingStand = new BoolValue("BrewingStand", true);

    public static final TimeUtil timer = new TimeUtil();
    public static boolean isChest = false;
    public static TimeUtil openChestTimer = new TimeUtil();
    private final NumberValue delay = new NumberValue("StealDelay", 100, 0, 1000,100);
    private final BoolValue trash = new BoolValue("PickTrash", true);
    public final BoolValue silentValue = new BoolValue("Silent", true);
    public final BoolValue showValue = new BoolValue("Show", true);
    public static boolean stealing = false;
    private int nextDelay = 0;
    public BlockPos blockPos;
    public long showTime;
    public BlockPos animatedPos;
    private GuiChest guiChest;
    private TileEntityChest chestt;
    public ScaledResolution scaledResolution = new ScaledResolution(mc);
    private Framebuffer framebuffer = new Framebuffer(1, 1, false);

    public ChestStealer() {
        super("ChestStealer", Category.Player);
    }

    @EventTarget
    private void onpacket(EventPacketSend event) {
        final Packet<?> packet = event.getPacket();

        if (packet instanceof C08PacketPlayerBlockPlacement) {
            final C08PacketPlayerBlockPlacement wrapped = (C08PacketPlayerBlockPlacement) packet;

            if (mc.theWorld.getBlockState(wrapped.getPosition()).getBlock() instanceof BlockChest)
                blockPos = wrapped.getPosition();
        }
    }
    @EventTarget
    private void onRender(EventRender2D e){
        if (showValue.getValue() && stealing) {
            final int length = chestt.getSizeInventory() / 9;
            framebuffer = RenderUtil.createFrameBuffer(framebuffer, true);
            framebuffer.framebufferClear();
            framebuffer.bindFramebuffer(false);
            GlStateManager.enableDepth();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            GlStateManager.enableRescaleNormal();
            RenderHelper.enableGUIStandardItemLighting();

            for (int yi = 1; yi <= length; yi++) {
                for (int xi = 1; xi <= 9; xi++) {
                    final ItemStack itemStack = guiChest.inventorySlots.inventorySlots.get((yi - 1) * 9 + xi - 1).getStack();

                    if (itemStack != null) {
                        mc.getRenderItem().renderItemIntoGUI3D(itemStack, ((xi - 1) * 22) + 4, ((yi - 1) * 22) + 4);
                        mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRendererObj, itemStack, (xi - 1) * 22 + 4, (yi - 1) * 22 + 4, null);
                    }
                }
            }

            RenderHelper.disableStandardItemLighting();
            GlStateManager.disableRescaleNormal();
            GlStateManager.disableBlend();
            framebuffer.unbindFramebuffer();
            mc.getFramebuffer().bindFramebuffer(false);
        }
    }
    @EventTarget
    public void Render3D(EventRender3D event){
        if (!showValue.getValue() || (blockPos == null && animatedPos == null) || (!(mc.currentScreen instanceof GuiChest) && animatedPos == null)) {
            showTime = System.currentTimeMillis();
            return;
        }

        mc.theWorld.loadedTileEntityList.forEach(entity -> {
            if (entity instanceof TileEntityChest) {
                this.chestt = (TileEntityChest) entity;

                if (blockPos != null) {
                    if (!(mc.currentScreen instanceof GuiChest)) return;

                    this.guiChest = (GuiChest) mc.currentScreen;

                    if (chestt.getPos().equals(blockPos)) {
                        final int length = chestt.getSizeInventory() / 9;
                        final RenderManager renderManager = mc.getRenderManager();

                        final double posX = (blockPos.getX() + 0.5) - renderManager.renderPosX;
                        final double posY = blockPos.getY() - renderManager.renderPosY;
                        final double posZ = (blockPos.getZ() + 0.5) - renderManager.renderPosZ;

                        GL11.glPushMatrix();
                        GL11.glTranslated(posX, posY, posZ);
                        GL11.glRotated(-mc.getRenderManager().playerViewY, 0F, 1F, 0F);
                        GL11.glRotated(-mc.getRenderManager().playerViewX, -1F, 0F, 0F);
                        GL11.glScaled(Math.max((showTime - System.currentTimeMillis()) / 10000.0, -0.015), Math.max((showTime - System.currentTimeMillis()) / 10000.0, -0.015), Math.min((System.currentTimeMillis() - showTime) / 10000.0, 0.015));

                        glDisable(GL_DEPTH_TEST);
                        glDepthMask(false);
                        GlStateManager.enableBlend();
                        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

                        final int x = -99;
                        final int y = -105 - (Math.round(length / 2F) * 22);
                        final int width = 200;
                        final int height = length * 22 + 2;

                        RoundedUtils.drawRound(x, y, width, height, 6, new Color(255, 255, 255, 140));

                        for (int yi = 1; yi <= length; yi++) {
                            for (int xi = 1; xi <= 9; xi++) {
                                RoundedUtils.drawRound(x + ((xi - 1) * 22) + 2, y + ((yi - 1) * 22) + 2, 20, 20, 3, new Color(255, 255, 255, 76));
                            }
                        }

//                        UI_BLOOM_RUNNABLES.add(() -> {
//                            GL11.glPushMatrix();
//                            GL11.glTranslated(posX, posY, posZ);
//                            GL11.glRotated(-mc.getRenderManager().playerViewY, 0F, 1F, 0F);
//                            GL11.glRotated(-mc.getRenderManager().playerViewX, -1F, 0F, 0F);
//                            GL11.glScaled(Math.max((showTime - System.currentTimeMillis()) / 10000.0, -0.015), Math.max((showTime - System.currentTimeMillis()) / 10000.0, -0.015), Math.min((System.currentTimeMillis() - showTime) / 10000.0, 0.015));
//
//                            RenderUtil.roundedRectangle(x, y, width, height, 6, new Color(0, 0, 0, 140));
//
//                            GL11.glPopMatrix();
//                        });

//                        NORMAL_BLUR_RUNNABLES.add(() -> {
//                            GL11.glPushMatrix();
//                            GL11.glTranslated(posX, posY, posZ);
//                            GL11.glRotated(-mc.getRenderManager().playerViewY, 0F, 1F, 0F);
//                            GL11.glRotated(-mc.getRenderManager().playerViewX, -1F, 0F, 0F);
//                            GL11.glScaled(Math.max((showTime - System.currentTimeMillis()) / 10000.0, -0.015), Math.max((showTime - System.currentTimeMillis()) / 10000.0, -0.015), Math.min((System.currentTimeMillis() - showTime) / 10000.0, 0.015));
//
//                            Stencil.write(false);
//                            GlStateManager.translate(0, 0, -0.001);
//                            for (int yi = 1; yi <= length; yi++) {
//                                for (int xi = 1; xi <= 9; xi++) {
//                                    RenderUtil.roundedRectangle(x + ((xi - 1) * 22) + 2, y + ((yi - 1) * 22) + 2, 20, 20, 3, Color.BLACK);
//                                }
//                            }
//                            GlStateManager.translate(0, 0, 0.001);
//                            Stencil.erase(true);
//                            StencilUtil.bindReadStencilBuffer(0);
//                            RenderUtil.roundedRectangle(x, y, width, height, 6, Color.BLACK);
//                            Stencil.dispose();
//
//                            GL11.glPopMatrix();
//                        });

                        GlStateManager.bindTexture(framebuffer.framebufferTexture);
                        ShaderUtil.drawQuad( x,  y, (framebuffer.framebufferTextureWidth / (double) scaledResolution.getScaleFactor()),  (framebuffer.framebufferTextureHeight / (double) scaledResolution.getScaleFactor()));

                        glDepthMask(true);
                        glEnable(GL_DEPTH_TEST);
                        glDisable(GL_BLEND);

                        GL11.glPopMatrix();
                    }
                } else if (guiChest != null) {
                    // GL11.glScaled(Math.min((System.currentTimeMillis() - showTime - 150) / 10000.0, 0), Math.min((System.currentTimeMillis() - showTime - 150) / 10000.0, 0), Math.max((showTime - System.currentTimeMillis() + 150) / 10000.0, 0));
                    if (System.currentTimeMillis() - showTime <= 150) {
                        if (chestt.getPos().equals(animatedPos)) {
                            final int length = chestt.getSizeInventory() / 9;
                            final RenderManager renderManager = mc.getRenderManager();

                            final double posX = (animatedPos.getX() + 0.5) - renderManager.renderPosX;
                            final double posY = animatedPos.getY() - renderManager.renderPosY;
                            final double posZ = (animatedPos.getZ() + 0.5) - renderManager.renderPosZ;

                            GL11.glPushMatrix();
                            GL11.glTranslated(posX, posY, posZ);
                            GL11.glRotated(-mc.getRenderManager().playerViewY, 0F, 1F, 0F);
                            GL11.glRotated(-mc.getRenderManager().playerViewX, -1F, 0F, 0F);
                            GL11.glScaled(Math.min((System.currentTimeMillis() - showTime - 150) / 10000.0, 0), Math.min((System.currentTimeMillis() - showTime - 150) / 10000.0, 0), Math.max((showTime - System.currentTimeMillis() + 150) / 10000.0, 0));

                            glDisable(GL_DEPTH_TEST);
                            glDepthMask(false);
                            GlStateManager.enableBlend();
                            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);

                            final int x = -99;
                            final int y = -105 - (Math.round(length / 2F) * 22);
                            final int width = 200;
                            final int height = length * 22 + 2;

                            RoundedUtils.drawRound(x, y, width, height, 6, new Color(255, 255, 255, 140));

                            for (int yi = 1; yi <= length; yi++) {
                                for (int xi = 1; xi <= 9; xi++) {

                                    RoundedUtils.drawRound(x + ((xi - 1) * 22) + 2, y + ((yi - 1) * 22) + 2, 20, 20, 3, new Color(255, 255, 255, 76));

                                }
                            }

//                            UI_BLOOM_RUNNABLES.add(() -> {
//                                GL11.glPushMatrix();
//                                GL11.glTranslated(posX, posY, posZ);
//                                GL11.glRotated(-mc.getRenderManager().playerViewY, 0F, 1F, 0F);
//                                GL11.glRotated(-mc.getRenderManager().playerViewX, -1F, 0F, 0F);
//                                GL11.glScaled(Math.min((System.currentTimeMillis() - showTime - 150) / 10000.0, 0), Math.min((System.currentTimeMillis() - showTime - 150) / 10000.0, 0), Math.max((showTime - System.currentTimeMillis() + 150) / 10000.0, 0));
//
//                                RenderUtil.roundedRectangle(x, y, width, height, 6, new Color(0, 0, 0, 140));
//
//                                GL11.glPopMatrix();
//                            });
//
//                            NORMAL_BLUR_RUNNABLES.add(() -> {
//                                GL11.glPushMatrix();
//                                GL11.glTranslated(posX, posY, posZ);
//                                GL11.glRotated(-mc.getRenderManager().playerViewY, 0F, 1F, 0F);
//                                GL11.glRotated(-mc.getRenderManager().playerViewX, -1F, 0F, 0F);
//                                GL11.glScaled(Math.min((System.currentTimeMillis() - showTime - 150) / 10000.0, 0), Math.min((System.currentTimeMillis() - showTime - 150) / 10000.0, 0), Math.max((showTime - System.currentTimeMillis() + 150) / 10000.0, 0));
//
//                                Stencil.write(false);
//                                GlStateManager.translate(0, 0, -0.001);
//                                for (int yi = 1; yi <= length; yi++) {
//                                    for (int xi = 1; xi <= 9; xi++) {
//                                        RenderUtil.roundedRectangle(x + ((xi - 1) * 22) + 2, y + ((yi - 1) * 22) + 2, 20, 20, 3, Color.BLACK);
//                                    }
//                                }
//                                GlStateManager.translate(0, 0, 0.001);
//                                Stencil.erase(true);
//                                StencilUtil.bindReadStencilBuffer(0);
//                                RenderUtil.roundedRectangle(x, y, width, height, 6, Color.BLACK);
//                                Stencil.dispose();
//
//                                GL11.glPopMatrix();
//                            });

                            GlStateManager.bindTexture(framebuffer.framebufferTexture);
                            ShaderUtil.drawQuad(x,  y,  (framebuffer.framebufferTextureWidth / (double) scaledResolution.getScaleFactor()), (framebuffer.framebufferTextureHeight / (double) scaledResolution.getScaleFactor()));

                            glDepthMask(true);
                            glEnable(GL_DEPTH_TEST);
                            glDisable(GL_BLEND);

                            GL11.glPopMatrix();
                        }
                    } else {
                        animatedPos = null;
                        guiChest = null;
                    }
                }
            }
        });
    }


    @EventTarget
    private void MotionEvent(EventMotion event) {
        if (HYTUtils.isInLobby()) return;

        if ((postValue.getValue() && event.isPost()) || (!postValue.getValue() && event.isPre())) {
            if (mc.thePlayer.openContainer == null){
                return;
            }
            if (!(mc.thePlayer.openContainer instanceof ContainerChest || mc.thePlayer.openContainer instanceof ContainerFurnace || mc.thePlayer.openContainer instanceof ContainerBrewingStand)) {
                stealing = false;
                return;
            }

            stealing = true;

            if (mc.thePlayer.openContainer instanceof ContainerFurnace && furnace.getValue()) {
                ContainerFurnace container = (ContainerFurnace) mc.thePlayer.openContainer;

                if ((isFurnaceEmpty(container)) && openChestTimer.delay(100) && timer.delay(100)) {
                    mc.thePlayer.closeScreen();
                    return;
                }

                for (int i = 0; i < container.tileFurnace.getSizeInventory(); ++i) {
                    if (container.tileFurnace.getStackInSlot(i) != null) {
                        if (timer.delay(nextDelay)) {

//                            for (int j = 0; j < 21; ++j) {
                            if (isInventoryFull()) {
                                mc.playerController.windowClick(container.windowId, i, 0, 4, mc.thePlayer);
                            } else {
                                mc.playerController.windowClick(container.windowId, i, 0, 1, mc.thePlayer);
                            }
//                            }

                            nextDelay = (int) (delay.getValue() * MathHelper.getRandomDoubleInRange(0.75, 1.25));
                            timer.reset();
                        }
                    }
                }
            }

            if (mc.thePlayer.openContainer instanceof ContainerBrewingStand && brewingStand.getValue()) {
                ContainerBrewingStand container = (ContainerBrewingStand) mc.thePlayer.openContainer;

                if ((isBrewingStandEmpty(container)) && openChestTimer.delay(100) && timer.delay(100)) {
                    mc.thePlayer.closeScreen();
                    return;
                }

                for (int i = 0; i < container.tileBrewingStand.getSizeInventory(); ++i) {
                    if (container.tileBrewingStand.getStackInSlot(i) != null) {
                        if (timer.delay(nextDelay)) {
//                            for (int j = 0; j < 21; ++j) {
                            if (isInventoryFull()) {
                                mc.playerController.windowClick(container.windowId, i, 0, 4, mc.thePlayer);
                            } else {
                                mc.playerController.windowClick(container.windowId, i, 0, 1, mc.thePlayer);
                            }
//                            }
                            nextDelay = (int) (delay.getValue() * MathHelper.getRandomDoubleInRange(0.75, 1.25));
                            timer.reset();
                        }
                    }
                }
            }

            if (mc.thePlayer.openContainer instanceof ContainerChest && chest.getValue() && isChest) {
                ContainerChest container = (ContainerChest) mc.thePlayer.openContainer;


                if ((isChestEmpty(container)) && openChestTimer.delay(100) && timer.delay(100)) {
                    mc.thePlayer.closeScreen();
                    return;
                }

                for (int i = 0; i < container.getLowerChestInventory().getSizeInventory(); ++i) {
                    if (container.getLowerChestInventory().getStackInSlot(i) != null) {
                        if (timer.delay(nextDelay) && (isItemUseful(container, i) || trash.getValue())) {
//                            for (int j = 0; j < 21; ++j) {
                            if (isInventoryFull()) {
                                mc.playerController.windowClick(container.windowId, i, 0, 4, mc.thePlayer);
                            } else {
                                mc.playerController.windowClick(container.windowId, i, 0, 1, mc.thePlayer);
                            }
//                            }
                            nextDelay = (int) (delay.getValue() * MathHelper.getRandomDoubleInRange(0.75, 1.25));
                            timer.reset();
                        }
                    }
                }
            }
        }
    };

    private boolean isInventoryFull() {
        for (ItemStack is : mc.thePlayer.inventory.mainInventory) {
            if (is == null) return false;
        }

        return true;
    }

    private boolean isChestEmpty(ContainerChest c) {
        for (int i = 0; i < c.getLowerChestInventory().getSizeInventory(); ++i) {
            if (c.getLowerChestInventory().getStackInSlot(i) != null) {
                if (isItemUseful(c, i) || trash.getValue()) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean isFurnaceEmpty(ContainerFurnace c) {
        for (int i = 0; i < c.tileFurnace.getSizeInventory(); ++i) {
            if (c.tileFurnace.getStackInSlot(i) != null) {
                return false;
            }
        }

        return true;
    }

    private boolean isBrewingStandEmpty(ContainerBrewingStand c) {
        for (int i = 0; i < c.tileBrewingStand.getSizeInventory(); ++i) {
            if (c.tileBrewingStand.getStackInSlot(i) != null) {
                return false;
            }
        }

        return true;
    }

    private boolean isItemUseful(ContainerChest c, int i) {
        ItemStack itemStack = c.getLowerChestInventory().getStackInSlot(i);
        Item item = itemStack.getItem();

        if (item instanceof ItemAxe || item instanceof ItemPickaxe) {
            return true;
        }

        if (item instanceof ItemFood)
            return true;
        if (item instanceof ItemBow || item == Items.arrow)
            return true;

        if (item instanceof ItemPotion && !ItemUtils.isPotionNegative(itemStack))
            return true;
        if (item instanceof ItemSword && ItemUtils.isBestSword(c, itemStack))
            return true;
        if (item instanceof ItemArmor && ItemUtils.isBestArmor(c, itemStack))
            return true;
        if (item instanceof ItemBlock)
            return true;

        return item instanceof ItemEnderPearl;
    }
}
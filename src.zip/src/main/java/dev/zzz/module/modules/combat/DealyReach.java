package dev.zzz.module.modules.combat;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.world.EventPacketSend;
import dev.zzz.event.world.EventTick;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.utils.client.ChatUtil;
import dev.zzz.utils.client.PacketUtil;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0APacketAnimation;
import org.lwjgl.input.Keyboard;

import java.util.LinkedList;

@Native
public class DealyReach extends Module {
    private LinkedList<Packet<?>> co2Packets = new LinkedList<>();
    private int co2Threshold = 5;
    private boolean canReleaseCO2 = false;

    public DealyReach() {
        super("BestReach2", Category.Combat);
    }

    @EventTarget
    public void onPacketSend(EventPacketSend event) {

        if (event.getPacket() instanceof C02PacketUseEntity c02) {

            if (co2Packets.size() < co2Threshold) {
                return;
            } else {

                co2Packets.add(c02);
                event.setCancelled(true);
            }
        }


        if (event.getPacket() instanceof C0APacketAnimation c0a) {
            if (co2Packets.size() < co2Threshold) {
                return;
            } else {
                co2Packets.add(c0a);
                event.setCancelled(true);
            }
        }


        if (canReleaseCO2 && event.getPacket() instanceof C03PacketPlayer) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onTick(EventTick event) {

        if (Keyboard.isKeyDown(Keyboard.KEY_1) && canReleaseCO2) {

            if (KillAura.target == null && mc.thePlayer.getDistanceToEntity(KillAura.target) < 6) {
                releaseCO2();
            }
        }
    }

    private void releaseCO2() {
        // 模拟CO2释放，清空CO2缓存包
        if (!co2Packets.isEmpty()) {
            // 这里假设是通过某种方式触发攻击包（如发送网络包）
            for (Packet<?> packet : co2Packets) {
                // 你可以根据需要更改此逻辑以发送相应的CO2包（例如通过PacketUtil发送）
                mc.getNetHandler().addToSendQueue(packet);
            }
            // 清空已收集的CO2包
            co2Packets.clear();
            canReleaseCO2 = false;  // 清空CO2释放状态
            ChatUtil.print("CO2已释放！");
        }
    }
}

package dev.zzz.module.modules.world;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.misc.MoveMathEvent;
import dev.zzz.event.world.EventUpdate;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.modules.player.AntiVoid;
import dev.zzz.utils.player.PlayerUtil;

@Native
public class SBStuck extends Module {
    public SBStuck() {
        super("SBStuck", Category.World);
    }
    @EventTarget
    public void onMoveMathEvent(MoveMathEvent event) {
        boolean bl = mc.thePlayer.positionUpdateTicks < 20 && !AntiVoid.mc.thePlayer.onGround && !PlayerUtil.isBlockUnder(30.0, true);
        if (bl) {
            event.setCancelled(true);
        }

    }
}

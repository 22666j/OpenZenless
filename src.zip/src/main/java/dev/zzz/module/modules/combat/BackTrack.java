package dev.zzz.module.modules.combat;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.Client;
import dev.zzz.event.EventTarget;
import dev.zzz.event.attack.EventAttack;
import dev.zzz.event.rendering.EventRender3D;
import dev.zzz.event.world.EventPacketReceive;
import dev.zzz.event.world.EventTick;
import dev.zzz.event.world.EventUpdate;
import dev.zzz.event.world.EventWorldLoad;
import dev.zzz.module.Category;
import dev.zzz.module.Module;

import dev.zzz.module.modules.movement.NoWeb;
import dev.zzz.module.values.ModeValue;
import dev.zzz.module.values.NumberValue;
import dev.zzz.utils.render.RenderUtil;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.S18PacketEntityTeleport;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.Vec3;

import java.util.ArrayList;
import java.util.LinkedHashMap;

@Native
public class BackTrack extends Module {
    private NumberValue length = new NumberValue("BackTrackLength", 5, 1, 20,1);
    public BackTrack() {
        super("BackTrack", Category.Combat);
    }
    public static LinkedHashMap<EntityPlayer, ArrayList<AxisAlignedBB>> playerBBox = new LinkedHashMap<>();

    public static boolean hand = true;

    @Override
    public void onEnable() {
        playerBBox.clear();
    }

    @EventTarget
    private void onUpdate(EventUpdate event) {
        for (EntityPlayer player : mc.theWorld.playerEntities) {
            playerBBox.computeIfAbsent(player, k -> new ArrayList<>());
            playerBBox.get(player).add(player.boundingBox);

            while (true) {
                if (playerBBox.get(player).size() > length.getValue()) {
                    playerBBox.get(player).remove(0);
                } else {
                    break;
                }
            }
        }
    }

    @EventTarget
    private void onWorld(EventWorldLoad event) {
        playerBBox.clear();
    };

    public static AxisAlignedBB getClosedBBox(EntityPlayer player) {
        if (mc.thePlayer.getDistanceToEntity(player) <= Client.instance.moduleManager.getModule(KillAura.class).getRange()) return predictPlayerBBox(player);
        if (!Client.instance.moduleManager.getModule(BackTrack.class).getState()) return predictPlayerBBox(player);
        if (playerBBox.get(player) == null) return predictPlayerBBox(player);
        AxisAlignedBB nearestBBox = predictPlayerBBox(player);
        double nearestDistance = mc.thePlayer.getClosestDistanceToBBox(nearestBBox);

        for (AxisAlignedBB bbox : playerBBox.get(player)) {
            float closestDistanceToBBox = mc.thePlayer.getClosestDistanceToBBox(bbox);
            if (closestDistanceToBBox < nearestDistance) {
                nearestDistance = closestDistanceToBBox;
                nearestBBox = bbox;
            }
        }

        return nearestBBox;
    }

    public static AxisAlignedBB predictPlayerBBox(EntityPlayer player) {
        double x = player.posX - player.lastTickPosX;
        double y = player.posY - player.lastTickPosY;
        double z = player.posZ - player.lastTickPosZ;
        return player.boundingBox.offset(x, y, z);
    }
}

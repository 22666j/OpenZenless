package dev.zzz.module.modules.render;

import dev.zzz.module.Category;
import dev.zzz.module.Module;

public class ItemPhysics
extends Module {
    public ItemPhysics() {
        super("ItemPhysics", Category.Render);
    }
}


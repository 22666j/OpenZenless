package dev.zzz.module.modules.misc;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.Client;
import dev.zzz.event.EventTarget;
import dev.zzz.event.world.*;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.modules.combat.AutoGapple;
import dev.zzz.module.modules.movement.Fly;
import dev.zzz.module.modules.world.Scaffold;
import dev.zzz.module.values.BoolValue;
import dev.zzz.module.values.ModeValue;
import dev.zzz.module.values.NumberValue;
import dev.zzz.utils.BlinkUtils;
import dev.zzz.utils.RotationComponent;
import dev.zzz.utils.client.MathUtil;
import dev.zzz.utils.client.PacketUtil;
import dev.zzz.utils.client.TimeUtil;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.FutureTask;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiDownloadTerrain;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.*;
import net.minecraft.network.play.server.*;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.PacketProcessListenableFutureTask;
import net.minecraft.util.Util;
import org.apache.commons.lang3.RandomUtils;

@Native
public class Disabler extends Module {
    private static Disabler INSTANCE;
    public static boolean fakePlayer = false;
    private boolean lastSprinting = false;
    public static ConcurrentLinkedDeque<Integer> pingPackets = new ConcurrentLinkedDeque<>();

    public Disabler() {
        super("Disabler", Category.Misc);
        INSTANCE = this;
    }


    public static void preProcessPackets() {
        LinkedList<FutureTask<?>> queue = new LinkedList<>();
        while (!mc.preScheduledTasks.isEmpty()) {
            FutureTask<?> task = mc.preScheduledTasks.get(0);
            if (mc.getNetHandler() != null && mc.theWorld != null && mc.thePlayer != null && task instanceof PacketProcessListenableFutureTask) {

                PacketProcessListenableFutureTask<?> packetTask = (PacketProcessListenableFutureTask<?>) task;

                fakePlayer = true;
                if (packetTask.packetToProcess instanceof S19PacketEntityHeadLook) {
                    S19PacketEntityHeadLook packet = (S19PacketEntityHeadLook) packetTask.packetToProcess;
                    Entity entity = packet.getEntity(mc.theWorld);
                    if (entity instanceof EntityPlayer) {
                        EntityPlayer player = (EntityPlayer) entity;
                        if (player.getEntityId() != mc.thePlayer.getEntityId()) {
                            packet.processPacket(mc.getNetHandler());
                        }
                    }
                }
                if (packetTask.packetToProcess instanceof S14PacketEntity) {
                    S14PacketEntity packet = (S14PacketEntity) packetTask.packetToProcess;
                    Entity entity = packet.getEntity(mc.theWorld);
                    if (entity instanceof EntityPlayer) {
                        EntityPlayer player = (EntityPlayer) entity;
                        if (player.getEntityId() != mc.thePlayer.getEntityId()) {
                            packet.processPacket(mc.getNetHandler());
                        }
                    }
                }
                if (packetTask.packetToProcess instanceof S19PacketEntityStatus) {
                    S19PacketEntityStatus packet = (S19PacketEntityStatus) packetTask.packetToProcess;
                    Entity entity = packet.getEntity(mc.theWorld);
                    if (entity instanceof EntityPlayer) {
                        EntityPlayer player = (EntityPlayer) entity;
                        if (player.getEntityId() != mc.thePlayer.getEntityId()) {
                            packet.processPacket(mc.getNetHandler());
                        }
                    }
                }
                if (packetTask.packetToProcess instanceof S1DPacketEntityEffect) {
                    S1DPacketEntityEffect packet = (S1DPacketEntityEffect) packetTask.packetToProcess;
                    Entity entity = mc.theWorld.getEntityByID(packet.getEntityId());
                    if (entity instanceof EntityPlayer) {
                        EntityPlayer player = (EntityPlayer) entity;
                        if (player.getEntityId() != mc.thePlayer.getEntityId()) {
                            packet.processPacket(mc.getNetHandler());
                        }
                    }
                }
                if (packetTask.packetToProcess instanceof S0BPacketAnimation) {
                    S0BPacketAnimation packet = (S0BPacketAnimation) packetTask.packetToProcess;
                    Entity entity = mc.theWorld.getEntityByID(packet.getEntityID());
                    if (entity instanceof EntityPlayer) {
                        EntityPlayer player = (EntityPlayer) entity;
                        if (player.getEntityId() != mc.thePlayer.getEntityId()) {
                            packet.processPacket(mc.getNetHandler());
                        }
                    }
                }
                if (packetTask.packetToProcess instanceof S18PacketEntityTeleport) {
                    S18PacketEntityTeleport packet = (S18PacketEntityTeleport) packetTask.packetToProcess;
                    Entity entity = mc.theWorld.getEntityByID(packet.getEntityId());
                    if (entity instanceof EntityPlayer) {
                        EntityPlayer player = (EntityPlayer) entity;
                        if (player.getEntityId() != mc.thePlayer.getEntityId()) {
                            packet.processPacket(mc.getNetHandler());
                        }
                    }
                }
                if (packetTask.packetToProcess instanceof S12PacketEntityVelocity) {
                    S12PacketEntityVelocity packet = (S12PacketEntityVelocity) packetTask.packetToProcess;
                    Entity entity = mc.theWorld.getEntityByID(packet.getEntityID());
                    if (entity instanceof EntityPlayer) {
                        EntityPlayer player = (EntityPlayer) entity;
                        if (player.getEntityId() != mc.thePlayer.getEntityId()) {
                            packet.processPacket(mc.getNetHandler());
                        }
                    }
                }
                if (packetTask.packetToProcess instanceof S13PacketDestroyEntities) {
                    S13PacketDestroyEntities packet = (S13PacketDestroyEntities) packetTask.packetToProcess;
                    packet.processPacket(mc.getNetHandler());
                }

                fakePlayer = false;
            }
            queue.add(task);
            mc.preScheduledTasks.pollFirst();
        }
        mc.scheduledTasks.add(queue);
    }

    public static void fixC0F(C0FPacketConfirmTransaction packet) {
        int id = packet.getUid();
        if (id >= 0 || pingPackets.isEmpty()) {
            mc.getNetHandler().getNetworkManager().sendPacket(packet);
        } else {
            while (true) {
                int current = pingPackets.getFirst();
                mc.getNetHandler().getNetworkManager().sendPacket(new C0FPacketConfirmTransaction(packet.getWindowId(), (short) current, true));
                pingPackets.pollFirst();
                if (current == id || pingPackets.isEmpty()) {
                    break;
                }
            }
        }
    }

    public static void onS08() {
        INSTANCE.s08 = true;
    }

    private boolean s08 = false;

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (s08) {
            s08 = false;
            while (mc.scheduledTasks.size() > 1) {
                processPackets();
            }
        }
    }

    @EventTarget
    public void onPacket(EventPacketSend event) {
        if (event.getPacket() instanceof C0BPacketEntityAction) {
            if (((C0BPacketEntityAction) event.getPacket()).getAction() == C0BPacketEntityAction.Action.START_SPRINTING) {
                if (this.lastSprinting) {
                    event.setCancelled(true);
                }
                this.lastSprinting = true;
            } else if (((C0BPacketEntityAction) event.getPacket()).getAction() == C0BPacketEntityAction.Action.STOP_SPRINTING) {
                if (!this.lastSprinting) {
                    event.setCancelled(true);
                }
                this.lastSprinting = false;
            }
        }

    }

    public static boolean getGrimPost() {
        return INSTANCE != null && INSTANCE.getState();
    }


    public static void processPackets() {
        if (mc.scheduledTasks.isEmpty()) return;
        while (!mc.scheduledTasks.get(0).isEmpty()) {
            Util.runTask(mc.scheduledTasks.get(0).poll(), Minecraft.logger);
        }
        mc.scheduledTasks.remove(0);
    }
}
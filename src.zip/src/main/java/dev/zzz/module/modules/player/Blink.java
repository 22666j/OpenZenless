package dev.zzz.module.modules.player;

import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.event.EventTarget;
import dev.zzz.event.rendering.EventRender3D;
import dev.zzz.event.world.*;
import dev.zzz.gui.notification.NotificationManager;
import dev.zzz.gui.notification.NotificationType;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.values.BoolValue;
import dev.zzz.module.values.ModeValue;
import dev.zzz.module.values.NumberValue;
import dev.zzz.utils.BlinkUtils;
import dev.zzz.utils.client.PacketUtil;
import dev.zzz.utils.client.TimeUtil;
import dev.zzz.utils.render.RenderUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.network.play.client.*;
import net.minecraft.network.play.server.S02PacketChat;
import org.lwjgl.opengl.GL11;

@Native
public class Blink extends Module {
    private final LinkedList<List<Packet<?>>> packets = new LinkedList();
    public EntityOtherPlayerMP fakePlayer;
    private int ticks;
    private final ModeValue<Blink.mode> modeValue = new ModeValue<>("Mode", Blink.mode.values(), Blink.mode.Simple);
    public BoolValue skywars = new BoolValue("SkyWars",false);
    public BoolValue autoclose = new BoolValue("AutoClose", false);
    private int countdownTicks = -1;  // 用于计时
    public Blink() {
        super("Blink", Category.Player);
    }

    @Override
    public void onEnable() {
        if (Blink.mc.thePlayer == null) {
            return;
        }
        countdownTicks = -1; // 重置计时器
        this.packets.clear();
        this.packets.add(new ArrayList());
        this.ticks = 0;
        this.fakePlayer = new EntityOtherPlayerMP(Blink.mc.theWorld, Blink.mc.thePlayer.getGameProfile());
        this.fakePlayer.clonePlayer(Blink.mc.thePlayer, true);
        this.fakePlayer.copyLocationAndAnglesFrom(Blink.mc.thePlayer);
        this.fakePlayer.rotationYawHead = Blink.mc.thePlayer.rotationYawHead;
        if (!skywars.getValue()) {
            Blink.mc.theWorld.addEntityToWorld(-1337, this.fakePlayer);
        }
    }

    @EventTarget
    public void onWorld(EventWorldLoad event) {
        this.setState(false);
    }

    @Override
    public void onDisable() {
        countdownTicks = -1; // 重置计时器
        this.packets.forEach(this::sendTick);
        this.packets.clear();
        try {
            if (this.fakePlayer != null) {
                Blink.mc.theWorld.removeEntity(this.fakePlayer);
            }
        }
        catch (Exception exception) {
        }
    }

    @EventTarget
    public void onPacket(EventHigherPacketSend event) {
        Packet packet = event.getPacket();
        if (PacketUtil.isCPacket(packet)) {
            mc.addScheduledTask(() -> this.packets.getLast().add(packet));
            event.setCancelled(true);
        }
    }
    @EventTarget
    public void onPacket(EventPacketReceive eventPacketReceive) {
        var packet = eventPacketReceive.getPacket();
        if(skywars.getValue()) {
            if (packet instanceof S02PacketChat) {
                var chatComponent = ((S02PacketChat) packet).chatComponent;
                if (chatComponent != null) {
                    var text = chatComponent.getUnformattedText();
                    if (text.contains("开始倒计时: 1 秒")) {
                        countdownTicks = 20;
                    }
                    if (text.contains("起床战争")) {
                        this.setState(false);
                    }
                }
            }
        }
    }
    @EventTarget
    public void onTick(EventTick event) {
        ++this.ticks;
        this.packets.add(new ArrayList());
        switch (this.modeValue.getValue()) {
            case Delay: {
                if (this.packets.size() <= 100) break;
                this.poll();
                break;
            }
            case SlowRelease: {
                if (this.packets.size() <= 100 && this.ticks % 5 != 0) break;
                this.poll();
            }
        }
    }

    private void poll() {
        if (this.packets.isEmpty()) {
            return;
        }
        this.sendTick(this.packets.getFirst());
        this.packets.removeFirst();
    }

    @Override
    public String getSuffix() {
        return modeValue.getValue().toString();
    }

    private void sendTick(List<Packet<?>> tick) {
        tick.forEach(packet -> {
            mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(packet);
            this.handleFakePlayerPacket(packet);
        });
    }

    private void handleFakePlayerPacket(Packet<?> packet) {
        if (packet instanceof C03PacketPlayer.C04PacketPlayerPosition) {
            C03PacketPlayer.C04PacketPlayerPosition position = (C03PacketPlayer.C04PacketPlayerPosition)packet;
            this.fakePlayer.setPositionAndRotation2(position.x, position.y, position.z, this.fakePlayer.rotationYaw, this.fakePlayer.rotationPitch, 3, true);
            this.fakePlayer.onGround = position.isOnGround();
        } else if (packet instanceof C03PacketPlayer.C05PacketPlayerLook) {
            C03PacketPlayer.C05PacketPlayerLook rotation = (C03PacketPlayer.C05PacketPlayerLook)packet;
            this.fakePlayer.setPositionAndRotation2(this.fakePlayer.posX, this.fakePlayer.posY, this.fakePlayer.posZ, rotation.getYaw(), rotation.getPitch(), 3, true);
            this.fakePlayer.onGround = rotation.isOnGround();
            this.fakePlayer.rotationYawHead = rotation.getYaw();
            this.fakePlayer.rotationYaw = rotation.getYaw();
            this.fakePlayer.rotationPitch = rotation.getPitch();
        } else if (packet instanceof C03PacketPlayer.C06PacketPlayerPosLook) {
            C03PacketPlayer.C06PacketPlayerPosLook positionRotation = (C03PacketPlayer.C06PacketPlayerPosLook)packet;
            this.fakePlayer.setPositionAndRotation2(positionRotation.x, positionRotation.y, positionRotation.z, positionRotation.getYaw(), positionRotation.getPitch(), 3, true);
            this.fakePlayer.onGround = positionRotation.isOnGround();
            this.fakePlayer.rotationYawHead = positionRotation.getYaw();
            this.fakePlayer.rotationYaw = positionRotation.getYaw();
            this.fakePlayer.rotationPitch = positionRotation.getPitch();
        } else if (packet instanceof C0BPacketEntityAction) {
            C0BPacketEntityAction action = (C0BPacketEntityAction)packet;
            if (action.getAction() == C0BPacketEntityAction.Action.START_SPRINTING) {
                this.fakePlayer.setSprinting(true);
            } else if (action.getAction() == C0BPacketEntityAction.Action.STOP_SPRINTING) {
                this.fakePlayer.setSprinting(false);
            } else if (action.getAction() == C0BPacketEntityAction.Action.START_SNEAKING) {
                this.fakePlayer.setSneaking(true);
            } else if (action.getAction() == C0BPacketEntityAction.Action.STOP_SNEAKING) {
                this.fakePlayer.setSneaking(false);
            }
        } else if (packet instanceof C0APacketAnimation) {
            C0APacketAnimation animation = (C0APacketAnimation)packet;
            this.fakePlayer.swingItem();
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(new C0FPacketConfirmTransaction(1, (short) 1, true));
        if (mc.thePlayer.hurtTime > 0 && this.autoclose.getValue().booleanValue()) {
            this.setState(false);
            NotificationManager.post(NotificationType.SUCCESS, "Blink", "AutoClose!", 5.0f);
        }
        if (countdownTicks > 0) {
            countdownTicks--;
        } else if (countdownTicks == 0) {
            this.setState(false);
            countdownTicks = -1; // 重置计时器
        }
        if(skywars.getValue()){
            mc.thePlayer.capabilities.allowEdit = true;
        }
    }
    private enum mode {
        Delay,
        SlowRelease,
        Simple
    }
}

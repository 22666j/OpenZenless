package dev.zzz.module.modules.movement;

import dev.zzz.event.EventTarget;
import dev.zzz.event.world.EventStrafe;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.utils.player.MoveUtil;

public class Strafe
extends Module {
    public Strafe() {
        super("Strafe", Category.Movement);
    }

    @Override
    public void onDisable() {
        Strafe.mc.timer.timerSpeed = 1.0f;
    }

    @EventTarget
    public void onStrafe(EventStrafe event) {
        MoveUtil.strafe();
    }
}


package dev.zzz.module.modules.player;

import dev.zzz.event.EventTarget;
import dev.zzz.event.world.EventMotion;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.values.ModeValue;

public class NoFall
extends Module {
    ModeValue<modeEnum> mode = new ModeValue("Mode", modeEnum.values(), modeEnum.HypixelSpoof);

    public NoFall() {
        super("NoFall", Category.Player);
    }

    @EventTarget
    public void onUpdate(EventMotion e) {
        this.setSuffix(this.mode.getValue().toString());
        switch (this.mode.getValue()) {
            case HypixelSpoof: {
                if (NoFall.mc.thePlayer.ticksExisted <= 50 || !(NoFall.mc.thePlayer.fallDistance > 3.0f)) break;
                e.setOnGround(true);
                break;
            }
            case GroundSpoof: {
                if (NoFall.mc.thePlayer.onGround) break;
                e.setOnGround(true);
            }
        }
    }

    enum modeEnum {
        HypixelSpoof,
        GroundSpoof

    }
}


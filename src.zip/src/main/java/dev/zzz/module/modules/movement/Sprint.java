package dev.zzz.module.modules.movement;

import dev.zzz.event.EventTarget;
import dev.zzz.event.world.EventStrafe;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.modules.combat.AutoGapple;
import dev.zzz.module.modules.combat.Gapple;
import dev.zzz.module.modules.combat.SuperKnockback;
import dev.zzz.module.modules.world.GApple;

public class Sprint
extends Module {
    public Sprint() {
        super("Sprint", Category.Movement);
        this.setState(true);
    }

    @EventTarget
    public void onUpdate(EventStrafe event) {
        if (AutoGapple.eating || Gapple.eating || GApple.eating) {
            Sprint.mc.gameSettings.keyBindSprint.pressed = false;
        }else {
            if (SuperKnockback.canSprint()) {
                Sprint.mc.gameSettings.keyBindSprint.pressed = true;
            }
        }

    }
}


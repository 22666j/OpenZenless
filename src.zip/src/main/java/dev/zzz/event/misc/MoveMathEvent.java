package dev.zzz.event.misc;

import dev.zzz.event.api.events.callables.EventCancellable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public final class MoveMathEvent extends EventCancellable {
}

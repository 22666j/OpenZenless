package dev.zzz.event.misc;

import dev.zzz.event.api.events.callables.EventCancellable;

public class EventDisplayChest
extends EventCancellable {
    private String q;

    public EventDisplayChest(String sb) {
        this.q = sb;
    }

    public String getString() {
        return this.q;
    }
}


package dev.zzz.event.misc;

import dev.zzz.event.api.events.callables.EventCancellable;

public class EventRightClick extends EventCancellable {
}

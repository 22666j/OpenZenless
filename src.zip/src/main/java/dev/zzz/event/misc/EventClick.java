package dev.zzz.event.misc;

import dev.zzz.event.api.events.Event;

public class EventClick
implements Event {
}


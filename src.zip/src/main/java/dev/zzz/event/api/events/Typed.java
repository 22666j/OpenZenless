package dev.zzz.event.api.events;

public interface Typed {
    public byte getType();
}


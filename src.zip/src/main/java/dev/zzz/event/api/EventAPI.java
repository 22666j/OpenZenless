package dev.zzz.event.api;

public final class EventAPI {
    public static final String VERSION = String.format("%s-%s", "0.7", "beta");
    public static final String[] AUTHORS = new String[]{"DarkMagician6"};

    private EventAPI() {
    }
}


package dev.zzz.event;

import net.minecraft.network.ThreadQuickExitException;

public class EventCancelledException
extends ThreadQuickExitException {
}


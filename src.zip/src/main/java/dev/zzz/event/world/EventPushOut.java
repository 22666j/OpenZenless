package dev.zzz.event.world;

import dev.zzz.event.api.events.callables.EventCancellable;

public class EventPushOut
extends EventCancellable {
}


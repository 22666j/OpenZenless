package dev.zzz.event.world;

import dev.zzz.event.api.events.Event;
import net.minecraft.entity.Entity;

public class EventLivingUpdate
implements Event {
    public Entity entity;

    public EventLivingUpdate() {

    }

    public Entity getEntity() {
        return this.entity;
    }
}


package dev.zzz.event.world;

import dev.zzz.event.api.events.Event;

public class EventTick
implements Event {
}


package dev.zzz.event.world;

import dev.zzz.event.api.events.Event;

public class EventPostUpdate implements Event {
}

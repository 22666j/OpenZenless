package dev.zzz.event.rendering;

import dev.zzz.event.api.events.Event;

public class EventPostRenderPlayer
implements Event {
}


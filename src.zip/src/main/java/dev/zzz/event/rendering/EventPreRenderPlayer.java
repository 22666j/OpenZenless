package dev.zzz.event.rendering;

import dev.zzz.event.api.events.Event;

public class EventPreRenderPlayer
implements Event {
}


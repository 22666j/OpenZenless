package dev.zzz.event.rendering;

import dev.zzz.event.api.events.Event;

public class EventDrawText
implements Event {
    public String text;

    public EventDrawText(String text) {
        this.text = text;
    }
}


/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package dev.zzz.hyt.party.ui.hyt.germ.component;

public interface GermComponent {
    public void drawComponent(String var1, int var2, int var3, int var4, int var5);

    public void mouseClicked(String var1);

    public int getHeight();

    public int getSeparation();
}


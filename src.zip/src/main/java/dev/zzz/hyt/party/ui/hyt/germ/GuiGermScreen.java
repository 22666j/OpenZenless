/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package dev.zzz.hyt.party.ui.hyt.germ;

import net.minecraft.client.gui.GuiScreen;

public abstract class GuiGermScreen
extends GuiScreen {
    public abstract String getUUID();
}


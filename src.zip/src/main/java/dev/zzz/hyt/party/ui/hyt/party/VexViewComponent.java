/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package dev.zzz.hyt.party.ui.hyt.party;

public class VexViewComponent {
    private final String id;

    public VexViewComponent(String id) {
        this.id = id;
    }

    public String getId() {
        return this.id;
    }
}


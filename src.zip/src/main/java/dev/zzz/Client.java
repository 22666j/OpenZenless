package dev.zzz;

import com.diaoling.client.viaversion.vialoadingbase.ViaLoadingBase;
import com.viaversion.viaversion.api.protocol.version.ProtocolVersion;
import com.yumegod.obfuscation.FlowObfuscate;
import com.yumegod.obfuscation.Native;
import dev.zzz.command.CommandManager;
import dev.zzz.config.ConfigManager;
import dev.zzz.event.EventManager;
import dev.zzz.gui.Newsplash;
import dev.zzz.gui.altmanager.AltManager;
import dev.zzz.gui.ui.UiManager;
import dev.zzz.gui.video.VideoPlayer;
import dev.zzz.module.Module;
import dev.zzz.module.ModuleManager;
import dev.zzz.module.values.Value;
import dev.zzz.utils.IrcManager;
import dev.zzz.utils.client.menu.BetterMainMenu;
import dev.zzz.utils.client.menu.NormalMainMenu;
import dev.zzz.utils.component.*;
import dev.zzz.utils.RotationComponent;
import dev.zzz.utils.SlotSpoofManager;
import dev.zzz.utils.YawPitchHelper;
import dev.zzz.utils.novoshader.BackgroundShader;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;

import dev.zzz.utils.player.MovementUtils;
import lombok.Getter;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Util;
import net.netease.PacketProcessor;
import net.viamcp.ViaMCP;
import org.apache.commons.compress.utils.IOUtils;
import org.bytedeco.javacv.FFmpegFrameGrabber;
import org.lwjgl.compatibility.display.Display;
import sun.misc.Unsafe;

@Native
public class Client {
    @Getter
    private ExecutorService executor;
    public static Minecraft mc = Minecraft.getMinecraft();
    public static Client instance;
    public static final File BACKGROUND = new File(mc.mcDataDir, "Background");
    public static String NAME = "Zenless";
    public static String VERSION = "250117";
    public static ResourceLocation cape;
    public String USER = "22666j";
    private static boolean logged;
    public String commandPrefix = ".";
    public ConfigManager configManager;
    @Getter
    public AltManager altManager;
    public ModuleManager moduleManager;
    public CommandManager commandManager;
    public UiManager uiManager;
    @Getter
    public SlotSpoofManager slotSpoofManager;
    @Getter
    private final VideoPlayer player = new VideoPlayer();
    @Getter
    public YawPitchHelper yawPitchHelper;
    public List<Float> cGUIPosX = new ArrayList<>();
    public List<Float> cGUIPosY = new ArrayList<>();
    public List<Module> cGUIInSetting = new ArrayList<>();
    public List<Value<?>> cGUIInMode = new ArrayList();
    public static Unsafe theUnsafe;
    public BackgroundShader blobShader;

    public String getUser() {
        return this.USER;
    }

    public String getVersion() {
        return VERSION;
    }

    public boolean isLogged() {
        return logged;
    }

    public void setLogged(boolean state) {
        logged = state;
    }
    public static String getIGN() { // 部分网易服务器session和ign对不上，比如雅虎宇宙
        return mc.thePlayer == null ? mc.getSession().getUsername() : mc.thePlayer.getName();
    }
    public Client() {
        logged = false;
    }
    public static boolean oOOoo = true;
    public void init() {
        //VideoPlayer videoPlayer = new VideoPlayer();
        try {
            ViaMCP.create();
            ViaMCP.INSTANCE.initAsyncSlider();
           // ViaLoadingBase.getInstance().reload(ProtocolVersion.v1_12_2);
            //ViaMCP.registerPackets();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Client.logged = true;
        try {
            try {
                //SplashScreen.setProgress(10, "ModuleManager");
                Client.instance = this;
                //SplashScreen.setProgress(11, "EventManager");
                this.altManager = new AltManager();
                this.commandManager = new CommandManager();
                this.configManager = new ConfigManager();
                this.uiManager = new UiManager();
                this.slotSpoofManager = new SlotSpoofManager();
                this.yawPitchHelper = new YawPitchHelper();
                this.setWindowIcon();
                try {
                    Client.instance.setLogged(true);
                    Client.instance.moduleManager = new ModuleManager();
                    EventManager.register(Client.instance);
                    EventManager.register(new RotationComponent());
                    EventManager.register(MovementUtils.INSTANCE);
                    EventManager.register(new FallDistanceComponent());
                    EventManager.register(new InventoryClickFixComponent());
                    EventManager.register(new PingSpoofComponent());
                    EventManager.register(new BadPacketsComponent());
                    EventManager.register(new PacketProcessor());
                    Client.instance.moduleManager.init();
                    Client.instance.commandManager.init();
                    Client.instance.uiManager.init();
                    Client.instance.configManager.loadAllConfig();
                    //IrcManager.main();
                    mc.displayGuiScreen(new Newsplash());
                    //mc.displayGuiScreen(new BetterMainMenu());
                }

                catch (Exception ignored) {}
            }
            catch (Exception ignored) {
            }
        }
        catch (Throwable ignored) {
        }
    }


    public static void displayGuiScreen(GuiScreen guiScreenIn) {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void setWindowIcon() {
        Util.EnumOS util$enumos = Util.getOSType();
        if (util$enumos != Util.EnumOS.OSX) {
            InputStream inputstream1;
            InputStream inputstream;
            block5: {
                inputstream = null;
                inputstream1 = null;
                try {
                    inputstream = Client.mc.mcDefaultResourcePack.getInputStreamAssets(new ResourceLocation("/assets/minecraft/express/icon/bh16.png"));
                    inputstream1 = Client.mc.mcDefaultResourcePack.getInputStreamAssets(new ResourceLocation("/assets/minecraft/express/icon/bh32.png"));
                    if (inputstream == null || inputstream1 == null) break block5;
                    Display.setIcon(new ByteBuffer[]{mc.readImageToBuffer(inputstream), mc.readImageToBuffer(inputstream1)});
                }
                catch (IOException ioexception) {
                    try {
                        Minecraft.logger.error("Couldn't set icon", ioexception);
                    }
                    catch (Throwable throwable) {
                        IOUtils.closeQuietly(inputstream);
                        IOUtils.closeQuietly(inputstream1);
                        throw throwable;
                    }
                    IOUtils.closeQuietly(inputstream);
                    IOUtils.closeQuietly(inputstream1);
                }
            }
            IOUtils.closeQuietly(inputstream);
            IOUtils.closeQuietly(inputstream1);
        }
    }
}


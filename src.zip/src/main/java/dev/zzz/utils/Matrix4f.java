package dev.zzz.utils;


import java.io.Serializable;

public class Matrix4f implements Serializable, Cloneable {
    public Matrix4f(org.lwjgl.compatibility.util.vector.Matrix4f matrix4f) {
    }
}


package dev.zzz.utils.misc;

import net.minecraft.client.Minecraft;

public interface MinecraftInstance {
    String AUTHOR = "Null dev team";
    public static final Minecraft mc = Minecraft.getMinecraft();
}


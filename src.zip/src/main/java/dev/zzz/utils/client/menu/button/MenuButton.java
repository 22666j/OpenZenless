package dev.zzz.utils.client.menu.button;

import dev.zzz.gui.altmanager.ColorUtils;
import dev.zzz.utils.client.menu.Screen;
import dev.zzz.utils.misc.MouseUtils;
import dev.zzz.utils.render.RenderUtil;
import dev.zzz.utils.render.RoundedUtils;
import dev.zzz.utils.render.animation.Animation;
import dev.zzz.utils.render.animation.Direction;
import dev.zzz.utils.render.animation.impl.DecelerateAnimation;
import dev.zzz.utils.render.fontRender.FontManager;

import java.awt.Color;

public class MenuButton
implements Screen {
    public final String text;
    private Animation hoverAnimation;
    public float x;
    public float y;
    public float width;
    public float height;
    public Runnable clickAction;

    public MenuButton(String text) {
        this.text = text;
    }

    @Override
    public void initGui() {
        this.hoverAnimation = new DecelerateAnimation(500, 1.0);
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        boolean hovered = MouseUtils.isHovering(this.x, this.y, this.width, this.height, mouseX, mouseY);
        this.hoverAnimation.setDirection(hovered ? Direction.FORWARDS : Direction.BACKWARDS);
        Color rectColor = new Color(85, 0, 255, 102);
        Color rectColor2 = new Color(28, 130, 250, 102);
        rectColor = ColorUtils.interpolateColorC(rectColor, rectColor2, (float)this.hoverAnimation.getOutput());
        RoundedUtils.drawRound(this.x, this.y, this.width, this.height, 3, rectColor);
        Color finalRectColor = rectColor;
        RenderUtil.drawBlur(3,2, () -> RoundedUtils.drawRound(this.x, this.y, this.width, this.height, 3, finalRectColor));
        RenderUtil.drawBloom(3, 4, 255, () -> RoundedUtils.drawRound(this.x, this.y, this.width, this.height, 3, new Color(0,0,0)));
        FontManager.arial20.drawCenteredString(this.text, this.x + this.width / 2.0f, this.y + FontManager.arial20.getMiddleOfBox(this.height) + 2.0f, -1);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        boolean hovered = MouseUtils.isHovering(this.x, this.y, this.width, this.height, mouseX, mouseY);
        if (hovered) {
            this.clickAction.run();
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
    }
}


package dev.zzz.utils.client;

import dev.zzz.Client;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;

import java.io.File;

import static dev.zzz.utils.client.HelperUtil.mc;

public class ChatUtil {
    public static void print(String prefix, String message) {
        if (mc.thePlayer != null) {
            mc.thePlayer.addChatMessage(new ChatComponentText("§7[§d§l" + prefix + "§r§7] " + message));
        }
    }
    public static void print(boolean prefix, String message) {
        if (mc.thePlayer != null) {
            if (prefix) message = "§7[§d§l" + Client.NAME + "§r§7] " + message;
            mc.thePlayer.addChatMessage(new ChatComponentText(message));
        }
    }

    public static void error(String message) {
        if (mc.thePlayer != null) {
            mc.thePlayer.addChatMessage(new ChatComponentText("§7[§c§lERROR§r§7] " + message));
        }
    }


    public static void scriptError(File scriptFile, String message) {
        if (mc.thePlayer != null) {
            mc.thePlayer.addChatMessage(new ChatComponentText("§d§lSCRIPT ERROR: §r§f" + scriptFile.getName() + " §c" + message));
        }
    }


    public static void print(Object o) {
        print(true, String.valueOf(o));
    }

    public static void send(String message) {
        if (mc.thePlayer != null) {
            mc.thePlayer.sendChatMessage(message);
        }
    }

}

package dev.zzz.utils.render;

public final class Translate {
}


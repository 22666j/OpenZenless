package dev.zzz.utils.render.animation;

import dev.zzz.utils.client.MathUtil;

public class AnimationUtils {
    long mc;
    public float anim;
    public float to;
    public float speed;

    public AnimationUtils(float anim, float to, float speed) {
        this.anim = anim;
        this.to = to;
        this.speed = speed;
        this.mc = System.currentTimeMillis();
    }

    public float getAnim() {
        int count = (int) ((System.currentTimeMillis() - this.mc) / 5L);
        if (count > 0) {
            this.mc = System.currentTimeMillis();
        }
        for (int i = 0; i < count; ++i) {
            this.anim = (float) MathUtil.lerp(this.anim, this.to, this.speed);
        }
        return this.anim;
    }

    public void setAnim(float anim) {
        this.anim = anim;
        this.mc = System.currentTimeMillis();
    }

    double lerpAngle(float start, float end, float amount) {
        float minAngle = (end - start + 180.0f) % 360.0f - 180.0f;
        return minAngle * amount + start;
    }
    public static float clamp(float number, float min, float max) {
        return number < min ? min : Math.min(number, max);
    }

    public static double animate(double target, double current, double speed) {
        boolean larger;
        if (current == target) {
            return current;
        }
        boolean bl = larger = target > current;
        if (speed < 0.0) {
            speed = 0.0;
        } else if (speed > 1.0) {
            speed = 1.0;
        }
        double dif = Math.max(target, current) - Math.min(target, current);
        double factor = dif * speed;
        if (factor < 0.1) {
            factor = 0.1;
        }
        if (larger) {
            if ((current += factor) >= target) {
                current = target;
            }
        } else if ((current -= factor) <= target) {
            current = target;
        }
        return current;
    }
}


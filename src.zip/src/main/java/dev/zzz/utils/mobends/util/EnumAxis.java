package dev.zzz.utils.mobends.util;

public enum EnumAxis {
    X,
    Y,
    Z;

}


package dev.zzz.utils.component;

import dev.zzz.Client;
import dev.zzz.event.EventTarget;
import dev.zzz.event.world.EventMotion;

public final class FallDistanceComponent {
    public static float distance;
    private float lastDistance;

    @EventTarget
    private void onMotion(EventMotion event) {
        if (event.isPre()) {
            float fallDistance = Client.mc.thePlayer.fallDistance;
            if (fallDistance == 0.0f) {
                distance = 0.0f;
            }
            distance += fallDistance - this.lastDistance;
            this.lastDistance = fallDistance;
        }
    }
}


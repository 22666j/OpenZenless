package dev.zzz.utils.player;

import dev.zzz.Client;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;

public class GetC03StatusUtil extends Client {
    public static final GetC03StatusUtil INSTANCE = new GetC03StatusUtil();
    public static int noMovePackets = 0;

    public static void packetEvent(Packet<?> packet) {
        if (packet instanceof C03PacketPlayer) {
            noMovePackets = ((C03PacketPlayer) packet).isMoving() ? 0 : ++noMovePackets;
        }
    }
}

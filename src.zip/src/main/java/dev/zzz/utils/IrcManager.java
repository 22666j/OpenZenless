package dev.zzz.utils;

import com.alkirc.client.IRCHandler;
import com.alkirc.client.IRCTransport;
import dev.zzz.Client;
import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumChatFormatting;

import java.io.IOException;
import java.util.Scanner;


/**
 * @Author: StaR4y
 * @Date: 2024/11/11
 * Time:20:42
 */
public class IrcManager {
    public static IRCTransport transport = new IRCTransport();
    private static EnumChatFormatting rankColor;

    public static void main() {
        try {
//            transport.start("localhost", 2245, new IRCHandler() {
            transport.start("154.37.214.127", 2245, new IRCHandler() {
                @Override
                public void onMessage(String sender,String message, String rank,String client) {
                    if(rank.equals("Owner") || rank.equals("Admin") || rank.equals("Dev") || rank.equals("Beta") || rank.equals("ZZZ") || rank.equals("User")) {
                        switch (rank) {
                            case "Owner":
                                rankColor = EnumChatFormatting.GOLD;
                                break;
                            case "Admin":
                                rankColor = EnumChatFormatting.DARK_RED;
                                break;
                            case "Dev":
                                rankColor = EnumChatFormatting.RED;
                                break;
                            case "Beta":
                                rankColor = EnumChatFormatting.DARK_GREEN;
                                break;
                            case "ZZZ":
                                rankColor = EnumChatFormatting.DARK_GREEN;
                                break;
                            case "User":
                                rankColor = EnumChatFormatting.GREEN;
                                break;
                        }
                    }else {
                        rankColor = EnumChatFormatting.GREEN;
                    }
                    DebugUtil.log(EnumChatFormatting.GREEN+"[Xylitol IRC] ["+client+"] "+rankColor + "[" + rank + "] " +  sender + "(" + transport.getIgn(sender) + ")" + EnumChatFormatting.RESET + ":" + message);
                }
                @Override
                public void onDisconnected(String message) {
                    System.out.println("IRC Disconnected: " + message);
                }

                @Override
                public void onConnected() {
                    System.out.println("IRC Connected");
                }

                @Override
                public String getInGameUsername() {
                    return Client.getIGN();
                }

                @Override
                public String getClientName() {
                    return "Qenless";
                }

                @Override
                public String getRank() {
                    return "ZZZ";
                }
            });
            transport.connect("22666J","***");//这个token是irc服务器验证我没写 厉害 能不能另外改

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

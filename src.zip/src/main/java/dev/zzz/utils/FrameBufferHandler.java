package dev.zzz.utils;

import org.lwjgl.opengl.GL11;
import java.nio.ByteBuffer;

public class FrameBufferHandler {
    private final int width;
    private final int height;
    private ByteBuffer prevFrameBuffer;
    private ByteBuffer currentFrameBuffer;
    private ByteBuffer interpolatedBuffer; // 预分配的插值缓冲区
    private int textureId; // 复用的纹理对象

    public FrameBufferHandler(int width, int height) {
        this.width = width;
        this.height = height;
        this.prevFrameBuffer = ByteBuffer.allocateDirect(width * height * 4);
        this.currentFrameBuffer = ByteBuffer.allocateDirect(width * height * 4);
        this.interpolatedBuffer = ByteBuffer.allocateDirect(width * height * 4); // 预分配插值缓冲区

        // 预生成纹理对象
        this.textureId = GL11.glGenTextures();
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
    }

    public void captureFrame() {
        // 交换缓冲区
        ByteBuffer temp = prevFrameBuffer;
        prevFrameBuffer = currentFrameBuffer;
        currentFrameBuffer = temp;

        // 从当前帧缓冲区读取像素
        currentFrameBuffer.clear();
        GL11.glReadPixels(0, 0, width, height, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, currentFrameBuffer);
    }

    public ByteBuffer getPrevFrameBuffer() {
        return prevFrameBuffer;
    }

    public ByteBuffer getCurrentFrameBuffer() {
        return currentFrameBuffer;
    }

    public ByteBuffer interpolateFrames(float t) {
        interpolatedBuffer.clear(); // 复用插值缓冲区
        for (int i = 0; i < width * height * 4; i++) {
            int prev = Byte.toUnsignedInt(prevFrameBuffer.get(i));
            int current = Byte.toUnsignedInt(currentFrameBuffer.get(i));
            int interpolated = (int) ((1 - t) * prev + t * current);
            interpolatedBuffer.put((byte) interpolated);
        }
        interpolatedBuffer.flip();
        return interpolatedBuffer;
    }

    public void renderInterpolatedFrame(float t) {
        ByteBuffer interpolatedFrame = interpolateFrames(t);

        // 绑定纹理并更新纹理数据
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA, width, height, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, interpolatedFrame);

        // 渲染纹理作为全屏四边形
        GL11.glBegin(GL11.GL_QUADS);
        GL11.glTexCoord2f(0, 0); GL11.glVertex2f(-1, -1);
        GL11.glTexCoord2f(1, 0); GL11.glVertex2f(1, -1);
        GL11.glTexCoord2f(1, 1); GL11.glVertex2f(1, 1);
        GL11.glTexCoord2f(0, 1); GL11.glVertex2f(-1, 1);
        GL11.glEnd();
        if (textureId != 0) {
            GL11.glDeleteTextures(textureId);
            textureId = 0; // 标记纹理已删除
        }
    }

    public void cleanup() {
        // 清理纹理对象
    }
}

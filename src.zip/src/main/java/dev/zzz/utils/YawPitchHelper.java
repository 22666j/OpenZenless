package dev.zzz.utils;

public class YawPitchHelper {
    public float realYaw = 0.0f;
    public float realPitch = 0.0f;
    public float realLastYaw = 0.0f;
    public float realLastPitch = 0.0f;
}


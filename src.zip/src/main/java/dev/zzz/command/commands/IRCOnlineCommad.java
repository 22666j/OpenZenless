package dev.zzz.command.commands;

import dev.zzz.command.Command;
import dev.zzz.utils.DebugUtil;
import dev.zzz.utils.IrcManager;
import top.fl0wowp4rty.phantomshield.annotations.Native;

import java.util.ArrayList;
import java.util.List;

public class IRCOnlineCommad extends Command {
    public IRCOnlineCommad() {
        super("online");
    }

    @Override
    public List<String> autoComplete(int arg, String[] args) {
        return new ArrayList<>();
    }

    @Override
    public void run(String[] var1) {
        DebugUtil.log("OnlineUserList: "+ IrcManager.transport.userToIgnMap);
    }

}

package dev.zzz.command.commands;
import dev.zzz.Client;
import dev.zzz.command.Command;
import dev.zzz.utils.IrcManager;
import top.fl0wowp4rty.phantomshield.annotations.Native;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class IRCCommand extends Command {
    public IRCCommand() {
        super("irc");
    }

    @Override
    public List<String> autoComplete(int arg, String[] args) {
        return new ArrayList<>();
    }

    @Override
    public void run(String[] var1) {
        String sb = Arrays.toString(var1);
        String modifiedMessage = sb.replace(Client.instance.commandManager.prefix + "irc", " ").replace("[", "").replace("]", "");
        IrcManager.transport.sendChat(modifiedMessage);
    }

}
package dev.zzz.gui.notification;

import dev.zzz.module.modules.render.HUD;
import dev.zzz.utils.misc.MinecraftInstance;
import dev.zzz.utils.render.ColorUtil;
import dev.zzz.utils.render.RenderUtil;
import dev.zzz.utils.render.RoundedUtils;
import dev.zzz.utils.render.animation.AnimTimeUtil;
import dev.zzz.utils.render.animation.Animation;
import dev.zzz.utils.render.animation.impl.DecelerateAnimation;
import dev.zzz.utils.render.fontRender.FontManager;
import java.awt.Color;

public class Notification
implements MinecraftInstance {
    private final NotificationType notificationType;
    private final String title;
    private final String description;
    private final float time;
    private final AnimTimeUtil timerUtil;
    private final Animation animation;

    public Notification(NotificationType type, String title, String description) {
        this(type, title, description, NotificationManager.getToggleTime());
    }

    public Notification(NotificationType type, String title, String description, float time) {
        this.title = title;
        this.description = description;
        this.time = (long)(time * 1000.0f);
        this.timerUtil = new AnimTimeUtil();
        this.notificationType = type;
        this.animation = new DecelerateAnimation(300, 1.0);
    }
    public void drawDefault(float x, float y, float width, float height, float alpha) {
        RoundedUtils.drawRound(x, y, width, height, 2, new Color(0, 0, 0, 100));
        //tenacityBoldFont14.drawString(getTitle(), x + 11, y + 2f, new Color(255, 255, 255, 255));
        FontManager.bold22.drawString(getDescription(), x + 11, y + FontManager.bold18.getHeight() - 3, new Color(255, 255, 255, 255));
        RoundedUtils.drawRound(x + 2f, y + 10f, 2, 4, 0.5f,  notificationType.getColor());
        RoundedUtils.drawGradientHorizontal(x, y, ((getTime() - getTimerUtil().getTime()) / getTime()) * width, height, 2,new Color(0,0,0,105),new Color(0,0,0,105));
    }

    public void drawLettuce(float x2, float y2, float width, float height) {
        RoundedUtils.drawRound(x2, y2 + 6, 1, FontManager.bold22.getHeight() - 7, 0, HUD.color(0));
        RoundedUtils.drawRound(x2, y2, width, height, 2, new Color(25,25,25,100));
        Color textColor = ColorUtil.applyOpacity(Color.GRAY.brighter(), 80.0f);
        FontManager.bold22.drawString(this.getTitle(), x2 + 8f, y2 + 6, Color.WHITE.getRGB());
        FontManager.arial20.drawString(this.getDescription(), x2 + 8f, y2 + 18.0f, textColor.getRGB());
    }

    public void blurLettuce(float x2, float y2, float width, float height, boolean glow) {
        RoundedUtils.drawRound(x2, y2 + 6, 1, FontManager.bold22.getHeight() - 7, 0, HUD.color(0));
        RoundedUtils.drawRound(x2, y2, width, height, 2, new Color(25,25,25));
        RenderUtil.resetColor();
    }

    public NotificationType getNotificationType() {
        return this.notificationType;
    }

    public String getTitle() {
        return this.title;
    }

    public String getDescription() {
        return this.description;
    }

    public float getTime() {
        return this.time;
    }

    public AnimTimeUtil getTimerUtil() {
        return this.timerUtil;
    }

    public Animation getAnimation() {
        return this.animation;
    }
}


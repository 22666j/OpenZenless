package dev.zzz.gui.ui.modules;

import dev.zzz.event.EventTarget;
import dev.zzz.event.rendering.EventRender2D;
import dev.zzz.event.rendering.EventShader;
import dev.zzz.gui.ui.UiModule;
import dev.zzz.utils.render.RoundedUtils;
import dev.zzz.utils.render.fontRender.FontManager;

import java.awt.*;

public class BlockRate extends UiModule {
    public BlockRate() {
        super("BlockRate", 10.0, 100.0, 100, 30);
    }
    @EventTarget
    public void onRender2D(EventRender2D e) {
        double x = this.getPosX();
        double y = this.getPosY();
        RoundedUtils.drawRound((float)x, (float)y, 100, 25, 2, new Color(0,0,0,130));
        FontManager.bold22.drawStringDynamic(" BlockRate:", x , y + 9, 1, 6);
        if (mc.thePlayer.isBlocking()) {
            if (mc.thePlayer.ticksExisted % 4 == 0) {
                FontManager.bold22.drawStringDynamic("80%", x + 70, y + 9, 1, 6);
            }
            else  {
                FontManager.bold22.drawStringDynamic("100%", x + 70, y + 9, 1, 6);
            }
        }
        else {
            FontManager.bold22.drawStringDynamic("0%", x + 70 , y + 9, 1, 6);
        }
    }
    @EventTarget
    public void onShader(EventShader e){
        double x = this.getPosX();
        double y = this.getPosY();
        RoundedUtils.drawRound((float)x, (float)y, 100, 25, 2, new Color(0,0,0));
    }
}

package dev.zzz.gui.ui.modules;

import dev.zzz.event.EventTarget;
import dev.zzz.event.rendering.EventRender2D;
import dev.zzz.event.rendering.EventShader;
import dev.zzz.gui.ui.UiModule;
import dev.zzz.module.modules.render.HUD;
import dev.zzz.module.modules.render.KillEffect;
import dev.zzz.module.modules.world.PlayerWarn;
import dev.zzz.utils.render.RenderUtil;
import dev.zzz.utils.render.RoundedUtils;
import dev.zzz.utils.render.fontRender.FontManager;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.Gui;
import net.minecraft.entity.player.EntityPlayer;

import java.awt.*;

public class Session extends UiModule {
    public Session() {
        super("Session", 10.0, 50.0, 200, 80);
        resetTimer();
    }
    private long startTime;
    @EventTarget
    public void onShader(EventShader e){
        double x = this.getPosX();
        double y = this.getPosY();
        double width = 130.0;
        double height = 55.0;
        RoundedUtils.drawRoundOutline((float)x, (float)y, (float)width, (float)height, 10.0f, 0.1f, new Color(0, 0, 0, 255), new Color(0, 0, 0, 255));
    }

    private String risegetTime() {
        long currentTime = System.currentTimeMillis();
        long elapsed = currentTime - this.startTime;
        int seconds = (int)(elapsed / 1000L) % 60;
        int minutes = (int)(elapsed / 60000L) % 60;
        return String.format("%02dminutes %02dseconds", minutes, seconds);
    }

    @EventTarget
    public void onRender2D(EventRender2D e){
        double x = this.getPosX();
        double y = this.getPosY();
        FontManager.arial22.drawSessionString("Session Stats", x + 28.0, y + 6.0, HUD.color(0), HUD.color(8));
        FontManager.arial20.drawString(this.risegetTime(), (float)x + 17.0f, (float)y + 22.0f, Color.white.getRGB());
        FontManager.arial20.drawString("kills:" + KillEffect.kills, (float)x + 28.0f, (float)y + 38.0f, Color.white.getRGB());
        FontManager.arial20.drawString("wins:" + KillEffect.wins, (float)x + 74.0f, (float)y + 38.0f, Color.white.getRGB());
    }
    private void resetTimer() {
        this.startTime = System.currentTimeMillis();
    }
    private String getTime() {
        long currentTime = System.currentTimeMillis();
        long elapsed = currentTime - startTime;

        int seconds = (int) (elapsed / 1000) % 60;
        int minutes = (int) (elapsed / (1000 * 60)) % 60;

        return String.format("%02dm %02ds", minutes, seconds);
    }
    public void drawLine(double x, double y, double width, double height, Color color){
        Gui.drawRect(x, y, x + width, y + height, color.getRGB());
    }

}

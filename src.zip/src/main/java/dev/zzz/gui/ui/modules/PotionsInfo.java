package dev.zzz.gui.ui.modules;

import dev.zzz.event.EventTarget;
import dev.zzz.event.rendering.EventRender2D;
import dev.zzz.event.rendering.EventShader;
import dev.zzz.gui.ui.UiModule;
import dev.zzz.module.modules.render.HUD;
import dev.zzz.utils.render.RenderUtil;
import dev.zzz.utils.render.RoundedUtils;
import dev.zzz.utils.render.animation.Direction;
import dev.zzz.utils.render.animation.impl.ContinualAnimation;
import dev.zzz.utils.render.animation.impl.EaseBackIn;
import dev.zzz.utils.render.fontRender.FontManager;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;

public class PotionsInfo
        extends UiModule {
    private int maxString = 0;
    private final Map<Integer, Integer> potionMaxDurations = new HashMap<Integer, Integer>();
    private final ContinualAnimation widthanimation = new ContinualAnimation();
    private final ContinualAnimation heightanimation = new ContinualAnimation();
    private final EaseBackIn animation = new EaseBackIn(200, 1.0, 1.3f);
    List<PotionEffect> effects = new ArrayList<PotionEffect>();

    public PotionsInfo() {
        super("PotionsInfo", 20.0, 40.0, 150.0, 60.0);
    }

    private String get(PotionEffect potioneffect) {
        Potion potion = Potion.potionTypes[potioneffect.getPotionID()];
        String s1 = I18n.format(potion.getName(), new Object[0]);
        s1 = s1 + " " + this.intToRomanByGreedy(potioneffect.getAmplifier() + 1);
        return s1;
    }
    public int getTotalHeight()
    {
        int h;
        if(mc.thePlayer.getActivePotionEffects().size() == 0){
            h =16;
        }else if(mc.thePlayer.getActivePotionEffects().size() == 1){
            h =52;
        }else if(mc.thePlayer.getActivePotionEffects().size() == 2){
            h =38;
        } else if(mc.thePlayer.getActivePotionEffects().size() == 3){
            h =33;
        } else if(mc.thePlayer.getActivePotionEffects().size() == 4) {
            h=31;
        } else if (mc.thePlayer.getActivePotionEffects().size() == 5){
            h=29;
        } else {
            h=28;
        }

        return h * mc.thePlayer.getActivePotionEffects().size();
    }

    private String intToRomanByGreedy(int num) {
        int[] values = new int[]{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] symbols = new String[]{"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < values.length && num >= 0; ++i) {
            while (values[i] <= num) {
                num -= values[i];
                stringBuilder.append(symbols[i]);
            }
        }
        return stringBuilder.toString();
    }

    @EventTarget
    public void onShader(EventShader event) {
        int x2 = (int)this.getPosX();
        int y2 = (int)this.getPosY();
        if (this.effects.isEmpty()) {
            return;
        }
        RoundedUtils.drawRound(x2, y2 - 25 /*+ i2 - offsetY*/, (int)this.widthanimation.getOutput(), getTotalHeight(), 4.0f, new Color(0,0,0));
    }

    @EventTarget
    public void onRender2D(EventRender2D event) {
        this.effects = PotionsInfo.mc.thePlayer.getActivePotionEffects().stream().sorted(Comparator.comparingInt(it -> FontManager.arial18.getStringWidth(this.get((PotionEffect)it)))).collect(Collectors.toList());
        int x2 = (int)this.getPosX();
        int y2 = (int)this.getPosY();
        int offsetX = 21;
        int offsetY = 14;
        int i2 = 16;
        ArrayList<Integer> needRemove = new ArrayList<Integer>();
        for (Map.Entry<Integer, Integer> entry : this.potionMaxDurations.entrySet()) {
            if (PotionsInfo.mc.thePlayer.getActivePotionEffect(Potion.potionTypes[entry.getKey()]) != null) continue;
            needRemove.add(entry.getKey());
        }
        Iterator<Integer> iterator = needRemove.iterator();
        while (iterator.hasNext()) {
            int id = (Integer)((Object)iterator.next());
            this.potionMaxDurations.remove(id);
        }
        for (PotionEffect effect : this.effects) {
            if (this.potionMaxDurations.containsKey(effect.getPotionID()) && this.potionMaxDurations.get(effect.getPotionID()) >= effect.getDuration()) continue;
            this.potionMaxDurations.put(effect.getPotionID(), effect.getDuration());
        }
        float width = !this.effects.isEmpty() ? 125 : 0.0f;
        float height = this.effects.size() * 25;
        this.widthanimation.animate(width, 20);
        this.heightanimation.animate(height, 20);
        if (PotionsInfo.mc.currentScreen instanceof GuiChat && this.effects.isEmpty()) {
            this.animation.setDirection(Direction.FORWARDS);
        } else if (!(PotionsInfo.mc.currentScreen instanceof GuiChat)) {
            this.animation.setDirection(Direction.BACKWARDS);
        }
        RenderUtil.scaleStart(x2 + 50, y2 + 15, (float)this.animation.getOutput());
        FontManager.arial18.drawStringWithShadow("Potion Example", (float)x2 + 52.0f - (float)(FontManager.arial18.getStringWidth("Potion Example") / 2), y2 + 18 - FontManager.arial18.getHeight() / 2, new Color(255, 255, 255, 60).getRGB());
        RenderUtil.scaleEnd();
        if (this.effects.isEmpty()) {
            this.maxString = 0;
        }
        if (!this.effects.isEmpty()) {
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.disableLighting();
            RoundedUtils.drawRound(x2, y2 - 25 /*+ i2 - offsetY*/, (int)this.widthanimation.getOutput(), getTotalHeight(), 4.0f, new Color(19, 19, 19, 150));
            FontManager.bold24.drawStringDynamic("Potion", x2 + 21, y2 - 19, 1, 6);
            FontManager.icon22.drawStringDynamic("c", x2 + 7, y2 - 18, 1, 6);
            drawLine(x2, y2 - 19, 2, 10, HUD.color(0));
            for (PotionEffect potioneffect : this.effects) {
                Potion potion = Potion.potionTypes[potioneffect.getPotionID()];
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                if (potion.hasStatusIcon()) {
                    mc.getTextureManager().bindTexture(new ResourceLocation("textures/gui/container/inventory.png"));
                    int i1 = potion.getStatusIconIndex();
                    GlStateManager.enableBlend();
                    PotionsInfo.mc.ingameGUI.drawTexturedModalRect(x2 + offsetX - 17, y2 + i2 - offsetY - 1, 0 + i1 % 8 * 18, 198 + i1 / 8 * 18, 18, 18);
                }
                float potionDurationRatio = (float)potioneffect.getDuration() / (potionMaxDurations.get(potioneffect.getPotionID()) != null ? potionMaxDurations.get(potioneffect.getPotionID()) : 1);
                String s2 = Potion.getDurationString(potioneffect);
                String s1 = this.get(potioneffect);
                FontManager.arial18.drawStringWithShadow(s1, x2 + offsetX + 3, y2 + i2 - offsetY - 1, -1);
                int finalI = i2;
                RoundedUtils.drawGradientCornerLR(x2 + offsetX + 3, y2 + finalI + 11 - offsetY - 1, 90 * potionDurationRatio, 4.0f, 1, HUD.color(1), HUD.color(6));
                i2 = i2 + 23;
                if (this.maxString >= PotionsInfo.mc.fontRendererObj.getStringWidth(s1)) continue;
                this.maxString = PotionsInfo.mc.fontRendererObj.getStringWidth(s1);
            }
        }
    }
    public void drawLine(double x, double y, double width, double height, Color color){
        Gui.drawRect(x, y, x + width, y + height, color.getRGB());
    }
}


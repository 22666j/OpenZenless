package dev.zzz.gui.ui.modules;

import dev.zzz.event.EventTarget;
import dev.zzz.event.rendering.EventRender2D;
import dev.zzz.event.rendering.EventShader;
import dev.zzz.gui.ui.UiModule;
import dev.zzz.module.modules.render.HUD;
import dev.zzz.utils.render.RoundedUtils;
import dev.zzz.utils.render.fontRender.FontManager;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.item.ItemStack;

import java.awt.*;

public class InventoryHUD extends UiModule {
    public InventoryHUD() {
        super("InventoryHUD", 10.0, 100.0, 200, 80);
    }
    @EventTarget
    public void onShader(EventShader e){
        double x = this.getPosX();
        double y = this.getPosY();
        int paddingX = 4;
        int paddingY = 4 + FontManager.bold24.getHeight();

        float width = 162 + paddingX;
        float height = 60 + FontManager.bold24.getHeight() + 4;
        RoundedUtils.drawRound((float)x, (float)y, width, height, 2, new Color(0,0,0));
        this.drawLine(x, y + 5, 2, 10, HUD.color(0));
    }
    @EventTarget
    public void onRender2D(EventRender2D e){
        double x = this.getPosX();
        double y = this.getPosY();
        int paddingX = 4;
        int paddingY = 4 + FontManager.bold24.getHeight();

        float width = 162 + paddingX;
        float height = 60 + FontManager.bold24.getHeight() + 4;
        RoundedUtils.drawRound((float)x, (float)y, width, height, 2, new Color(0,0,0,130));
        this.drawLine(x, y + 5, 2, 10, HUD.color(0));
        FontManager.bold24.drawStringDynamic("Inventory", x + 21, y + 5, 1, 6);
        FontManager.icon22.drawStringDynamic("a", x + 7, y + 6, 1, 6);
        ItemStack[] inventory = mc.thePlayer.inventory.mainInventory;

        boolean hasItems = false;

        for (int i = 9; i < inventory.length; i++) {
            ItemStack stack = inventory[i];
            if (stack != null) {
                hasItems = true;
                int itemX = (int)x + ((i - 9) % 9) * 18 + paddingX;
                int itemY = (int)y + ((i - 9) / 9) * 18 + paddingY;

                drawItemStack(stack, itemX, itemY);
            }
        }

        if (!hasItems) {
            String emptyText = "Empty";
            int textWidth = FontManager.arial20.getStringWidth(emptyText);
            int textX = (int)x + (int) (width / 2) - (textWidth / 2);
            int textY = (int)y + (int) (height / 2) - (FontManager.arial20.getHeight() / 2) + (FontManager.bold24.getHeight() / 2);
            FontManager.arial20.drawStringWithShadow(emptyText, textX, textY, new Color(255, 255, 255, 200).getRGB());
        }
    }
    public void drawLine(double x, double y, double width, double height, Color color){
        Gui.drawRect(x, y, x + width, y + height, color.getRGB());
    }

    private void drawItemStack(ItemStack stack, int x, int y) {
        RenderItem itemRender = mc.getRenderItem();

        GlStateManager.pushMatrix();
        RenderHelper.enableGUIStandardItemLighting();
        GlStateManager.disableLighting();
        GlStateManager.enableRescaleNormal();
        GlStateManager.enableColorMaterial();
        GlStateManager.enableLighting();
        itemRender.zLevel = 200.0F;

        itemRender.renderItemAndEffectIntoGUI(stack, x, y);
        itemRender.renderItemOverlayIntoGUI(FontManager.arial16, stack, x, y, null);

        itemRender.zLevel = 0.0F;
        GlStateManager.popMatrix();
        GlStateManager.disableLighting();
    }
}

package dev.zzz.gui.ui.modules;

import dev.zzz.Client;
import dev.zzz.event.EventTarget;
import dev.zzz.event.rendering.EventRender2D;
import dev.zzz.event.rendering.EventShader;
import dev.zzz.gui.ui.UiModule;
import dev.zzz.module.Category;
import dev.zzz.module.Module;
import dev.zzz.module.modules.render.HUD;
import dev.zzz.utils.render.ColorUtil;
import dev.zzz.utils.render.RenderUtil;
import dev.zzz.utils.render.RoundedUtils;
import dev.zzz.utils.render.animation.Animation;
import dev.zzz.utils.render.animation.Direction;
import dev.zzz.utils.render.fontRender.FontManager;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.EnumChatFormatting;

import static dev.zzz.module.modules.render.HUD.mcfont;

public class ModuleList
extends UiModule {
    public List<Module> modules;

    public ModuleList() {
        super("ModuleList", RenderUtil.width(), 0.0, 100.0, 0.0);
    }

    @EventTarget
    public void blur(EventShader event) {
        double yOffset = 0.0;
        ScaledResolution sr = new ScaledResolution(mc);
        for (Module module : this.modules) {
            if (((Boolean)HUD.importantModules.getValue()).booleanValue() && module.getCategory() == Category.Render) continue;
            Animation moduleAnimation = module.getAnimation();
            if (!module.getState() && moduleAnimation.finished(Direction.BACKWARDS)) continue;
            String displayText = this.formatModule(module);
            double textWidth = FontManager.arial18.getStringWidth(displayText);
            double xValue = sr.getScaledWidth() - 10;
            boolean flip = xValue <= (double)((float)sr.getScaledWidth() / 2.0f);
            double x2 = flip ? xValue : (double)sr.getScaledWidth() - (textWidth + 3.0);
            double y2 = yOffset + 4.0;
            double heightVal = (Double)HUD.height.getValue() - 2.0;
            switch (((ANIM)((Object)HUD.animation.getValue())).name()) {
                case "MoveIn": {
                    if (flip) {
                        x2 -= Math.abs((moduleAnimation.getOutput() - 1.0) * ((double)sr.getScaledWidth() - (2.0 + textWidth)));
                        break;
                    }
                    x2 += Math.abs((moduleAnimation.getOutput() - 1.0) * (2.0 + textWidth));
                    break;
                }
                case "ScaleIn": {
                    RenderUtil.scaleStart((float)(x2 + (double)((float)FontManager.arial18.getStringWidth(displayText) / 2.0f)), (float)(y2 + heightVal / 2.0 - (double)((float)FontManager.arial18.getHeight() / 2.0f)), (float)moduleAnimation.getOutput());
                }
            }
            if (((Boolean)HUD.background.getValue()).booleanValue()) {
                RoundedUtils.drawRound((float)(x2 - 2.0), (float)(y2 - 3.0), FontManager.arial18.getStringWidth(displayText) + 5, (float)13, HUD.alpha.getValue().floatValue(), new Color(0, 0, 0));
            }
            if (((ANIM)((Object)HUD.animation.getValue())).name() == "ScaleIn") {
                RenderUtil.scaleEnd();
            }
            yOffset += moduleAnimation.getOutput() * heightVal + 3;
        }
    }

    private String formatModule(Module module) {
        String name = module.getName();
        name = name.replaceAll(" ", "");
        String formatText = "%s %s%s";
        String suffix = module.getSuffix();
        if (suffix == null || suffix.isEmpty()) {
            return name;
        }
        return String.format(formatText, new Object[]{name, EnumChatFormatting.GRAY, suffix});
    }

    @EventTarget
    public void onRender2D(EventRender2D event) {
        ArrayList<Module> moduleList = new ArrayList<Module>();
        moduleList.addAll(Client.instance.moduleManager.getModules());
        if (this.modules == null) {
            this.modules = moduleList;
            this.modules.removeIf(module -> module.getCategory() == Category.Render && (Boolean)HUD.importantModules.getValue() != false);
        }
        this.modules.sort(Comparator.<Module>comparingDouble(m -> {
            String name = m.getName() + (m.getSuffix() != "" ? " " + m.getSuffix() : "");
            if (mcfont.isEnabled()){
                return mc.fontRendererObj.getStringWidth(name);
            }
            return FontManager.arial18.getStringWidth(name);
        }).reversed());
        double yOffset = 0.0;
        ScaledResolution sr = new ScaledResolution(mc);
        int count = 0;
        for (Module module2 : this.modules) {
            if (((Boolean)HUD.importantModules.getValue()).booleanValue() && module2.getCategory() == Category.Render) continue;
            Animation moduleAnimation = module2.getAnimation();
            moduleAnimation.setDirection(module2.getState() ? Direction.FORWARDS : Direction.BACKWARDS);
            if (!module2.getState() && moduleAnimation.finished(Direction.BACKWARDS)) continue;
            String displayText = this.formatModule(module2);
            double textWidth;
            if(mcfont.isEnabled()){
                textWidth = mc.fontRendererObj.getStringWidth(displayText);
            }else{
                textWidth = FontManager.arial18.getStringWidth(displayText);
            }
            double xValue = sr.getScaledWidth() - 10;
            boolean flip = xValue <= (double)((float)sr.getScaledWidth() / 2.0f);
            double x = flip ? xValue : (double)sr.getScaledWidth() - (textWidth + 3.0);
            float alphaAnimation = 1.0f;
            double y = yOffset + 4.0;
            double heightVal = (Double)HUD.height.getValue() - 2;
            switch (((ANIM)(HUD.animation.getValue())).name()) {
                case "MoveIn": {
                    if (flip) {
                        x -= Math.abs((moduleAnimation.getOutput() - 1.0) * ((double)sr.getScaledWidth() - (2.0 - textWidth)));
                        break;
                    }
                    x += Math.abs((moduleAnimation.getOutput() - 1.0) * (2.0 + textWidth));
                    break;
                }
                case "ScaleIn": {
                    RenderUtil.scaleStart((float)(x + (double)((float)FontManager.arial18.getStringWidth(displayText) / 2.0f)), (float)(y + heightVal / 2.0 - (double)((float)FontManager.arial18.getHeight() / 2.0f)), (float)moduleAnimation.getOutput());
                    alphaAnimation = (float)moduleAnimation.getOutput();
                }
            }
            if (((Boolean)HUD.background.getValue()).booleanValue()) {
                RoundedUtils.drawRound((float)(x - 2.0), (float)(y - 3.0), FontManager.arial18.getStringWidth(displayText) + 5, (float)13, HUD.alpha.getValue().floatValue(),ColorUtil.applyOpacity(new Color(20, 20, 20), ((Double)HUD.backgroundAlpha.getValue()).floatValue() * alphaAnimation));
            }
            if (((Boolean)HUD.hLine.getValue()).booleanValue()) {
                Gui.drawRect3((float)RenderUtil.width() - 1.0f, (float)(y - 3.0), 1.0, (float)heightVal, HUD.color(count).getRGB());
            }
            int textcolor = HUD.color(count).getRGB();
            if(mcfont.isEnabled()){
                mc.fontRendererObj.drawStringWithShadow(displayText, (float) x, (float) (y - 1.0 + (double) FontManager.arial18.getMiddleOfBox((float) 13)), ColorUtil.applyOpacity(textcolor, alphaAnimation));
            }else {
                FontManager.arial18.drawStringWithShadow(displayText, (float) x, (float) (y - 1.0 + (double) FontManager.arial18.getMiddleOfBox((float) 13)), ColorUtil.applyOpacity(textcolor, alphaAnimation));
            }
            if (((ANIM)(HUD.animation.getValue())).name() == "ScaleIn") {
                RenderUtil.scaleEnd();
            }
            yOffset += moduleAnimation.getOutput() * heightVal + 3;
            ++count;
        }
    }

    public static enum ANIM {
        MoveIn,
        ScaleIn;

    }
}


package dev.zzz.gui.ui.modules;

import dev.zzz.Client;
import dev.zzz.event.EventTarget;
import dev.zzz.event.rendering.EventRender2D;
import dev.zzz.event.rendering.EventShader;
import dev.zzz.gui.elements.drawEntityOnScreen;
import dev.zzz.gui.ui.UiModule;
import dev.zzz.module.modules.combat.KillAura;
import dev.zzz.module.modules.render.HUD;
import dev.zzz.utils.render.RoundedUtils;
import dev.zzz.utils.render.fontRender.FontManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;

import java.awt.*;

public class Info extends UiModule {
    public Info() {
        super("Info", 10.0, 50.0, 240, 120);
        resetTimer();
    }
    private long startTime;
    @EventTarget
    public void onShader(EventShader e){
        double x = this.getPosX();
        double y = this.getPosY();
        double width = 100;
        double height = 120;

        RoundedUtils.drawRound((float) x,(float) y,(float) width,(float) height, 5, new Color(0,0,0));
        RoundedUtils.drawRound(((float) x)+110,((float) y)+35,130,85, 5, new Color(0,0,0));
        RoundedUtils.drawRound(((float) x)+110,(float) y,130,25, 5, new Color(0,0,0));
        //this.drawLine(x, y + 5, 2, 10, HUD.color(0));
    }

    @EventTarget
    public void onRender2D(EventRender2D e){
        double x = this.getPosX();
        double y = this.getPosY();
        double width = 100;
        double height = 120;
        RoundedUtils.drawRound((float) x,(float) y,(float) width,(float) height, 5, new Color(0,0,0,130));
        RoundedUtils.drawRound(((float) x)+110,((float) y)+35,130,85, 5, new Color(0,0,0,130));
        RoundedUtils.drawRound(((float) x)+110,(float) y,130,25, 5, new Color(0,0,0,130));
        // this.drawLine(x, y + 5, 2, 10, HUD.color(0));
        //FontManager.bold24.drawStringDynamic("Info", x + 21, y + 6, 1, 50);
        //FontManager.icon22.drawStringDynamic("s", x + 7, y + 7, 1, 50);
        EntityLivingBase target = KillAura.target;

        //3D Entiy
        drawEntityOnScreen renderer = new drawEntityOnScreen(Minecraft.getMinecraft());
        renderer.drawEntity(((float) x)+30, ((float) y)+105, 50,0f,0f);

        String str = String.format("| %s | %sfps", Client.instance.getVersion(), Minecraft.getDebugFPS());
        String mark = Client.NAME;
        FontManager.bold24.drawStringDynamic(mark.toUpperCase(), x+120, y+8.5, 1,50);
        HUD.getFont().drawString(str.toUpperCase(), (float) x + 125 + FontManager.bold24.getStringWidth(mark.toUpperCase()), (float) y + 9.5f, -1);

        String health = String.format("HP: %.1f", Minecraft.getMinecraft().thePlayer.getHealth());
        String X = String.format("X: %.1f", Minecraft.getMinecraft().thePlayer.posX);
        String Y = String.format("Y: %.1f", Minecraft.getMinecraft().thePlayer.posY);
        String Z = String.format("Z: %.1f", Minecraft.getMinecraft().thePlayer.posZ);
        String item = "Item:";

        //HUD.getFont().drawString(health, (float) x + 60, (float) y + 40, -1);
        //HUD.getFont().drawString(coordinates, (float) x + 60 , (float) y + 50, -1);

        //drawFont
        FontManager.arial18.drawStringDynamic(health, (float) x + 60, (float) y + 45, 1,50);
        FontManager.arial18.drawStringDynamic(X, (float) x + 60, (float) y + 60, 1,50);
        FontManager.arial18.drawStringDynamic(Y, (float) x + 60, (float) y + 75, 1,50);
        FontManager.arial18.drawStringDynamic(Z, (float) x + 60, (float) y + 90, 1,50);
        FontManager.arial18.drawStringDynamic(item, (float) x + 60, (float) y + 15, 1,50);

        String ip = mc.isSingleplayer() ? "SinglePlayer" : mc.getCurrentServerData().serverIP;

        FontManager.arial20.drawStringDynamic("IP: " + ip, (float) x + 120, (float) y + 45, 1, 50);
        FontManager.arial20.drawStringDynamic(getTime(), (float) x + 120, (float) y + 60, 1, 50);

        //drawItem
        ItemStack heldItem = Minecraft.getMinecraft().thePlayer.getHeldItem();
        if (heldItem != null) {
            // Get Item
            String itemName = heldItem.getDisplayName();
            String durability = String.format("%d/%d", heldItem.getMaxDamage() - heldItem.getItemDamage(), heldItem.getMaxDamage());

            // Item
            RenderHelper.enableGUIStandardItemLighting();
            Minecraft.getMinecraft().getRenderItem().renderItemAndEffectIntoGUI(heldItem, (int) x + 70, (int) y + 25);
            RenderHelper.disableStandardItemLighting();

            FontManager.arial20.drawStringDynamic("Item: " + itemName, (float) x + 120, (float) y + 75, 1, 50);
            FontManager.arial20.drawStringDynamic("Durability: " + durability, (float) x + 120, (float) y + 90, 1, 50);
        }else {
            FontManager.arial20.drawStringDynamic("Item: None", (float) x + 120, (float) y + 75, 1, 50);
            FontManager.arial20.drawStringDynamic("Durability: None", (float) x + 120, (float) y + 90, 1, 50);
        }


        //Player Avatar
        //PlayerAvatarRenderer avatarRenderer = new PlayerAvatarRenderer(Minecraft.getMinecraft());
        //avatarRenderer.drawPlayerAvatar(((float) x)+25, ((float) y)+30, 45, 45);
    }
    private void resetTimer() {
        this.startTime = System.currentTimeMillis();
    }
    private String getTime() {
        long currentTime = System.currentTimeMillis();
        long elapsed = currentTime - startTime;

        int seconds = (int) (elapsed / 1000) % 60;
        int minutes = (int) (elapsed / (1000 * 60)) % 60;
        int hours = (int) (elapsed / (1000 * 60 * 60)) % 24;

        return String.format("Time: %02d:%02d:%02d", hours , minutes, seconds);
    }
    public void drawLine(double x, double y, double width, double height, Color color){
        Gui.drawRect(x, y, x + width, y + height, color.getRGB());
    }

}
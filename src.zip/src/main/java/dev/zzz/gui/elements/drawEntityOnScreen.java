package dev.zzz.gui.elements;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.OpenGlHelper;

public class drawEntityOnScreen extends Gui {
    private final Minecraft mc;

    public drawEntityOnScreen(Minecraft mc) {
        this.mc = mc;
    }
    public void drawEntity(float posX, float posY, int scale, float mouseX, float mouseY) {
        String playerName = mc.getSession().getUsername();
        AbstractClientPlayer player = (AbstractClientPlayer) mc.theWorld.getPlayerEntityByName(playerName);
        if (player != null) {
            GlStateManager.enableColorMaterial();
            GlStateManager.pushMatrix();
            GlStateManager.translate((float) posX, (float) posY, 50.0F);
            GlStateManager.scale((float) (-scale), (float) scale, (float) scale);
            GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
            float f = player.renderYawOffset;
            float f1 = player.rotationYaw;
            float f2 = player.rotationPitch;
            float f3 = player.prevRotationYawHead;
            float f4 = player.rotationYawHead;
            GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
            RenderHelper.enableStandardItemLighting();
            GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
            GlStateManager.rotate(-((float) Math.atan((double) (mouseY / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
            player.renderYawOffset = (float) Math.atan((double) (mouseX / 40.0F)) * 20.0F;
            player.rotationYaw = (float) Math.atan((double) (mouseX / 40.0F)) * 40.0F;
            player.rotationPitch = -((float) Math.atan((double) (mouseY / 40.0F))) * 20.0F;
            player.rotationYawHead = player.rotationYaw;
            player.prevRotationYawHead = player.rotationYaw;
            GlStateManager.translate(0.0F, 0.0F, 0.0F);
            RenderManager rendermanager = Minecraft.getMinecraft().getRenderManager();
            rendermanager.setPlayerViewY(180.0F);
            rendermanager.setRenderShadow(false);
            rendermanager.renderEntityWithPosYaw(player, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F);
            rendermanager.setRenderShadow(true);
            player.renderYawOffset = f;
            player.rotationYaw = f1;
            player.rotationPitch = f2;
            player.prevRotationYawHead = f3;
            player.rotationYawHead = f4;
            GlStateManager.popMatrix();
            RenderHelper.disableStandardItemLighting();
            GlStateManager.disableRescaleNormal();
            GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
            GlStateManager.disableTexture2D();
            GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);

        }
    }
}
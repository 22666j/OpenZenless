package dev.zzz.gui;

import dev.zzz.Client;
import dev.zzz.gui.video.VideoPlayer;
import dev.zzz.utils.client.menu.NormalMainMenu;
import net.minecraft.client.gui.GuiScreen;
import org.bytedeco.javacv.FFmpegFrameGrabber;
import org.bytedeco.javacv.FrameGrabber;

import java.io.File;

import static dev.zzz.gui.video.VideoPlayer.*;

public class Newsplash extends GuiScreen {

    public Newsplash(){
        try {
            Client.instance.getPlayer().init(new File(Client.BACKGROUND, "splash.mp4"));
        } catch (FFmpegFrameGrabber.Exception e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        super.drawScreen(mouseX, mouseY, partialTicks);
        try {
            Client.instance.getPlayer().render(0, 0, GuiScreen.width, GuiScreen.height);
        } catch (FrameGrabber.Exception e) {
            throw new RuntimeException(e);
        }

        if (Client.instance.getPlayer().count >= Client.instance.getPlayer().frameLength - 1) {
            try {
                Client.instance.getPlayer().stop();
            } catch (FFmpegFrameGrabber.Exception e) {
                throw new RuntimeException(e);
            }


            mc.displayGuiScreen(new NormalMainMenu());
        }
    }
}

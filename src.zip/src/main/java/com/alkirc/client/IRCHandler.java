package com.alkirc.client;


public interface IRCHandler {
    void onMessage(String sender, String message, String rank, String client);
    void onDisconnected(String message);
    void onConnected();
    String getInGameUsername();
    String getClientName();
    String getRank();
}

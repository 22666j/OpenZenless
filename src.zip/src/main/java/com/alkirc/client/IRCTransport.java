package com.alkirc.client;


import com.alkirc.packet.IRCPacket;
import com.alkirc.packet.implemention.clientbound.*;
import com.alkirc.packet.implemention.serverbound.*;
import com.alkirc.processor.IRCProtocol;
import org.smartboot.socket.MessageProcessor;
import org.smartboot.socket.transport.AioQuickClient;
import org.smartboot.socket.transport.AioSession;


import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


public class IRCTransport {
    private final IRCProtocol protocol = new IRCProtocol();
    private AioSession session;
    private IRCHandler handler;
    public static final Map<String,String> userToIgnMap = new ConcurrentHashMap<>();
    public static final Map<String,String> clienttousermap = new ConcurrentHashMap<>();
    public static final Map<String,String> ignToUserMap = new ConcurrentHashMap<>();
    public static final Map<String,String> userToRankMap = new ConcurrentHashMap<>();

    public void start(String host, int port,IRCHandler handler) throws IOException {
        this.handler = handler;
        MessageProcessor<IRCPacket> processor = (session, msg) -> {
            if(msg instanceof ClientBoundDisconnectPacket){
                handler.onDisconnected(((ClientBoundDisconnectPacket) msg).getReason());
            }
            if(msg instanceof ClientBoundConnectedPacket){
                handler.onConnected();
                ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
                Runnable task = this::sendInGameUsername;
                Runnable task2 = this::sendRank;
                Runnable task3 = this::sendClientName;
                scheduler.scheduleAtFixedRate(task, 5, 5, TimeUnit.SECONDS);
                scheduler.scheduleAtFixedRate(task2, 5, 5, TimeUnit.SECONDS);
                scheduler.scheduleAtFixedRate(task3, 5, 5, TimeUnit.SECONDS);
            }
            if(msg instanceof ClientBoundUpdateUserListPacket) {
                ClientBoundUpdateUserListPacket updateUserListPacket = (ClientBoundUpdateUserListPacket) msg;
                Map<String, String> userMap = updateUserListPacket.getUserMap();
                userToIgnMap.clear();
                userToIgnMap.putAll(userMap);
                ignToUserMap.clear();
                userToIgnMap.forEach((user, ign) -> ignToUserMap.put(ign, user));
            }
            if (msg instanceof ClientBoundUpdateClientListPacket) {
                clienttousermap.clear();
                clienttousermap.putAll(((ClientBoundUpdateClientListPacket) msg).getclientnamemap());
            }

            if (msg instanceof ClientBoundRankPacket){
                userToRankMap.clear();
                userToRankMap.putAll(((ClientBoundRankPacket) msg).getRankMap());
            }
            if(msg instanceof ClientBoundMessagePacket){
                handler.onMessage(((ClientBoundMessagePacket) msg).getSender(),((ClientBoundMessagePacket) msg).getMessage(), ((ClientBoundMessagePacket) msg).getRank(),((ClientBoundMessagePacket) msg).getClient());
            }
        };
        AioQuickClient client = new AioQuickClient(host, port, protocol, processor);
        session = client.start();
    }
    public void close(){
        session.close();
    }
    public boolean isDisconnected(){
        return !session.isInvalid();
    }
    public boolean isConnected(){
        return session.isInvalid();
    }

    public void sendPacket(IRCPacket packet){
        try {
            byte[] data = protocol.encode(packet);
            session.writeBuffer().writeInt(data.length);
            session.writeBuffer().write(data);
            session.writeBuffer().flush();
        }catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public boolean isUser(String name) {
        boolean exists = ignToUserMap.containsKey(name);
//        System.out.println("Checking if user exists for ign: " + name + ", exists: " + exists);
        return exists;
    }


    public String getName(String ign){
        return ignToUserMap.get(ign);
    }

    public String getIgn(String name){
        return userToIgnMap.get(name);
    }
    public String getRank(String name){
        return userToRankMap.get(name);
    }
    public String getClient(String name){
        return clienttousermap.get(name);
    }

    public void sendChat(String message){
        sendPacket(new ServerBoundMessagePacket(message));
    }
    private void sendRank(String username){
        sendPacket(new ServerBoundRankPacket(username));
    }
    public void sendRank(){
        sendRank(handler.getRank());
    }
    public void sendInGameUsername(String username){
        sendPacket(new ServerBoundUpdateIgnPacket(username));
    }

    public void sendInGameUsername(){
        sendInGameUsername(handler.getInGameUsername());
    }

    public void sendClientName(String clientName){
        sendPacket(new ServerBoundUpdateClientPacket(clientName));
    }

    public void sendClientName(){
        sendClientName(handler.getClientName());
    }
    public void connect(String username,String token){
        sendPacket(new ServerBoundHandshakePacket(username,token));
    }

    public void setHandler(IRCHandler handler) {
        this.handler = handler;
    }

}

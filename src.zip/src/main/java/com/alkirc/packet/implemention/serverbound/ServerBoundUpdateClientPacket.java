package com.alkirc.packet.implemention.serverbound;


import com.alkirc.packet.IRCPacket;
import com.alkirc.packet.annotations.ProtocolField;

public class ServerBoundUpdateClientPacket implements IRCPacket {
    @ProtocolField("n")
    private final String clientName;

    public ServerBoundUpdateClientPacket(String clientName) {
        this.clientName = clientName;
    }

    public String getName() {
        return clientName;
    }
}

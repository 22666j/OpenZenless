package com.alkirc.packet.implemention.clientbound;

import com.alkirc.packet.IRCPacket;
import com.alkirc.packet.annotations.ProtocolField;

import java.util.Map;

public class ClientBoundRankPacket implements IRCPacket{
    @ProtocolField("r")
    private final Map<String,String> rankMap;

    public ClientBoundRankPacket(Map<String, String> rankMap) {
        this.rankMap = rankMap;
    }

    public Map<String, String> getRankMap() {
        return rankMap;
    }
}

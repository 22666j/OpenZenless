package com.alkirc.packet.implemention.clientbound;


import com.alkirc.packet.IRCPacket;
import com.alkirc.packet.annotations.ProtocolField;

import java.util.Map;

public class ClientBoundUpdateClientListPacket implements IRCPacket {
    @ProtocolField("u")
    private final Map<String,String> clientnamemap;

    public ClientBoundUpdateClientListPacket(Map<String, String> clientnamemap) {
        this.clientnamemap = clientnamemap;
    }

    public Map<String, String> getclientnamemap() {
        return clientnamemap;
    }
}

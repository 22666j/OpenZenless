package com.alkirc.packet.implemention.clientbound;

import com.alkirc.packet.IRCPacket;


public class ClientBoundConnectedPacket implements IRCPacket {
}

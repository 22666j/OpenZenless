package com.alkirc.packet.implemention.clientbound;


import com.alkirc.packet.IRCPacket;
import com.alkirc.packet.annotations.ProtocolField;

public class ClientBoundMessagePacket implements IRCPacket {
    @ProtocolField("s")
    private final String sender;

    @ProtocolField("m")
    private final String message;
    @ProtocolField("r")
    private final String rank;
    @ProtocolField("b")
    private final String client;

    public ClientBoundMessagePacket(String sender, String message, String rank,String client) {
        this.sender = sender;
        this.message = message;
        this.rank = rank;
        this.client = client;
    }

    public String getSender() {
        return sender;
    }

    public String getMessage() {
        return message;
    }
    public String getRank(){return rank;}
    public String getClient(){return client;}
}

package com.alkirc.packet.implemention.serverbound;


import com.alkirc.packet.IRCPacket;
import com.alkirc.packet.annotations.ProtocolField;

public class ServerBoundRankPacket implements IRCPacket {
    @ProtocolField("u")
    private String user;
    public ServerBoundRankPacket(String user) {
        this.user = user;
    }
    public String getUser(){
        return user;
    }
}

package com.alkirc.packet.implemention.serverbound;


import com.alkirc.packet.IRCPacket;
import com.alkirc.packet.annotations.ProtocolField;

public class ServerBoundMessagePacket implements IRCPacket {
    @ProtocolField("m")
    private final String message;

    public ServerBoundMessagePacket(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
